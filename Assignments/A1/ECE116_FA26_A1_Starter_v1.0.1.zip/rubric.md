# A1 grading rubric

A1 is graded out of 100 points and contributes 18.75 percent of the course grade.

## Part A: Code behavior (50 points)

Each passed behavioral test is worth one point. The criteria apply to the code in your complete
Canvas ZIP; no separate code upload is required.

| Concept group | Tests | Points |
|---|---:|---:|
| Periodic scheduling | 5 | 5 |
| ADC to PWM mapping | 6 | 6 |
| Button debounce | 6 | 6 |
| Lab state machine | 2 | 2 |
| Calibration math | 6 | 6 |
| Calibration sequence | 7 | 7 |
| Stable cover detection | 5 | 5 |
| Gesture events | 6 | 6 |
| Timer state machine | 7 | 7 |
| **Total** | **50** | **50** |

A compile failure scores 0 for Part A. A crash or timeout loses only the affected behavioral test
when that failure can be isolated.

## Part B: System behavior, evidence, and reasoning (50 points)

The scoring bands describe how each criterion is assessed. Intermediate scores are possible when
your work falls between bands.

### B1. Physical lab controller (8 points)

- **0:** The lab does not compile or cannot demonstrate the controller.
- **4:** Some modes work, but periodic reporting, one-press transitions, separate outputs, or AUTO
  response is unreliable.
- **6:** OFF/AUTO/ON and light-dependent PWM work with one meaningful gap in behavior or evidence.
- **8:** One press produces one transition, GPIO2 acts as the ON output, GPIO3 acts as the AUTO
  output, AUTO responds over the measured light range, and sensing plus rate-limited reporting
  continue in every mode.

### B2. Adaptive calibration and two-environment operation (12 points)

- **0:** The device uses a fixed raw threshold or cannot calibrate.
- **6:** It measures two references but has a broken prompt, validity, release, or recovery path.
- **9:** The complete calibration sequence works in one environment and diagnostics agree with
  observed values, but the second environment or one recovery behavior is weakly supported.
- **12:** The same uploaded firmware visibly calibrates and accepts gestures in two meaningfully
  different lighting conditions, rejects an insufficient span, and never leaks the calibration
  cover into the timer.

### B3. Integrated timer behavior and observability (12 points)

- **0:** The physical timer does not reach its required modes.
- **6:** A partial happy path works, but entry, adding, commit, countdown, done, or cancel is
  broken, or state cannot be inspected.
- **9:** The full happy path works with one transition, cancel origin, LED pattern, or Serial
  reporting gap.
- **12:** R1-R6 work repeatedly; LEDs distinguish calibration and timer state; Serial reports
  calibration once and timer state or whole-second changes without flooding.

### B4. Engineering evidence and calibration/timer FSMs (10 points)

- **0:** Required figures and behavior evidence are missing.
- **5:** Some artifacts exist but do not establish the claimed sequence or disagree with code.
- **8:** The student-authored calibration and timer FSM regions, four named GIFs, and Serial
  excerpts cover most claims with one meaningful gap.
- **10:** Every required artifact is embedded, captioned, and traceable to the submitted system;
  the calibration region correctly traces conditions, captures/resets, returned events, and LED
  behavior, while the timer region matches the implementation's states, events, cancel paths, and
  visible outputs.

### B5. Parameter justification, code reading, and adaptation reasoning (8 points)

- **0:** Decision values are unexplained, and the code-reading and adaptation responses are absent.
- **4:** Some values have observations, but several parameters remain unsupported or the
  code-reading responses mostly restate function names without explaining behavior.
- **6:** Implemented parameters are mostly justified, most supplied mechanisms are explained
  accurately, and the adaptation response covers most requested issues.
- **8:** Calibration and trial evidence support each student-selected normalized and temporal choice; all supplied
  mechanisms are explained using the relevant fields and branches; and the adaptation response
  explains update conditions, freeze conditions, timescale relative to a tap, and recovery from an
  abrupt lighting change.
