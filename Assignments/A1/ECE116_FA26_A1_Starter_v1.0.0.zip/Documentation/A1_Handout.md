# A1: Light-controlled timer

**Due:** Friday, October 9 at 7:00 p.m. Pacific Time

## Assignment brief

Build a countdown timer that uses a light-dependent resistor (LDR) as its input and three LEDs as
its output. The timer must measure the current lighting conditions at startup, recognize several
cover gestures, and remain responsive while it tracks time and updates its outputs.

A1 has two parts. The Lab reviews the Arduino toolchain and develops reusable functions for
nonblocking timing, analog input, pulse-width modulation (PWM), button events, and state-dependent
output. The Challenge applies those patterns to calibration, gesture events, and a finite-state
machine (FSM).

By completing A1, you will learn to:

- organize several periodic services in one nonblocking `loop()`;
- map a sensor reading into a bounded output;
- convert a noisy physical input into a discrete event;
- implement application behavior as an explicit FSM;
- calibrate a sensor against its current operating environment.

## System requirements

The completed Challenge must satisfy the following behavior:

- On startup, measure uncovered and covered light references before accepting timer gestures.
- Use the measured references to normalize later readings instead of relying on a fixed ADC
  threshold.
- Accept three quick taps to enter `ADDING`, then add one time unit for each additional tap.
- Accept a sustained cover to start `COUNTDOWN`.
- Update the countdown from elapsed time without blocking the sensor and output services.
- Accept a longer cover in `ADDING` or `COUNTDOWN` to cancel the timer and return to `STANDBY`.
- Enter `DONE` at zero, display a brief LED alert, and return to `STANDBY`.
- Report calibration results, events, state changes, and visible seconds over Serial without
  printing unchanged status on every loop pass.
- Continue calibrating, sensing, and timing when Serial Monitor is closed. Opening or closing a
  monitor may affect which diagnostic lines you can see; it must not control application progress.

You will choose several timing and threshold values from measurements on your hardware. The same
compiled firmware must recalibrate and operate in two meaningfully different lighting conditions.

## Provided system and implementation boundary

The course provides the integration sketches, headers, hardware I/O, Serial reporting, state
structures, function contracts, and TODO frames. You implement the logic in exactly two files:

- `Arduino/Lab_1/a1_lab_logic.cpp`
- `Arduino/Challenge_1/a1_timer_logic.cpp`

Do not edit the supplied `.ino` files or headers. Each Arduino project uses the same three-file
structure:

| File | Role |
|---|---|
| `.ino` | Supplied integration code that owns pins, hardware I/O, Serial output, and `loop()`. Read it, but do not edit it. |
| `.h` | Supplied interface contract. Read this first for types, function parameters, units, threshold directions, and return values. |
| `.cpp` | Your implementation file. Complete the labeled TODOs without renaming functions or changing their parameters. |

Read each project in this order:

1. Read the header to learn the types, function contracts, and units.
2. Read the TODO frame in the `.cpp` file to find the required implementation work.
3. Read the `.ino` file to see where the functions are called.

The starter uses the following C++ forms:

- `a1::name` selects a type or function inside the course namespace.
- `Type *state` passes persistent state that the function updates with `state->field`.
- `const Type &config` passes a configuration by read-only reference; access its fields with
  `config.field`.

## Lab: Build a responsive night-light controller

**Planned session:** Thursday, October 1, three hours

Complete this lab on Thursday, October 1. The Lab reviews the board workflow and develops the
input, timing, event, and output patterns used in the Challenge. Begin the Challenge after the Lab,
and continue working through the Friday, October 9 deadline. Thursday, October 8 is an open-work
session for Challenge integration, testing, and debugging.

The Lab controller has three modes and two state-dependent outputs:

- `OFF`: Both LEDs are off.
- `AUTO`: The first LED is off. The LDR controls the second LED with PWM, with darker conditions
  producing a brighter LED.
- `ON`: The first LED is on steadily. The second LED is off.

Each accepted button press advances `OFF -> AUTO -> ON -> OFF`. The same nonblocking `loop()` must
continue to sample the sensor, update the outputs, service the button, and report status over
Serial.

### Lab setup

Required equipment:

- Seeed Studio XIAO ESP32-S3 Sense and a USB-C data cable.
- GL5528 LDR and an approximately 10 kOhm fixed resistor for the voltage divider.
- Three distinct-color LEDs, each with its own approximately 220-330 Ohm resistor.
- One momentary pushbutton for the structured lab.
- Breadboard and jumper wires.

Connect the Lab button from GPIO5 to GND. The supplied sketch configures the pin with
`INPUT_PULLUP`. Leave the button connected when you begin the Challenge; the Challenge does not
use GPIO5.

The pinout diagram identifies the XIAO pins used in A1.

![XIAO ESP32-S3 pins used in A1](Fig/xiao_pinout.png)
*A0 reads the light divider. The Lab uses D1/GPIO2 for the ON LED, D2/GPIO3 for the AUTO LED,
and D4/GPIO5 for its pushbutton. The Challenge uses D1/D2/D3 for its three mode LEDs.*

The voltage-divider diagram shows the light-dependent resistor (LDR) circuit. The divider converts
a change in LDR resistance into a voltage that the analog-to-digital converter (ADC) can sample.

![GL5528 LDR voltage divider](Fig/ldr_divider.png)
*Wire the divider as 3V3 - LDR - A0 node - 10 kOhm - GND. Measure the covered and uncovered ranges
on your board. Ambient light and component tolerances affect the ADC readings.*

Place one current-limiting resistor in series with each LED. Estimate the resistance with
`R = (Vsupply - Vf) / I_target`. Use the forward-voltage value for the LED color that you install.

![Mode LED with current-limiting resistor](Fig/led_resistor.png)
*Connect each GPIO-driven LED through its own series resistor. Repeat this branch for each mode
LED.*

### Arduino IDE orientation

The first Lab activity brings up the Arduino development environment with the actual `Lab_1`
starter. You may complete the installation before class, but setup and recovery time are included
in the Lab. A1 does not use a separate setup sketch or a completed example of the Lab behavior.

The steps below cover the Arduino IDE operations required for A1. If you have not used Arduino IDE
before, use these official references for the unfamiliar operation and then return to the course
checkpoint:

| Operation | Official reference |
|---|---|
| Install Arduino IDE 2 | [Downloading and installing Arduino IDE 2](https://docs.arduino.cc/software/ide-v2/tutorials/getting-started/ide-v2-downloading-and-installing) |
| Install an ESP32 board package | [Arduino IDE 2 Board Manager](https://docs.arduino.cc/software/ide-v2/tutorials/ide-v2-board-manager) |
| Connect and identify the XIAO ESP32-S3 | [Seeed Studio XIAO ESP32-S3 getting started](https://wiki.seeedstudio.com/xiao_esp32s3_getting_started/) |
| Verify and upload a sketch | [Uploading a sketch with Arduino IDE 2](https://docs.arduino.cc/software/ide-v2/tutorials/getting-started/ide-v2-uploading-a-sketch) |
| Read device output | [Arduino IDE 2 Serial Monitor](https://docs.arduino.cc/software/ide-v2/tutorials/ide-v2-serial-monitor) |

The official references demonstrate general tool use. The course version, board target, port,
starter file, and baud rate below define the A1 environment.

Install ESP32 Arduino core 3.3.10 and connect the board with a USB-C data cable. Select the board
target `esp32:esp32:XIAO_ESP32S3`. A1 uses only libraries included with that core. Use `Lab_1` as
your first compile and upload target.

#### Arduino IDE path

1. In `File > Preferences`, add
   `https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json`
   to `Additional Boards Manager URLs`.
2. In `Boards Manager`, install `esp32 by Espressif Systems` version 3.3.10.
3. Select `Tools > Board > esp32 > XIAO_ESP32S3`, and then select the connected port.
4. Open `Arduino/Lab_1/Lab_1.ino`.
5. Click `Verify`, and then click `Upload`. The starter compiles and prints a banner before you
   complete the TODOs. The controller behavior remains incomplete.

#### Optional command-line path

Optional: If you use `arduino-cli`, run the following commands from the package root. Replace
`<PORT>` with the connected serial port.

```text
arduino-cli config add board_manager.additional_urls \
  https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
arduino-cli core update-index
arduino-cli core install esp32:esp32@3.3.10
arduino-cli compile --fqbn esp32:esp32:XIAO_ESP32S3 Arduino/Lab_1
arduino-cli upload --fqbn esp32:esp32:XIAO_ESP32S3 -p <PORT> Arduino/Lab_1
```

Open the Serial Monitor at 115200 baud. Confirm that the starter banner appears. If it does not
appear, check the selected board, port, cable, and ESP32 core installation before debugging the Lab
logic.

The supplied integration sketches make USB diagnostic writes nonblocking. Close Serial Monitor
after bring-up and confirm that the physical controller continues to operate. When you reopen the
monitor, the sketch reports its current calibration or application state.

### Lab implementation

The supplied `Lab_1.ino` contains the pin assignments, direct hardware I/O, Serial output, and
cooperative service loop. Implement the six graded functions in `a1_lab_logic.cpp`. Use
`a1_lab_logic.h` as the interface contract. Complete the labeled TODO expressions and transitions
within the supplied `.cpp` structure.

Read the signal path in `loop()` in this order: raw input, accepted event, application state, and
state-dependent output. The write-up questions cover both the supplied structure and the TODOs
that you complete.

### Lab work sequence

Work through Problems L1-L6 in this order. Do not wait until every TODO is complete before testing.
After each problem, trace the function with the listed examples, compile the sketch, and inspect
the observable checkpoint. The functions are grouped by role in the source file, so their physical
order is not the required completion order.

---

### L1: Schedule work without blocking

**TODOs:** `L1a-L1c`

**Goal:** Implement a rollover-safe scheduler that lets several services share `loop()` without
blocking one another.

**Work**

1. Complete `L1a` by calculating elapsed time from `nowMs` and `*lastRunMs`.
2. Complete `L1b` by rejecting a call while the elapsed time is shorter than `intervalMs`.
3. Complete `L1c` by recording the accepted run time before returning `true`.
4. Use unsigned subtraction, `nowMs - *lastRunMs`. Comparing `nowMs` with
   `*lastRunMs + intervalMs` fails near `millis()` rollover. A service becomes due at the inclusive
   boundary `elapsedMs >= intervalMs`.

**Evidence:** Keep a short Serial excerpt showing that reports continue without a blocking pause
while you change the light level. At this stage, unfinished mode and mapping logic may leave the
output fields at their starter values.

**Complete when:** The Serial trace continues without a `delay()`-based pause.

---

### L2: Measure the light range

**TODOs:** `L2a-L2b` | **Checkpoint:** configured references match observed ranges

**Goal:** Measure the sensor endpoints needed to interpret the ADC values from your own circuit.

**Work**

1. Observe several uncovered readings and several covered readings in the Serial trace.
2. Complete `L2a` with a representative uncovered reading.
3. Complete `L2b` with a representative covered reading.
4. Do not use one momentary extreme. For the supplied divider, the uncovered value must be greater
   than the covered value, and both conditions will vary across samples.

**Evidence:** Under **Design Decisions** in the README, record the observed uncovered and covered ranges and identify the representative value selected from each range.

**Complete when:** After a reset, the configured values still agree with the observed ranges and the source uses those values. Implement the mapping in L3.

---

### L3: Map ADC readings to PWM

**TODOs:** `L3a-L3b`

**Goal:** Map the measured sensor range into a bounded PWM output with defined endpoint behavior.

**Work**

1. Complete `L3a` by scaling the distance from the bright reference by `maxDuty`.
2. Complete `L3b` by dividing by the calibrated ADC span and rounding to the nearest integer.
3. Use the interior relationship
   `(brightReference - reading) / (brightReference - darkReference)`.
4. Keep the supplied `int64_t` intermediates so multiplication occurs before integer division
   without overflowing. Account for half of the positive denominator before division to round
   instead of truncate.
5. Leave the three supplied early returns unchanged. They reject invalid references and clamp
   readings outside the measured range.

**Evidence:** Under **Design Decisions** in the README, show the expected duty at the bright endpoint, dark endpoint, and midpoint. Retain a short observation of the AUTO LED responding to a changing light level.

**Complete when:** Bright produces duty `0`, dark produces `maxDuty`, the midpoint produces approximately half duty.

---

### L4: Define the mode cycle

**TODOs:** `L4a-L4c`

**Goal:** Express the controller's mode sequence as a finite-state transition rule.

**Work**

1. Complete `L4a` with the mode after `OFF`.
2. Complete `L4b` with the mode after `AUTO`.
3. Complete `L4c` with the mode after `ON`.
4. Keep the supplied `default` recovery behavior. `nextLightMode()` does not read the button or
   drive an LED. Given the current state, it returns only the next state.

![Example FSM: OFF/DIM/BRIGHT](Fig/example_fsm.png)
*A generic three-state FSM in enum-and-switch form. The Lab uses OFF/AUTO/ON; the Challenge uses a
different set of states and events.*

**Evidence:** Under **Design Decisions** in the README, trace four calls beginning at `OFF` and identify the state returned by each call.

**Complete when:** A traced event advances OFF to AUTO to ON to OFF, and each state's outputs match its requirements. Hardware will not advance reliably until L5 creates one clean event per press.

---

### L5: Convert a noisy level into one event

**TODOs:** `L5a-L5f`

**Goal:** Convert noisy button samples into one accepted event for each physical press.

**Work**

1. Complete `L5a` by initializing the accepted level to the observed startup level.
2. Complete `L5b` and `L5c` by recording a newly observed raw level and the time it appeared.
3. Complete `L5d` by measuring how long that raw level has remained unchanged.
4. Complete `L5e` by testing the stable-time requirement.
5. Complete `L5f` by testing whether the qualified raw level differs from the accepted level.
6. Treat `lastRawPressed` as the newest electrical observation and `stablePressed` as the level the
   application has accepted. Restart the timer after every raw change. An accepted release rearms
   the next press without becoming a press event.

![Decision on value vs decision on edge](Fig/edge_vs_value.png)
*A level describes the signal now. An edge identifies when it changed. Stable-time qualification
decides whether that change is accepted.*

**Evidence:** Under **Design Decisions** in the README, explain the difference between the raw and accepted levels. Retain a hardware observation covering one press, a held press, release, and several ordinary presses.

**Complete when:** One press advances one mode; holding does not repeat; and release does not advance the mode.

---

### L6: Integrate and check off

**Milestone:** integrated hardware check

**Goal:** Verify the complete nonblocking signal path and state-dependent outputs on hardware.

**Work**

1. Compile the updated sketch and confirm the L1-L5 checkpoints.
2. Test the full signal path: raw button level -> accepted press event -> mode -> state-dependent
   outputs.
3. Keep Serial Monitor open while cycling through all three modes.
4. Confirm that the ON LED is active only in `ON`, the AUTO LED responds to the LDR only in `AUTO`,
   and both LEDs are off in `OFF`.

For checkoff, show a single `lab_controller.gif` that includes all three modes, the separate ON and
AUTO outputs, and visible AUTO response to changing light. In your README, include a short matching
Serial excerpt containing `mode`, `light`, `on_led`, and `auto_duty`. Be ready to point to the
boundary between raw button level, accepted press event, application state, and output.

The Challenge extends this event pattern by measuring cover duration, classifying light gestures,
and using those events in the timer FSM.

**Evidence:** Submit `lab_controller.gif` and the matching Serial excerpt in the final package. Use them to identify the raw level, accepted event, state, and output boundary.

**Complete when:** All three modes behave as specified, and sensor, button, output, and Serial services remain responsive together.

---

### Lab write-up questions

Answer these questions under **Design Decisions** in your README. Refer to the relevant lines in
`a1_lab_logic.cpp` and `Lab_1.ino`; do not answer only from the function names.

1. `mapLightToDuty()` begins with three `if` statements. For each condition, describe the sensor
   situation, the returned duty, and why the function handles it before interpolation.
2. Why does the mapping require `brightReference > darkReference`? What assumption does this make
   about the voltage-divider direction? What would change if covering the LDR increased the ADC
   reading?
3. Why does `periodicDue()` use unsigned subtraction? Why does it update `*lastRunMs` only when it
   returns `true`?
4. What different information do `lastRawPressed` and `stablePressed` represent? Why must
   `resetButtonDebouncer()` initialize them to the same level?
5. Why must your raw-change block in `updateButtonDebouncer()` restart `rawChangedMs` after every
   observed change? Describe one bounce sequence that would be accepted too early without this
   restart.
6. Trace both Lab LED outputs in `OFF`, `AUTO`, and `ON`. Why does the supplied sketch continue to
   sample and map the LDR while the controller is not in `AUTO`?

## Challenge: Build the light-controlled timer

Build a countdown timer that runs on the XIAO. The timer uses the light sensor as its only input.
Three colored LEDs indicate the current mode. Serial output reports each mode change and each
change to the accumulated or remaining whole seconds.

The timer must calibrate itself after each reset. During calibration, it measures the sensor in
uncovered and covered conditions. It then uses those references to interpret later readings. The
same compiled program must work under different ambient-light conditions. Do not use a fixed raw
ADC threshold.

### Startup calibration

Implement the following calibration sequence:

1. Leave the sensor uncovered when the board starts. Keep all three LEDs steadily on for five
   seconds while the device captures the uncovered reference.
2. Blink all three LEDs to request the covered condition. Cover the sensor and keep it covered.
   Begin the covered capture only after the sensor reading shows a sustained decrease.
3. Turn all three LEDs off when covered capture is complete. Uncover the sensor. Wait for a stable
   release before entering `STANDBY`. Do not classify the calibration cover as a timer gesture.
4. Turn on the green standby LED when calibration succeeds and the timer is ready.
5. If the references are reversed or too close together, the supplied recovery branch shows a
   distinct rapid error blink for 1200 ms and restarts calibration. Uncover the sensor as soon as
   the rapid blink begins so the next ambient capture starts uncovered. You implement the validity
   decision and represent this supplied recovery behavior in your calibration FSM diagram.

After calibration, map each reading to a cover score from `0.0` to `1.0`. The uncovered reference
maps to approximately `0.0`, and the covered reference maps to approximately `1.0`. Use separate
entry and release thresholds to add hysteresis. Require a threshold crossing to remain stable for
a specified time before updating the accepted covered level.

After each successful calibration, report the two measured references, their span, and the
corresponding raw diagnostic boundaries over Serial. Compute these values from the current
calibration. Do not copy measured ADC values into the source as constants.

### Starter code contract

The supplied `Challenge_1.ino` connects the sensor, LEDs, Serial reporting, and main loop. Implement
the graded logic and configuration values in `a1_timer_logic.cpp`. Do not change the declarations
in `a1_timer_logic.h`. The header defines the function inputs, state fields, units, threshold
directions, return values, and mode names. Use the behavioral requirements to design the state
transitions.

Read the pipeline in `loop()` in this order: raw ADC reading, normalized score, accepted covered
level, gesture event, and finite-state machine (FSM) state. The rate-limited diagnostic output
reports the values at each stage. Use these reports to test one stage before depending on it in the
next stage.

The Challenge `.cpp` file provides common helpers, complete reset functions, and the outer branch
and `switch` structure. Complete the TODOs for calibration, stable cover detection, gesture
classification, and the transitions required by R1-R6. Multi-statement TODOs appear inside the
phase, state, or event branch where that behavior belongs.

### Behavioral requirements

- **R0: Calibration.** Complete the startup calibration sequence. After a reset, the same compiled
  firmware must recalibrate and operate in two meaningfully different ambient-light conditions.
  Do not edit or upload the program between trials.
- **R1: Timer entry.** From `STANDBY`, accept exactly three quick taps to enter `ADDING` and add the
  first unit of time. Require each tap to arrive within a time window after the previous tap. Reset
  the entry count when the window expires. Choose and document the window.
- **R2: Add time.** In `ADDING`, add a fixed amount for each additional tap, and report the new
  accumulated time over Serial. Store the value as `uint32_t`. Because the committed duration is
  stored in milliseconds, limit the accumulated value to `UINT32_MAX / 1000U` whole seconds. If an
  addition exceeds that limit, store the limit instead of allowing either representation to wrap.
- **R3: Commit.** Accept a sustained cover of approximately one second as a commit event. A commit
  moves the timer from `ADDING` to `COUNTDOWN`.
- **R4: Countdown.** Calculate the remaining time from `millis()`, and report each new whole-second
  value over Serial.
- **R5: Done.** When the remaining time reaches zero, enter `DONE`, show a clear LED alert for
  approximately two seconds, and then return to `STANDBY`.
- **R6: Cancel.** Define a cover-duration gesture that returns the timer to `STANDBY` from either
  `ADDING` or `COUNTDOWN`. Implement both cancel paths as FSM transitions.

For R0, record the minimum and maximum uncovered raw readings seen during each five-second ambient
capture. The two lighting conditions are meaningfully different when those observed uncovered
ranges do not overlap. Both trials must still produce a valid calibration and accept a timer tap.
If the ranges overlap, change the ambient lighting more and repeat the two trials with the same
uploaded firmware.

Classify a cover by its duration. Use nonoverlapping intervals for tap, commit, and cancel. Leave a
dead band between the tap and commit intervals. Set the cancel threshold above the complete commit
interval. Choose each boundary from your own timing trials, and explain the selected values in the
README.

Implement the required and trial-supported values in `makeCalibrationConfig()`,
`makeCoverDecisionConfig()`, `makeGestureConfig()`, and `makeTimerConfig()`. The supplied `.ino`
reads those configurations; you do not edit the integration sketch.

### Output and reporting requirements

Use three distinct LED colors. Activate exactly one mode LED in `STANDBY`, `ADDING`, and
`COUNTDOWN`. After each accepted tap in `ADDING`, briefly turn all three LEDs on. Because the
`ADDING` LED is already on, the other two LEDs provide the visible acknowledgment. Use a clear
multi-LED pattern in `DONE`, and use the specified LED patterns during calibration. Document the
complete LED mapping. A1 does not use a buzzer or OLED.

Report every mode change over Serial. In `ADDING` and `COUNTDOWN`, also report each change to the
accumulated or remaining whole seconds. Rate-limit periodic diagnostics, and do not print an
unchanged status on every loop pass.

The Challenge reuses the Lab patterns for cooperative services, mapping, clamping, event
boundaries, and enum-and-switch FSMs. Implement the calibration checks, normalized cover detector,
hysteresis, duration classifier, timer transitions, integration, and required evidence.

### Challenge work sequence

Work through Problems C1-C6 in this order. The four configuration functions are physically grouped
near the beginning of `a1_timer_logic.cpp`; fill in only the configuration named by the problem you
are currently solving. Compile the updated sketch after each problem and inspect its stated
observable checkpoint.

### Configuration tuning sequence

The configuration TODOs need provisional values before the complete system can run. Use this staged
procedure instead of treating the first values you type as final:

1. Choose provisional values inside the ranges below and complete only the logic for the current
   problem. These ranges are bring-up bounds, not an answer key.
2. During calibration, record the uncovered and covered ranges, within-condition variation, and
   resulting span. Tune calibration values first; do not tune gesture timing around an unstable
   sensor decision.
3. Use the `sensor raw=... score=... covered=...` trace to tune normalized entry, release, and
   stable-time values. Require separation from ordinary uncovered and covered variation.
4. Time several deliberate taps, commits, and cancels. Choose boundaries with margin around the
   observed durations and preserve the required dead band and ordering.
5. Repeat the complete calibration and gesture trials in the second, nonoverlapping uncovered-light
   range. Revise values only if necessary, then rerun both conditions without changing firmware
   between the two final trials.

| Policy | Safe provisional range or relationship |
|---|---|
| Covered capture | 500-2000 ms |
| Calibration trigger and release stability | 100-300 ms each |
| Calibration error display | Course-supplied 1200 ms; always uncover during the rapid blink |
| Fractional drop requesting covered capture | 0.15-0.35 |
| Calibration release score | 0.20-0.50 |
| Minimum calibration span | 200-600 ADC counts, below both measured spans and above ordinary noise |
| Normal cover entry and release scores | entry 0.65-0.85; release 0.20-0.50; keep entry at least 0.15 higher |
| Normal cover stable time | 20-100 ms |
| Tap boundaries | minimum 20-100 ms; exclusive maximum 250-500 ms |
| Commit and cancel boundaries | commit minimum 800-1500 ms; cancel minimum 2000-3500 ms |
| Entry-tap window | 600-1200 ms |
| Seconds per tap | 5-30 seconds, chosen for a practical recorded demonstration |
| DONE alert | 1500-2500 ms |

---

### C1: Establish a calibrated signal scale

**TODOs:** `C1a-C1f`, `C5-C7`

**Goal:** Define a calibrated sensor scale that maps changing raw ADC values into a stable
normalized cover score.

**Work**

1. Complete `C1a-C1c` with the covered-capture, stable trigger, and stable release intervals.
   The course supplies the 1200 ms error-display duration.
2. Complete `C1d-C1f` with the fractional drop that requests covered capture, the calibration
   release score, and the minimum acceptable ADC span.
3. Complete `C5` so only correctly ordered references with enough separation are valid.
4. Complete `C6` so uncovered maps to `0`, covered maps to `1`, and intermediate readings map
   proportionally.
5. Complete `C7` by mapping a bounded score back to the raw ADC boundary used in the Serial report.
6. For the supplied divider, use `span = uncoveredReference - coveredReference`. The forward
   mapping divides the sample's drop from the uncovered reference by this span. The inverse mapping
   starts at the uncovered reference and subtracts `score * span`. Read the function contract to
   determine whether a span exactly equal to `minimumSpan` is valid.

**Evidence:** Under **Design Decisions** in the README, show the uncovered, covered, and midpoint score calculations and one inverse mapping such as score `0.7`.

**Complete when:** The endpoint, midpoint, and inverse examples agree with the configured reference direction.

---

### C2: Run startup calibration

**TODOs:** `C8a-C8h`

**Goal:** Implement startup calibration as a nonblocking state machine over sensor samples and
elapsed time.

**Work**

1. Complete `C8a-C8b` to end ambient capture and save its average.
2. Complete `C8c-C8e` to calculate fractional drop, request covered capture, and require a
   continuous trigger for `triggerStableMs`.
3. Complete `C8f-C8g` to end covered capture and save its average.
4. Complete `C8h` so release is accepted only after a continuous `releaseStableMs` candidate.
5. Read the supplied `CAL_PHASE_ERROR` branch. Trace how elapsed error-display time calls
   `beginCalibration()`, clears the old capture state, and returns `CAL_EVENT_RESTARTED`.
6. Draw the calibration FSM from the complete mixed supplied/TODO implementation. Include
   `AMBIENT`, `WAIT_COVER`, `CAPTURE_COVERED`, `WAIT_RELEASE`, `ERROR`, and `READY`.
   Label every transition condition, captured value or state reset, returned calibration event,
   and visible LED behavior. Do not copy a completed diagram from another source.
7. Keep the supplied phase-entry helper on every transition. The current sample is added before a
   capture boundary is tested, so that boundary sample belongs to the average. A broken cover or
   release request must discard its old candidate time. Guard fractional-drop calculation when the
   uncovered reference is zero.

**Evidence:** Retain a Serial excerpt containing `calibration phase=... raw=...` for one valid
calibration and one inadequate-span attempt. Record the LED sequence and resulting ready or
restart behavior. Include the calibration FSM as a clearly labeled region of
`Documentation/Fig/fsm_diagram.png`.

**Complete when:** One valid calibration reaches `STANDBY`; and an inadequate span enters the error phase and restarts.

---

### C3: Turn scores into a stable covered level

**TODOs:** `C2a-C2c`, `C9a-C9d`

**Goal:** Convert a varying normalized score into one stable covered or uncovered level.

**Work**

1. Complete `C2a-C2c` with a higher covered-entry score, lower release score, and positive stable
   time.
2. Complete `C9a-C9b` by recognizing a newly requested candidate and storing its value and start
   time.
3. Complete `C9c-C9d` by accepting a candidate only after it remains continuous for the stable
   interval.
4. Preserve the accepted state while the score lies between `releaseScore` and `enterScore`. This
   hysteresis is separate from temporal qualification: a score beyond a threshold must also remain
   there continuously before the accepted level changes.

**Evidence:** Retain a short `sensor raw=... score=... covered=...` trace containing a brief crossing, sustained cover, and values in the hysteresis band.

**Complete when:** Brief crossings are ignored; sustained changes are accepted; and the accepted level does not chatter in the hysteresis band.

---

### C4: Turn cover durations into events

**TODOs:** `C3a-C3d`, `C10a-C10b`, `C11`

**Goal:** Convert accepted cover edges and durations into one-time `TAP`, `COMMIT`, and `CANCEL`
events.

**Work**

1. Complete `C3a-C3d` with the tap interval, commit lower bound, and held-cover cancel time.
2. Complete `C10a` so a completed cover in the half-open tap interval emits `TAP`.
3. Complete `C10b` so a completed cover in the commit interval below cancel emits `COMMIT`.
4. Complete `C11` so an ongoing hold emits `CANCEL` once when it reaches `cancelMinimumMs`.
5. Leave a dead band between tap and commit. Tap and commit are classified after release because
   their completed duration is then known. Cancel fires while still covered, and `cancelEmitted`
   prevents another event from the same hold.

**Evidence:** Under **Design Decisions** in the README, record the chosen intervals and the result just below, at, and just above each boundary. Retain a Serial trace showing one event for a held cancel and no event on its release.

**Complete when:** The board prints the correct event at each tested boundary, and one physical gesture produces at most one event.

---

### C5: Implement the timer FSM

**TODOs:** `C4a-C4c`, `F1a-F4b`

**Goal:** Derive and implement the complete timer finite-state machine from the behavioral
requirements.

**Work**

1. Draw the timer FSM from R1-R6 before editing `updateTimer()`. Include `STANDBY`, `ADDING`,
   `COUNTDOWN`, and `DONE`; every event and elapsed-time transition; both cancel paths; and return
   from `DONE`. Keep it distinct from the calibration FSM required in C2, using two clearly
   labeled regions in the same submitted diagram.
2. Complete `C4a-C4c` with the entry-tap window, seconds per tap, and DONE-alert duration.
3. Complete `F1a-F1c` for entry timeout, required tap count, and entry into `ADDING`.
4. Complete `F2a-F2e` for cancel, saturating time addition, millisecond conversion, and entry into
   `COUNTDOWN`.
5. Complete `F3a-F3e` for cancel, completion, entry into `DONE`, and remaining whole seconds.
6. Complete `F4a-F4b` for DONE timeout and restoration of the full `STANDBY` invariant.
7. Treat events as inputs, not states. Calculate elapsed time from the stored start time. Use
   `uint64_t` for intermediate addition and conversion, then limit accumulated seconds to the
   supplied `MAX_COUNTDOWN_SECONDS` before storing either representation. Use the supplied complete
   reset helper when returning to `STANDBY`.

**Evidence:** Include your FSM diagram in the final package. Retain a Serial trace covering three-tap entry, slow-entry timeout, addition, commit, countdown, DONE, and both cancel paths.

**Complete when:** The hardware trace follows the diagram for every required path.

---

### C6: Integrate, recalibrate, and collect evidence

**Milestone:** full-system validation

**Goal:** Validate that calibration, event extraction, the timer FSM, and outputs operate together
across different lighting conditions.

**Work**

1. Run the complete timer repeatedly before recording evidence.
2. Confirm that the calibration cover does not become a gesture.
3. Confirm that every mode has the required LED output and that Serial reports the expected event
   before each transition.
4. Confirm that the countdown calculates time from `millis()`.
5. Reset in a second lighting environment whose observed uncovered range does not overlap the first,
   and repeat without editing or uploading the program.

**Evidence:** Retain the required GIFs, matching Serial excerpts, both calibration reference pairs, and the complete timer sequence described in the Challenge bench procedure.

**Complete when:** The same firmware calibrates successfully in both lighting conditions, and every recorded event, state, timer value, and LED output agrees.

---

### Challenge write-up questions

Answer these questions under **Design Decisions** in your README. They cover mechanisms supplied
to support your implementation; the TODO blocks remain your own work.

1. What problems do the supplied `elapsedMs()` and `clamp01()` helpers prevent? Give one input
   example for each helper where using the raw value directly would be unsafe or misleading.
2. `enterCalibrationPhase()` resets the phase timer, candidate history, sample sum, and sample
   count. Explain why retaining any one of those values could corrupt the next phase. Then trace
   the supplied `CAL_PHASE_ERROR` branch: state what makes it call `beginCalibration()`, what that
   call clears, and why the user must uncover before the new ambient capture.
3. When calibration becomes ready, `Challenge_1.ino` resets the covered detector, cover tracker,
   and timer. Explain how these resets prevent the calibration cover from becoming the first timer
   gesture.
4. In the supplied portion of `updateCoveredDetector()`, `coveredStateRequestedByScore` begins at
   the accepted level. Describe the score regions that request an enter, request a release, or
   preserve the current level. Explain how this creates hysteresis.
5. Why does `CoverTracker` need `cancelEmitted` in addition to `wasCovered` and `coverStartedMs`?
   What incorrect event could occur on release if this field were omitted?
6. `clearTimerForStandby()` resets more than `mode`. Name the state history it clears and explain
   why the `default` branch of `updateTimer()` uses this complete reset.

### Required reasoning question

Answer this question under **Design Decisions** in your README:

The required implementation stops updating its calibration after startup. Design an alternative
that updates its ambient-light baseline during normal operation. Explain when the baseline can
update, when it must remain fixed, how its update rate compares with the duration of a tap, and how
the controller recovers after an abrupt lighting change. You do not need to implement this design.

### Challenge bench procedure

1. Leave the Lab pushbutton connected from GPIO5 to GND. Connect the LDR divider midpoint to A0,
   and connect the three LED branches to GPIO2, GPIO3, and GPIO4. The Lab uses the first two LEDs.
   The Challenge uses all three LEDs and ignores GPIO5.
2. Start the board with the sensor uncovered. Confirm the steady-on, blinking, all-off, and
   green-ready calibration sequence. Confirm that Serial reports distinct reference values and an
   acceptable span.
3. After the device enters `STANDBY`, confirm that the calibration cover has not emitted a tap or
   cancel event.
4. From `STANDBY`, make two quick taps. Confirm that the device remains in `STANDBY`. Make the third
   tap, and confirm that the device enters `ADDING`.
5. In `ADDING`, make one tap. Confirm that it adds exactly one unit. Make a commit gesture, and
   confirm that the device enters `COUNTDOWN`.
6. Confirm that Serial reports the countdown in real time. Confirm that zero enters `DONE` and that
   the alert returns the device to `STANDBY` after approximately two seconds.
7. From `ADDING`, make a cancel-length cover and confirm the return to `STANDBY`. Repeat from
   `COUNTDOWN`.
8. Change the ambient lighting enough that the uncovered raw ranges from the two five-second ambient
   captures do not overlap. Reset the board without uploading, repeat calibration and the entry
   taps, and capture both lighting conditions in `adaptive_calibration.gif`.
9. Run the complete timer sequence at least twice before recording the remaining GIFs.

## Submission and assessment

### Required deliverables

- `Arduino/Lab_1/a1_lab_logic.cpp`: Complete all Lab TODOs. Keep `Lab_1.ino` and
  `a1_lab_logic.h` unchanged.
- `Arduino/Challenge_1/a1_timer_logic.cpp`: Complete all Challenge TODOs. Keep `Challenge_1.ino`
  and `a1_timer_logic.h` unchanged.
- `Documentation/Fig/fsm_diagram.png`: Provide one figure with clearly labeled calibration and
  timer FSM regions, and embed it with a caption in the README. The calibration region must include
  all six phases, transition conditions, state resets or captured values, returned events, and LED
  behavior. The timer region must match the submitted implementation.
- `Documentation/Fig/lab_controller.gif`: Show `OFF`, `AUTO`, and `ON`; the separate ON and AUTO
  outputs; and the AUTO output responding to changing light.
- `Documentation/Fig/adaptive_calibration.gif`: In one continuous recording, show the same
  uploaded firmware calibrating and accepting a tap in two different ambient-light conditions.
  Reset the board between conditions. Do not edit, recompile, or upload the program between trials.
- `Documentation/Fig/add_then_countdown.gif`: Show `STANDBY -> ADDING -> COUNTDOWN -> DONE`.
  Include a short matching Serial excerpt in the README that shows the accumulated and remaining
  seconds.
- `Documentation/Fig/enter_then_cancel.gif`: Show a cancel from `ADDING` and a cancel from
  `COUNTDOWN`.
- `Documentation/README.md`: Use the six supplied headings. Include the two calibration result
  lines; normalized-score and timing parameters; evidence for the selected values; seconds per
  tap; the LED mapping; the cancel gesture; answers to the Lab and Challenge code-reading
  questions; the adaptation reasoning answer; the submitted file list; the hardware list; and the
  exact build procedure.

### Canvas submission

Upload one complete ZIP to the A1 assignment in Canvas. Include both Arduino projects, the README,
figures, GIFs, and all required evidence. Staff grade the code from this same package and review
the physical behavior, evidence, and written explanation.

Name the archive `A1_<student-id>.zip`, for example `A1_A12345678.zip`, and keep it under the
course's 100 MB submission limit. The ZIP root must contain `Arduino/` and `Documentation/` directly:

```text
A1_A12345678.zip
|-- Arduino/
|   |-- Lab_1/
|   `-- Challenge_1/
`-- Documentation/
    |-- README.md
    `-- Fig/              # FSM image, required GIFs, and referenced evidence images
```

You may replace the complete ZIP before the hard close. Staff use the latest eligible Canvas
submission, subject to an approved individual extension. Do not submit separate Lab and Challenge
archives. Download your submitted ZIP and confirm that it opens and contains the intended files.

Staff run behavioral tests after submission: 19 points for Lab logic and 31 for Challenge logic.
These tests evaluate the required functions; hardware checkoff and package review establish the
wiring, LED behavior, Serial output, and complete physical interaction. Timing deductions are
applied after grading according to the syllabus.
