# A1: Light-Controlled Timer (your submission)

v14 · 2026-09-06

This is the README STUB for your A1 submission. Replace every prompt below with
your own answer. Keep the six headings. The grader reads this file alongside your
GIFs, so be specific: state your actual numbers and your actual gesture design.

## Overview

> What does your timer do, in three or four sentences? Describe the startup
> CALIBRATING path and the four application modes (STANDBY, ADDING, COUNTDOWN,
> DONE). In one line each, name the light gesture that drives each application
> transition. Say which structured-lab mechanic you reused for what.

## Files

> List the files you are submitting and one line on what each contains
> (the two complete Arduino starter projects, this README, and your Fig/ images
> and GIFs). Keep each supplied `.ino` and `.h` beside the `.cpp` you completed
> so both Arduino projects compile independently.

## Hardware

> List your parts and your exact pin map (LDR divider midpoint -> which ADC pin;
> each mode LED -> which GPIO and through what resistor). State each LED color and
> the series resistor you sized for it, and
> show your reasoning with R = (Vsupply - Vf) / I_target. Also record the Lab pushbutton
> from GPIO5 to GND and note that it may remain wired because the Challenge uses GPIO2/3/4.
> Identify GPIO2 as the Lab ON output and GPIO3 as the Lab AUTO/PWM output.
> Reference your Fig images.

## Design Decisions

> This is the graded core. Include the successful Serial calibration result from
> each of your two lighting trials: uncovered reference, covered reference, span,
> and derived raw diagnostic boundaries. Also record the minimum and maximum raw
> readings from each five-second uncovered capture and show that the two observed
> ranges do not overlap. Then state each normalized or temporal
> decision parameter with a one-line reason supported by YOUR trials:
> - Lab bright and dark references returned by `makeLabConfig()`
> - units per tap (how many seconds each accepted tap adds)
> - normalized cover-enter and cover-release scores, including why their separation
>   creates hysteresis
> - minimum accepted calibration span and stable-time requirements
> - tap window (min/max cover ms that counts as a tap)
> - commit cover time (how long a cover starts the countdown)
> - cancel cover time (how long a cover cancels; explain why it cannot be confused
>   with a commit -- the dead band / ordering that makes the gesture unambiguous)
> Document the calibration LED sequence and color-to-mode mapping. Explain why the supplied
> error branch clears the old capture state, why the sensor must be uncovered during its fixed
> 1200 ms indication, and how that branch appears in your calibration FSM. Explain your
> CANCEL gesture, its FSM transition, and why it is unambiguous. Finally answer the
> six Lab code-reading questions and six Challenge code-reading questions from the
> handout. Use short numbered answers that refer to the named fields, branches, and
> functions. Finish with the required reasoning question about continuous ambient
> adaptation without an explicit calibration state.

## Figures

> Embed your FSM diagram and your four required GIFs, each with a one-line caption:
> - `Fig/fsm_diagram.png`, one figure with two clearly labeled regions: the six-phase calibration
>   FSM (conditions, captures/resets, returned events, and LED behavior) and your timer FSM
>   (states, events, transitions, and both cancel paths)
> - lab_controller.gif (OFF/AUTO/ON, separate ON and AUTO outputs, and visible AUTO response)
> - adaptive_calibration.gif (same binary calibrating and accepting a tap in two
>   lighting conditions whose observed uncovered ranges do not overlap)
> - add_then_countdown.gif (happy path: standby -> adding -> countdown -> done)
> - enter_then_cancel.gif (cancel from both ADDING and COUNTDOWN)
> Beneath the adaptive GIF, include both calibration result lines. Beneath the
> happy-path GIF, include a short Serial excerpt showing seconds accumulating and
> then counting down.
> Put the image files in Documentation/Fig/.

## Build

> State how to compile and flash: the board package and FQBN, and the exact
> arduino-cli command you used per sketch. Confirm
> both sketches compile for esp32:esp32:XIAO_ESP32S3.
