// Challenge_1.ino
// v13 - 2026-09-06
//
// Challenge 1 -- Adaptive Light-Controlled Timer.
//
// This supplied integration sketch must remain unchanged. Complete the
// calibration, detection, gesture, and timer logic in a1_timer_logic.cpp.

#include "a1_timer_logic.h"

#define LDR_PIN                 A0
#define LED_STANDBY             2
#define LED_ADDING              3
#define LED_COUNTDOWN           4

#define CAL_BLINK_MS            250UL
#define CAL_ERROR_BLINK_MS      100UL
#define FLASH_MS                120UL
#define ALERT_BLINK_MS          200UL
#define SAMPLE_MS               5UL
#define DIAGNOSTIC_REPORT_MS    250UL
#define SERIAL_BAUD             115200

const char *const CALIBRATION_PHASE_NAMES[] = {
    "AMBIENT", "WAIT_COVER", "CAPTURE_COVERED", "WAIT_RELEASE", "ERROR", "READY"};
const char *const TIMER_MODE_NAMES[] = {"STANDBY", "ADDING", "COUNTDOWN", "DONE"};
const char *const COVER_EVENT_NAMES[] = {"NONE", "TAP", "COMMIT", "CANCEL"};

const a1::CalibrationConfig calibrationConfiguration = a1::makeCalibrationConfig();
const a1::CoverDecisionConfig coverDecisionConfiguration = a1::makeCoverDecisionConfig();
const a1::GestureConfig gestureConfiguration = a1::makeGestureConfig();
const a1::TimerConfig timerConfiguration = a1::makeTimerConfig();

a1::CalibrationState calibrationState;
a1::CoveredDetector coveredDetectorState;
a1::CoverTracker coverTrackerState;
a1::TimerState timerState;

uint32_t lastSensorSampleMs = 0;
uint32_t lastDiagnosticReportMs = 0;
uint32_t tapFlashStartedMs = 0;
bool tapFlashIsActive = false;
bool serialOutputWasAvailable = false;

a1::CalibrationPhase lastReportedCalibrationPhase = (a1::CalibrationPhase)255;
a1::TimerMode lastReportedTimerMode = (a1::TimerMode)255;
uint32_t lastReportedSeconds = UINT32_MAX;

void setEveryLed(bool isOn);
void updateLedOutputs(uint32_t currentTimeMs);
bool serialOutputIsAvailable();
void serviceSerialOutput(uint32_t currentTimeMs);
void reportCalibrationPhaseChange();
void reportCalibrationResult();
void reportTimerStateChange(uint32_t currentTimeMs);

/*
 * setup()
 *
 * Initializes the board and gives every software state a known starting value.
 */
void setup() {
  Serial.begin(SERIAL_BAUD);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial.setTxTimeoutMs(0);
#endif
  analogReadResolution(12);

  pinMode(LDR_PIN,INPUT);
  pinMode(LED_STANDBY,OUTPUT);
  pinMode(LED_ADDING,OUTPUT);
  pinMode(LED_COUNTDOWN,OUTPUT);

  uint32_t setupTimeMs = millis();
  a1::beginCalibration(&calibrationState,setupTimeMs);
  a1::resetCoveredDetector(&coveredDetectorState,false,setupTimeMs);
  a1::resetCoverTracker(&coverTrackerState,false,setupTimeMs);
  a1::resetTimer(&timerState,setupTimeMs);
  lastSensorSampleMs = setupTimeMs;
  lastDiagnosticReportMs = setupTimeMs;

  serviceSerialOutput(setupTimeMs);
}

/*
 * loop()
 *
 * Runs calibration first, then converts each raw sample into an event and FSM update.
 */
void loop() {
  uint32_t currentTimeMs = millis();
  updateLedOutputs(currentTimeMs);
  serviceSerialOutput(currentTimeMs);

  if ((uint32_t)(currentTimeMs - lastSensorSampleMs) < SAMPLE_MS) return;
  lastSensorSampleMs = currentTimeMs;
  int currentLightReading = analogRead(LDR_PIN);
  bool diagnosticReportIsDue = (uint32_t)(currentTimeMs - lastDiagnosticReportMs) >= DIAGNOSTIC_REPORT_MS;
  if (diagnosticReportIsDue) lastDiagnosticReportMs = currentTimeMs;

  // Calibration owns the sensor until it captures valid references and a stable release.
  if (calibrationState.phase != a1::CAL_PHASE_READY) {
    a1::CalibrationEvent calibrationEvent = a1::updateCalibration(&calibrationState,currentLightReading,currentTimeMs,calibrationConfiguration);
    reportCalibrationPhaseChange();
    if (diagnosticReportIsDue && serialOutputIsAvailable()) {
      Serial.printf("calibration phase=%s raw=%d\n",CALIBRATION_PHASE_NAMES[calibrationState.phase],currentLightReading);
    }

    if (calibrationEvent == a1::CAL_EVENT_READY) {
      a1::resetCoveredDetector(&coveredDetectorState,false,currentTimeMs);
      a1::resetCoverTracker(&coverTrackerState,false,currentTimeMs);
      a1::resetTimer(&timerState,currentTimeMs);
      reportCalibrationResult();
      reportTimerStateChange(currentTimeMs);
    }
    return;
  }

  // Normal operation: raw ADC -> normalized score -> stable level -> event -> FSM state.
  float currentNormalizedCoverScore = a1::normalizedCoverScore(currentLightReading,calibrationState.uncoveredReference,calibrationState.coveredReference);
  bool currentStableCoveredState = a1::updateCoveredDetector(&coveredDetectorState,currentNormalizedCoverScore,currentTimeMs,coverDecisionConfiguration.enterScore,coverDecisionConfiguration.releaseScore,coverDecisionConfiguration.stableMs);
  a1::CoverEvent currentCoverEvent = a1::updateCoverTracker(&coverTrackerState,currentStableCoveredState,currentTimeMs,gestureConfiguration);
  if (diagnosticReportIsDue && serialOutputIsAvailable()) {
    Serial.printf("sensor raw=%d score=%.2f covered=%d\n",currentLightReading,currentNormalizedCoverScore,currentStableCoveredState);
  }
  if (currentCoverEvent != a1::COVER_EVENT_NONE && serialOutputIsAvailable()) {
    Serial.printf("event=%s\n",COVER_EVENT_NAMES[currentCoverEvent]);
  }

  a1::TimerMode timerModeBeforeUpdate = timerState.mode;
  a1::updateTimer(&timerState,currentCoverEvent,currentTimeMs,timerConfiguration);

  if (currentCoverEvent == a1::COVER_EVENT_TAP && (timerModeBeforeUpdate == a1::TIMER_ADDING || timerState.mode == a1::TIMER_ADDING)) {
    tapFlashStartedMs = currentTimeMs;
    tapFlashIsActive = true;
  }

  reportTimerStateChange(currentTimeMs);
}

/*
 * setEveryLed()
 *
 * Drives all three mode LEDs to the same level for shared visual patterns.
 */
void setEveryLed(bool isOn) {
  digitalWrite(LED_STANDBY,isOn);
  digitalWrite(LED_ADDING,isOn);
  digitalWrite(LED_COUNTDOWN,isOn);
}

/*
 * updateLedOutputs()
 *
 * Converts calibration or timer state into nonblocking LED feedback.
 */
void updateLedOutputs(uint32_t currentTimeMs) {
  if (calibrationState.phase != a1::CAL_PHASE_READY) {
    switch (calibrationState.phase) {
      case a1::CAL_PHASE_AMBIENT:
        setEveryLed(true);
        break;

      case a1::CAL_PHASE_WAIT_COVER:
      case a1::CAL_PHASE_CAPTURE_COVERED:
        setEveryLed(((currentTimeMs - calibrationState.phaseStartMs) / CAL_BLINK_MS) % 2 == 0);
        break;

      case a1::CAL_PHASE_WAIT_RELEASE:
        setEveryLed(false);
        break;

      case a1::CAL_PHASE_ERROR:
        setEveryLed(((currentTimeMs - calibrationState.phaseStartMs) / CAL_ERROR_BLINK_MS) % 2 == 0);
        break;

      default:
        setEveryLed(false);
        break;
    }
    return;
  }

  if (timerState.mode == a1::TIMER_DONE) {
    setEveryLed(((currentTimeMs - timerState.doneStartMs) / ALERT_BLINK_MS) % 2 == 0);
    return;
  }

  if (tapFlashIsActive && (uint32_t)(currentTimeMs - tapFlashStartedMs) < FLASH_MS) {
    setEveryLed(true);
    return;
  }

  tapFlashIsActive = false;
  digitalWrite(LED_STANDBY,timerState.mode == a1::TIMER_STANDBY);
  digitalWrite(LED_ADDING,timerState.mode == a1::TIMER_ADDING);
  digitalWrite(LED_COUNTDOWN,timerState.mode == a1::TIMER_COUNTDOWN);
}

/*
 * serialOutputIsAvailable()
 *
 * Reports whether the current Serial transport can accept diagnostic output.
 */
bool serialOutputIsAvailable() {
  return (bool)Serial;
}

/*
 * serviceSerialOutput()
 *
 * Detects a newly connected monitor and reports the current state once.
 */
void serviceSerialOutput(uint32_t currentTimeMs) {
  bool serialOutputIsAvailableNow = serialOutputIsAvailable();
  if (!serialOutputIsAvailableNow) {
    serialOutputWasAvailable = false;
    return;
  }

  if (serialOutputWasAvailable) return;
  serialOutputWasAvailable = true;

  Serial.println("Challenge_1: adaptive light-controlled timer");
  lastReportedCalibrationPhase = (a1::CalibrationPhase)255;
  lastReportedTimerMode = (a1::TimerMode)255;
  lastReportedSeconds = UINT32_MAX;
  reportCalibrationPhaseChange();

  if (calibrationState.phase == a1::CAL_PHASE_READY) {
    reportCalibrationResult();
    reportTimerStateChange(currentTimeMs);
  }
}

/*
 * reportCalibrationPhaseChange()
 *
 * Reports a calibration phase only when it changes.
 */
void reportCalibrationPhaseChange() {
  if (!serialOutputIsAvailable()) return;
  if (lastReportedCalibrationPhase == calibrationState.phase) return;
  lastReportedCalibrationPhase = calibrationState.phase;
  Serial.printf("calibration -> %s\n",CALIBRATION_PHASE_NAMES[calibrationState.phase]);
}

/*
 * reportCalibrationResult()
 *
 * Reports the measured references, span, and implied raw ADC boundaries.
 */
void reportCalibrationResult() {
  if (!serialOutputIsAvailable()) return;
  int calibrationSpan = calibrationState.uncoveredReference - calibrationState.coveredReference;
  float rawCoverEnterThreshold = a1::rawReadingAtScore(calibrationState.uncoveredReference,calibrationState.coveredReference,coverDecisionConfiguration.enterScore);
  float rawCoverReleaseThreshold = a1::rawReadingAtScore(calibrationState.uncoveredReference,calibrationState.coveredReference,coverDecisionConfiguration.releaseScore);
  Serial.printf("calibration uncovered=%d covered=%d span=%d enter_raw=%.1f release_raw=%.1f\n",calibrationState.uncoveredReference,calibrationState.coveredReference,calibrationSpan,rawCoverEnterThreshold,rawCoverReleaseThreshold);
}

/*
 * reportTimerStateChange()
 *
 * Reports timer mode or visible seconds only when either value changes.
 */
void reportTimerStateChange(uint32_t currentTimeMs) {
  if (!serialOutputIsAvailable()) return;
  bool timerModeDisplaysSeconds = timerState.mode == a1::TIMER_ADDING || timerState.mode == a1::TIMER_COUNTDOWN;
  uint32_t currentlyVisibleSeconds = timerModeDisplaysSeconds ? timerState.remainingSeconds : 0;
  if (lastReportedTimerMode == timerState.mode && lastReportedSeconds == currentlyVisibleSeconds) return;

  lastReportedTimerMode = timerState.mode;
  lastReportedSeconds = currentlyVisibleSeconds;

  if (timerModeDisplaysSeconds) {
    Serial.printf("status_ms=%u mode=%s seconds=%u\n",currentTimeMs,TIMER_MODE_NAMES[timerState.mode],currentlyVisibleSeconds);
  } else {
    Serial.printf("status_ms=%u mode=%s\n",currentTimeMs,TIMER_MODE_NAMES[timerState.mode]);
  }
}
