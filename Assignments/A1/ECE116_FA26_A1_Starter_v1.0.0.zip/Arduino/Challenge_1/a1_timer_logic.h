#ifndef A1_TIMER_LOGIC_H
#define A1_TIMER_LOGIC_H

#include <stdint.h>

namespace a1 {

enum CalibrationPhase {
  CAL_PHASE_AMBIENT = 0,    // Capture the uncovered ambient-light reference.
  CAL_PHASE_WAIT_COVER,     // Wait for a stable request to cover the sensor.
  CAL_PHASE_CAPTURE_COVERED, // Capture the covered light reference.
  CAL_PHASE_WAIT_RELEASE,   // Wait for a stable release after covered capture.
  CAL_PHASE_ERROR,          // Display an invalid-calibration indication.
  CAL_PHASE_READY           // Calibration is valid and normal operation may begin.
};

enum CalibrationEvent {
  CAL_EVENT_NONE = 0,             // No externally visible milestone occurred.
  CAL_EVENT_AMBIENT_CAPTURED,     // The uncovered reference was accepted.
  CAL_EVENT_COVER_CAPTURE_STARTED, // Stable cover was accepted; capture began.
  CAL_EVENT_INVALID,              // The two captured references were not usable.
  CAL_EVENT_RESTARTED,            // Error display ended and calibration restarted.
  CAL_EVENT_READY                 // Stable release completed calibration.
};

struct CalibrationConfig {
  uint32_t ambientCaptureMs;   // Duration of the uncovered-reference average, in ms.
  uint32_t coverCaptureMs;     // Duration of the covered-reference average, in ms.
  uint32_t triggerStableMs;    // Continuous cover-request time required to begin capture.
  uint32_t releaseStableMs;    // Continuous released time required to finish calibration.
  uint32_t errorDisplayMs;     // Course-supplied time in CAL_PHASE_ERROR before restarting.
  float triggerDropFraction;   // Minimum (uncovered - reading) / uncovered value that requests cover.
  float releaseScore;          // Largest normalized score in [0, 1] considered released.
  int minimumSpan;             // Minimum uncovered-minus-covered separation, in ADC counts.
};

/*
 * makeCalibrationConfig()
 *
 * Returns the required and trial-supported startup-calibration parameters.
 */
CalibrationConfig makeCalibrationConfig();

struct CalibrationState {
  CalibrationPhase phase;      // Current calibration phase.
  uint32_t phaseStartMs;       // millis() timestamp when the current phase began.
  uint64_t sampleSum;          // Sum of ADC samples in the current capture window.
  uint32_t sampleCount;        // Number of samples represented by sampleSum.
  int uncoveredReference;      // Accepted average ADC reading with the sensor uncovered.
  int coveredReference;        // Accepted average ADC reading with the sensor covered.
  bool candidateActive;        // Whether a cover or release request is being timed.
  uint32_t candidateSinceMs;   // millis() timestamp when that request became continuous.
};

/*
 * calibrationReferencesValid()
 *
 * Checks whether two measured calibration references are usable.
 *
 * Parameters:
 *   uncoveredReference: Average raw ADC reading with the sensor uncovered.
 *   coveredReference: Average raw ADC reading with the sensor covered.
 *   minimumSpan: Smallest accepted uncovered-minus-covered difference, in ADC
 *     counts.
 *
 * Returns:
 *   true only when uncoveredReference is greater than coveredReference and
 *   their difference is at least minimumSpan.
 */
bool calibrationReferencesValid(int uncoveredReference,
                                int coveredReference,
                                int minimumSpan);

/*
 * normalizedCoverScore()
 *
 * Maps one raw ADC reading to a normalized cover score.
 *
 * Parameters:
 *   reading: Current raw ADC sample.
 *   uncoveredReference: Raw value represented by score 0.
 *   coveredReference: Raw value represented by score 1.
 *
 * Returns:
 *   A value clamped to [0, 1], where 0 means uncovered and 1 means covered.
 *   Returns 0 when the reference ordering is invalid or equal.
 */
float normalizedCoverScore(int reading,
                           int uncoveredReference,
                           int coveredReference);

/*
 * rawReadingAtScore()
 *
 * Converts a normalized cover score back to a raw ADC boundary for diagnostics.
 *
 * Parameters:
 *   uncoveredReference: Raw value represented by score 0.
 *   coveredReference: Raw value represented by score 1.
 *   score: Normalized boundary to convert; values outside [0, 1] are clamped.
 *
 * Returns:
 *   The linearly interpolated raw ADC boundary as a float.
 */
float rawReadingAtScore(int uncoveredReference,
                        int coveredReference,
                        float score);

/*
 * beginCalibration()
 *
 * Resets every calibration field and starts uncovered capture.
 *
 * Parameters:
 *   state: Calibration state to initialize. A null pointer is ignored.
 *   nowMs: Current time in milliseconds; becomes the ambient-phase start time.
 */
void beginCalibration(CalibrationState *state, uint32_t nowMs);

/*
 * updateCalibration()
 *
 * Advances one ADC sample through the startup-calibration state machine.
 *
 * Parameters:
 *   state: Persistent calibration state from the previous sample.
 *   reading: Current raw ADC sample. A capture includes the sample that reaches
 *     its configured duration.
 *   nowMs: Current time in milliseconds.
 *   config: Calibration durations, trigger threshold, release threshold, and
 *     minimum valid reference span.
 *
 * Returns:
 *   The milestone reached on this sample, or CAL_EVENT_NONE. Cover and release
 *   requests must remain continuous for their configured stable times. Invalid
 *   references enter CAL_PHASE_ERROR and restart after errorDisplayMs. A null
 *   state pointer returns CAL_EVENT_NONE.
 */
CalibrationEvent updateCalibration(CalibrationState *state,
                                   int reading,
                                   uint32_t nowMs,
                                   const CalibrationConfig &config);

struct CoveredDetector {
  bool covered;              // Currently accepted covered level.
  bool candidate;            // Pending level being tested for temporal stability.
  uint32_t candidateSinceMs; // millis() timestamp when candidate first appeared.
};

struct CoverDecisionConfig {
  float enterScore;    // Score in [0, 1] at or above which uncovered may become covered.
  float releaseScore;  // Score in [0, 1] at or below which covered may become uncovered.
  uint32_t stableMs;   // Continuous request time required before either change.
};

/*
 * makeCoverDecisionConfig()
 *
 * Returns normalized cover thresholds and the temporal qualification interval.
 * enterScore must be greater than releaseScore to create hysteresis.
 */
CoverDecisionConfig makeCoverDecisionConfig();

/*
 * resetCoveredDetector()
 *
 * Initializes the accepted and candidate covered levels without emitting an edge.
 *
 * Parameters:
 *   state: Covered-detector state to initialize. A null pointer is ignored.
 *   initiallyCovered: Initial accepted and candidate level.
 *   nowMs: Current time in milliseconds; becomes the candidate timestamp.
 */
void resetCoveredDetector(CoveredDetector *state,
                          bool initiallyCovered,
                          uint32_t nowMs);

/*
 * updateCoveredDetector()
 *
 * Applies hysteresis and temporal qualification to one normalized score.
 *
 * Parameters:
 *   state: Persistent detector state from the previous score.
 *   score: Current normalized cover score in [0, 1].
 *   nowMs: Current time in milliseconds.
 *   enterScore: Minimum score that requests a change from uncovered to covered.
 *   releaseScore: Maximum score that requests a change from covered to uncovered.
 *   stableMs: Minimum milliseconds that a requested level must remain unchanged
 *     before it becomes the accepted covered level.
 *
 * Returns:
 *   The accepted covered level after this update. A null state returns false.
 */
bool updateCoveredDetector(CoveredDetector *state,
                           float score,
                           uint32_t nowMs,
                           float enterScore,
                           float releaseScore,
                           uint32_t stableMs);

enum CoverEvent {
  COVER_EVENT_NONE = 0,  // No completed or held gesture became an event.
  COVER_EVENT_TAP,       // A completed brief cover fell in the tap interval.
  COVER_EVENT_COMMIT,    // A completed cover fell in the commit interval.
  COVER_EVENT_CANCEL     // A held cover reached the cancel threshold.
};

struct GestureConfig {
  uint32_t tapMinimumMs;    // Inclusive lower duration for a completed tap.
  uint32_t tapMaximumMs;    // Exclusive upper duration for a completed tap.
  uint32_t commitMinimumMs; // Inclusive lower duration for a completed commit.
  uint32_t cancelMinimumMs; // Cancel fires when a held cover reaches this duration.
};

/*
 * makeGestureConfig()
 *
 * Returns nonoverlapping tap, commit, and cancel timing parameters.
 */
GestureConfig makeGestureConfig();

/*
 * classifyCompletedCover()
 *
 * Classifies the duration of one completed cover.
 *
 * Parameters:
 *   durationMs: Milliseconds from accepted cover start to accepted release.
 *   config: Tap, commit, and cancel duration boundaries.
 *
 * Returns:
 *   TAP for [tapMinimumMs, tapMaximumMs), COMMIT for
 *   [commitMinimumMs, cancelMinimumMs), and NONE for every other completed
 *   duration. CANCEL is emitted while held by updateCoverTracker().
 */
CoverEvent classifyCompletedCover(uint32_t durationMs,
                                  const GestureConfig &config);

struct CoverTracker {
  bool wasCovered;          // Accepted covered level seen on the previous update.
  uint32_t coverStartedMs;  // millis() timestamp when the current cover began.
  bool cancelEmitted;       // Whether the current hold already emitted CANCEL.
};

/*
 * resetCoverTracker()
 *
 * Initializes cover-edge and held-gesture history without emitting an event.
 *
 * Parameters:
 *   state: Cover-tracker state to initialize. A null pointer is ignored.
 *   initiallyCovered: Accepted cover level at initialization.
 *   nowMs: Current time in milliseconds; becomes the initial cover timestamp.
 */
void resetCoverTracker(CoverTracker *state,
                       bool initiallyCovered,
                       uint32_t nowMs);

/*
 * updateCoverTracker()
 *
 * Converts accepted cover levels into tap, commit, and fire-once cancel events.
 *
 * Parameters:
 *   state: Persistent edge and gesture history from the previous update.
 *   covered: Current accepted output of updateCoveredDetector().
 *   nowMs: Current time in milliseconds.
 *   config: Duration boundaries used to classify or cancel the gesture.
 *
 * Returns:
 *   At most one CoverEvent for this update. A cancel fires once as soon as the
 *   held duration reaches cancelMinimumMs. Releasing after a cancel emits no
 *   second event. A null state returns COVER_EVENT_NONE.
 */
CoverEvent updateCoverTracker(CoverTracker *state,
                              bool covered,
                              uint32_t nowMs,
                              const GestureConfig &config);

enum TimerMode {
  TIMER_STANDBY = 0,  // Wait for the required quick-tap entry sequence.
  TIMER_ADDING,       // Accumulate time units and wait for commit or cancel.
  TIMER_COUNTDOWN,    // Update remaining time from elapsed milliseconds.
  TIMER_DONE          // Display the completion alert before returning to standby.
};

struct TimerConfig {
  uint32_t entryTapWindowMs;   // Maximum allowed gap between entry taps, inclusive.
  uint32_t unitsPerTapSeconds; // Seconds seeded or added by one accepted tap.
  uint32_t doneAlertMs;        // Duration of the TIMER_DONE indication.
  uint8_t entryTapsRequired;   // Number of quick taps required to enter ADDING.
};

/*
 * makeTimerConfig()
 *
 * Returns the required entry count and selected timer timing parameters.
 */
TimerConfig makeTimerConfig();

struct TimerState {
  TimerMode mode;                 // Current observable application mode.
  uint8_t entryTapCount;          // Quick taps accepted in the current entry attempt.
  uint32_t lastEntryTapMs;        // millis() timestamp of the most recent entry tap.
  uint32_t remainingSeconds;      // Accumulated or rounded-up seconds, limited so milliseconds remain representable.
  uint32_t countdownStartMs;      // millis() timestamp when COUNTDOWN began.
  uint32_t countdownDurationMs;   // Fixed total countdown duration chosen at commit.
  uint32_t doneStartMs;           // millis() timestamp when TIMER_DONE began.
};

/*
 * resetTimer()
 *
 * Restores all application fields to the complete STANDBY invariant.
 *
 * Parameters:
 *   state: Timer state to initialize. A null pointer is ignored.
 *   nowMs: Current time in milliseconds; initializes all timer timestamps.
 */
void resetTimer(TimerState *state, uint32_t nowMs);

/*
 * updateTimer()
 *
 * Applies one gesture event and one elapsed-time update to the application FSM.
 *
 * Parameters:
 *   state: Persistent timer state from the previous update.
 *   event: Newly extracted cover event, or COVER_EVENT_NONE.
 *   nowMs: Current time in milliseconds.
 *   config: Entry-window, time-unit, DONE-duration, and required-tap settings.
 *
 * Effects:
 *   Updates the state fields required by R1-R6. Relative-time behavior must
 *   remain correct across uint32_t millis() rollover. An invalid mode recovers
 *   to the complete STANDBY invariant. A null state pointer is ignored.
 */
void updateTimer(TimerState *state,
                 CoverEvent event,
                 uint32_t nowMs,
                 const TimerConfig &config);

}  // namespace a1

#endif
