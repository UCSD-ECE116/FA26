#include "a1_timer_logic.h"

#include <limits.h>

namespace a1 {
namespace {

/*
 * elapsedMs()
 *
 * Returns elapsed milliseconds using unsigned arithmetic so rollover is safe.
 */
uint32_t elapsedMs(uint32_t nowMs, uint32_t sinceMs) {
  return nowMs - sinceMs;  // Unsigned subtraction also works across millis() rollover.
}

/*
 * clamp01()
 *
 * Restricts a normalized value to the inclusive range [0, 1].
 */
float clamp01(float value) {
  if (value < 0.0f) return 0.0f;  // Prevents scores below the uncovered endpoint.
  if (value > 1.0f) return 1.0f;  // Prevents scores above the covered endpoint.
  return value;                   // Preserves values already inside the valid range.
}

const uint32_t MAX_COUNTDOWN_SECONDS = UINT32_MAX / 1000U;  // Largest whole-second value representable by countdownDurationMs.

/*
 * resetCapture()
 *
 * Clears the running sum and count used by one calibration capture phase.
 */
void resetCapture(CalibrationState *state) {
  state->sampleSum = 0;    // Removes samples accumulated during an earlier phase.
  state->sampleCount = 0;  // Marks the new capture window as empty.
}

/*
 * enterCalibrationPhase()
 *
 * Enters one calibration phase with a fresh phase timer and capture window.
 */
void enterCalibrationPhase(CalibrationState *state,
                           CalibrationPhase phase,
                           uint32_t nowMs) {
  state->phase = phase;             // Records the newly entered phase.
  state->phaseStartMs = nowMs;      // Starts this phase's elapsed-time measurement.
  state->candidateActive = false;   // Discards a cover or release request from the old phase.
  state->candidateSinceMs = nowMs;  // Gives future candidate timing a known initial value.
  resetCapture(state);              // Prevents samples from crossing phase boundaries.
}

/*
 * captureAverage()
 *
 * Returns the integer average of the samples collected in the current phase.
 */
int captureAverage(const CalibrationState *state) {
  if (state->sampleCount == 0) return 0;                // Avoids division by zero for an empty capture.
  return (int)(state->sampleSum / state->sampleCount);  // Computes the integer ADC average.
}

/*
 * clearTimerForStandby()
 *
 * Restores every application-state field to its STANDBY invariant.
 */
void clearTimerForStandby(TimerState *state, uint32_t nowMs) {
  state->mode = TIMER_STANDBY;      // Restores the externally visible mode.
  state->entryTapCount = 0;         // Removes an incomplete entry sequence.
  state->lastEntryTapMs = nowMs;    // Gives the next entry sequence a fresh time origin.
  state->remainingSeconds = 0;      // Removes accumulated or remaining timer value.
  state->countdownStartMs = nowMs;  // Clears the old countdown's time origin.
  state->countdownDurationMs = 0;   // Removes the committed countdown duration.
  state->doneStartMs = nowMs;       // Clears the old DONE alert's time origin.
}

}  // namespace

/*
 * makeCalibrationConfig()
 *
 * Returns the required and trial-supported startup-calibration parameters.
 */
CalibrationConfig makeCalibrationConfig() {
  CalibrationConfig config{};  // Creates the calibration settings returned to Challenge_1.ino.

  config.ambientCaptureMs = 5000;  // The specification fixes ambient capture at five seconds.
  config.coverCaptureMs = 0;       // TODO C1a: replace 0 with the covered-sample capture time.
  config.triggerStableMs = 0;      // TODO C1b: replace 0 with the cover-trigger stable time.
  config.releaseStableMs = 0;      // TODO C1c: replace 0 with the release stable time.
  config.errorDisplayMs = 1200;    // Course-supplied time for visible error feedback and uncovering.
  config.triggerDropFraction = 0;  // TODO C1d: replace 0 with the fractional drop that requests cover.
  config.releaseScore = 0;         // TODO C1e: replace 0 with the normalized release score.
  config.minimumSpan = 0;          // TODO C1f: replace 0 with the minimum valid ADC span.

  return config;  // Gives the selected calibration policy to the supplied integration sketch.
}

/*
 * makeCoverDecisionConfig()
 *
 * Returns normalized cover thresholds and the temporal qualification interval.
 * enterScore must be greater than releaseScore to create hysteresis.
 */
CoverDecisionConfig makeCoverDecisionConfig() {
  CoverDecisionConfig config{};  // Creates the normal-operation cover detector settings.

  config.enterScore = 0;    // TODO C2a: replace 0 with your normalized enter threshold.
  config.releaseScore = 0;  // TODO C2b: replace 0 with your lower release threshold.
  config.stableMs = 0;      // TODO C2c: replace 0 with your temporal qualification time.

  return config;  // Gives the selected cover-decision policy to the supplied integration sketch.
}

/*
 * makeGestureConfig()
 *
 * Returns nonoverlapping tap, commit, and cancel timing parameters.
 */
GestureConfig makeGestureConfig() {
  GestureConfig config{};  // Creates the duration boundaries used by the gesture classifier.

  config.tapMinimumMs = 0;     // TODO C3a: replace 0 with the shortest accepted tap.
  config.tapMaximumMs = 0;     // TODO C3b: replace 0 with the exclusive tap upper bound.
  config.commitMinimumMs = 0;  // TODO C3c: replace 0 with the commit lower bound.
  config.cancelMinimumMs = 0;  // TODO C3d: replace 0 with the held-cover cancel time.

  return config;  // Gives the selected gesture boundaries to the supplied integration sketch.
}

/*
 * makeTimerConfig()
 *
 * Returns the required entry count and selected timer timing parameters.
 */
TimerConfig makeTimerConfig() {
  TimerConfig config{};  // Creates the timing settings used by the application FSM.

  config.entryTapWindowMs = 0;    // TODO C4a: replace 0 with the entry-tap window.
  config.unitsPerTapSeconds = 0;  // TODO C4b: replace 0 with the seconds added by one tap.
  config.doneAlertMs = 0;         // TODO C4c: replace 0 with the DONE alert duration.
  config.entryTapsRequired = 3;   // The specification fixes entry at three quick taps.

  return config;  // Gives the selected timer policy to the supplied integration sketch.
}

/*
 * calibrationReferencesValid()
 *
 * Checks whether two measured calibration references are usable.
 *
 * Parameters:
 *   uncoveredReference: Average raw ADC reading with the sensor uncovered.
 *   coveredReference: Average raw ADC reading with the sensor covered.
 *   minimumSpan: Smallest accepted uncovered-minus-covered difference, in ADC
 *     counts.
 *
 * Returns:
 *   true only when uncoveredReference is greater than coveredReference and
 *   their difference is at least minimumSpan.
 */
bool calibrationReferencesValid(int uncoveredReference,
                                int coveredReference,
                                int minimumSpan) {
  if (uncoveredReference <= coveredReference) return false;  // Rejects reversed references.

  int uncoveredToCoveredAdcSpan = uncoveredReference - coveredReference;  // Measures separation between references.
  return false;                                                           // TODO C5: replace false with the test that accepts a sufficient ADC span.
}

/*
 * normalizedCoverScore()
 *
 * Maps one raw ADC reading to a normalized cover score.
 *
 * Parameters:
 *   reading: Current raw ADC sample.
 *   uncoveredReference: Raw value represented by score 0.
 *   coveredReference: Raw value represented by score 1.
 *
 * Returns:
 *   A value clamped to [0, 1], where 0 means uncovered and 1 means covered.
 *   Returns 0 when the reference ordering is invalid or equal.
 */
float normalizedCoverScore(int reading,
                           int uncoveredReference,
                           int coveredReference) {
  int uncoveredToCoveredAdcSpan = uncoveredReference - coveredReference;  // Measures the raw range mapped onto 0 through 1.
  if (uncoveredToCoveredAdcSpan <= 0) return 0.0f;                        // Invalid references have no score range.

  float normalizedScoreForReading = 0.0f;     // TODO C6: replace 0.0f with reading's position across the calibrated span.
  return clamp01(normalizedScoreForReading);  // Keeps results inside [0, 1].
}

/*
 * rawReadingAtScore()
 *
 * Converts a normalized cover score back to a raw ADC boundary for diagnostics.
 *
 * Parameters:
 *   uncoveredReference: Raw value represented by score 0.
 *   coveredReference: Raw value represented by score 1.
 *   score: Normalized boundary to convert; values outside [0, 1] are clamped.
 *
 * Returns:
 *   The linearly interpolated raw ADC boundary as a float.
 */
float rawReadingAtScore(int uncoveredReference,
                        int coveredReference,
                        float score) {
  float boundedNormalizedScore = clamp01(score);                          // Limits the boundary to the calibrated range.
  int uncoveredToCoveredAdcSpan = uncoveredReference - coveredReference;  // Measures the raw range represented by one score unit.

  return 0.0f;  // TODO C7: map boundedNormalizedScore back into the calibrated raw ADC range.
}

/*
 * beginCalibration()
 *
 * Resets every calibration field and starts uncovered capture.
 *
 * Parameters:
 *   state: Calibration state to initialize. A null pointer is ignored.
 *   nowMs: Current time in milliseconds; becomes the ambient-phase start time.
 */
void beginCalibration(CalibrationState *state, uint32_t nowMs) {
  if (state == nullptr) return;  // Cannot initialize missing calibration state.

  state->uncoveredReference = 0;                           // Removes the previous uncovered calibration result.
  state->coveredReference = 0;                             // Removes the previous covered calibration result.
  enterCalibrationPhase(state, CAL_PHASE_AMBIENT, nowMs);  // Begins a fresh ambient capture.
}

/*
 * updateCalibration()
 *
 * Advances one ADC sample through the startup-calibration state machine.
 *
 * Parameters:
 *   state: Persistent calibration state from the previous sample.
 *   reading: Current raw ADC sample. A capture includes the sample that reaches
 *     its configured duration.
 *   nowMs: Current time in milliseconds.
 *   config: Calibration durations, trigger threshold, release threshold, and
 *     minimum valid reference span.
 *
 * Returns:
 *   The milestone reached on this sample, or CAL_EVENT_NONE. Cover and release
 *   requests must remain continuous for their configured stable times. Invalid
 *   references enter CAL_PHASE_ERROR and restart after errorDisplayMs. A null
 *   state pointer returns CAL_EVENT_NONE.
 */
CalibrationEvent updateCalibration(CalibrationState *state,
                                   int reading,
                                   uint32_t nowMs,
                                   const CalibrationConfig &config) {
  if (state == nullptr) return CAL_EVENT_NONE;  // Cannot advance missing calibration state.

  uint32_t millisecondsInCurrentCalibrationPhase = elapsedMs(nowMs, state->phaseStartMs);  // Measures time in this phase.
  // The phase switch keeps each calibration phase's behavior separate and visible.

  switch (state->phase) {                     // Runs only the behavior owned by the active calibration phase.
    case CAL_PHASE_AMBIENT:                   // Captures the uncovered ambient reference for a fixed interval.
      state->sampleSum += (uint64_t)reading;  // Adds this uncovered sample to the average.
      state->sampleCount++;                   // Records that one more sample was captured.

      if (false) {                      // TODO C8a: compare millisecondsInCurrentCalibrationPhase with ambientCaptureMs.
        state->uncoveredReference = 0;  // TODO C8b: replace 0 with the captured average.
        // The next phase waits for the student to cover the sensor.
        enterCalibrationPhase(state, CAL_PHASE_WAIT_COVER, nowMs);  // Starts waiting for a stable cover request.
        return CAL_EVENT_AMBIENT_CAPTURED;                          // Reports completion of uncovered-reference capture.
      }
      break;  // Keeps collecting ambient samples until the interval qualifies.

    case CAL_PHASE_WAIT_COVER: {                          // Waits for a large enough reading drop to remain stable.
      float fractionalDropFromUncoveredReference = 0.0f;  // TODO C8c: calculate the drop and guard division by zero.
      bool coveredCaptureRequested = false;               // TODO C8d: compare the fractional drop with the trigger threshold.

      if (!coveredCaptureRequested) {    // Rejects samples that no longer request covered capture.
        state->candidateActive = false;  // A broken request must restart stable-time measurement.
        break;                           // Waits for a future sample to begin a new continuous request.
      }

      if (!state->candidateActive) {      // Starts timing only on the first sample of a new request.
        state->candidateActive = true;    // Marks the first sample of a continuous request.
        state->candidateSinceMs = nowMs;  // Records when that request began.
      }

      if (false) {  // TODO C8e: compare time since candidateSinceMs with triggerStableMs.
        // The cover request has qualified, so covered-reference capture may begin.
        enterCalibrationPhase(state, CAL_PHASE_CAPTURE_COVERED, nowMs);  // Starts averaging covered samples.
        return CAL_EVENT_COVER_CAPTURE_STARTED;                          // Reports that the cover request qualified.
      }
      break;  // Remains in this phase while the candidate accumulates stable time.
    }

    case CAL_PHASE_CAPTURE_COVERED:           // Captures the covered reference for a fixed interval.
      state->sampleSum += (uint64_t)reading;  // Adds this covered sample to the average.
      state->sampleCount++;                   // Records that one more sample was captured.

      if (false) {                    // TODO C8f: compare millisecondsInCurrentCalibrationPhase with coverCaptureMs.
        state->coveredReference = 0;  // TODO C8g: replace 0 with the captured average.

        // Invalid references enter the visible error phase instead of normal operation.
        if (!calibrationReferencesValid(state->uncoveredReference,state->coveredReference,config.minimumSpan)) {  // Tests the captured references against the required separation.
          enterCalibrationPhase(state, CAL_PHASE_ERROR, nowMs);  // Enters visible error feedback for invalid data.
          return CAL_EVENT_INVALID;                              // Reports the failed calibration attempt to the sketch.
        }

        // A valid covered reference still requires release before calibration is ready.
        enterCalibrationPhase(state, CAL_PHASE_WAIT_RELEASE, nowMs);  // Requires release before normal operation.
      }
      break;  // Keeps collecting covered samples until the interval qualifies.

    case CAL_PHASE_WAIT_RELEASE: {  // Waits for the sensor to remain stably uncovered.
      float normalizedScoreForCurrentReading = normalizedCoverScore(reading,state->uncoveredReference,state->coveredReference);  // Places this sample on the calibrated 0-to-1 scale.
      bool releaseRequestedByScore =                                // Names whether this score requests the uncovered state.
          normalizedScoreForCurrentReading <= config.releaseScore;  // Applies the release-side threshold.

      if (!releaseRequestedByScore) {    // Rejects samples that are still too covered for release.
        state->candidateActive = false;  // A covered sample restarts release qualification.
        break;                           // Waits for a future sample to begin a new continuous release.
      }

      if (!state->candidateActive) {      // Starts timing only on the first sample of a new release request.
        state->candidateActive = true;    // Marks the first sample of a continuous release.
        state->candidateSinceMs = nowMs;  // Records when that release began.
      }

      if (false) {                       // TODO C8h: compare time since candidateSinceMs with releaseStableMs.
        state->phase = CAL_PHASE_READY;  // Makes normal operation eligible to start.
        state->phaseStartMs = nowMs;     // Records when calibration became ready.
        state->candidateActive = false;  // Removes release-candidate history.
        return CAL_EVENT_READY;          // Reports that calibration and release are complete.
      }
      break;  // Remains here while the release candidate accumulates stable time.
    }

    case CAL_PHASE_ERROR:  // Holds course-supplied visible feedback before restarting calibration.
      // Study this supplied recovery branch and represent it in your calibration FSM diagram.
      if (millisecondsInCurrentCalibrationPhase >= config.errorDisplayMs) {
        beginCalibration(state, nowMs);  // Clears old capture state and starts a new uncovered average.
        return CAL_EVENT_RESTARTED;      // Reports that a new calibration attempt began.
      }
      break;  // Keeps displaying the error while the user uncovers the sensor.

    case CAL_PHASE_READY:  // Leaves calibration idle after successful release.
      break;               // Calibration remains ready until the integration sketch resets it.

    default:                           // Handles corrupted or out-of-range calibration phases.
      beginCalibration(state, nowMs);  // Recovers an invalid phase with a full calibration reset.
      return CAL_EVENT_RESTARTED;      // Reports the recovery reset to the integration sketch.
  }

  return CAL_EVENT_NONE;  // Reports that this sample did not complete a calibration milestone.
}

/*
 * resetCoveredDetector()
 *
 * Initializes the accepted and candidate covered levels without emitting an edge.
 *
 * Parameters:
 *   state: Covered-detector state to initialize. A null pointer is ignored.
 *   initiallyCovered: Initial accepted and candidate level.
 *   nowMs: Current time in milliseconds; becomes the candidate timestamp.
 */
void resetCoveredDetector(CoveredDetector *state,
                          bool initiallyCovered,
                          uint32_t nowMs) {
  if (state == nullptr) return;  // Cannot initialize missing detector state.

  state->covered = initiallyCovered;    // Sets the accepted starting level.
  state->candidate = initiallyCovered;  // Prevents reset from inventing a pending change.
  state->candidateSinceMs = nowMs;      // Gives future candidate timing a known initial value.
}

/*
 * updateCoveredDetector()
 *
 * Applies hysteresis and temporal qualification to one normalized score.
 *
 * Parameters:
 *   state: Persistent detector state from the previous score.
 *   score: Current normalized cover score in [0, 1].
 *   nowMs: Current time in milliseconds.
 *   enterScore: Minimum score that requests a change from uncovered to covered.
 *   releaseScore: Maximum score that requests a change from covered to uncovered.
 *   stableMs: Minimum milliseconds that a requested level must remain unchanged
 *     before it becomes the accepted covered level.
 *
 * Returns:
 *   The accepted covered level after this update. A null state returns false.
 */
bool updateCoveredDetector(CoveredDetector *state,
                           float score,
                           uint32_t nowMs,
                           float enterScore,
                           float releaseScore,
                           uint32_t stableMs) {
  if (state == nullptr) return false;  // Cannot update missing detector state.

  // Begin by preserving the accepted level. Scores in the hysteresis band do not request change.
  bool coveredStateRequestedByScore = state->covered;    // Preserves the accepted level inside the hysteresis band.
  if (!state->covered && score >= enterScore) {          // Requests covered only above the enter threshold.
    coveredStateRequestedByScore = true;                 // High score requests entry into covered.
  } else if (state->covered && score <= releaseScore) {  // Requests release only below the lower threshold.
    coveredStateRequestedByScore = false;                // Low score requests release from covered.
  }

  if (coveredStateRequestedByScore == state->covered) {  // Cancels qualification when no level change is requested.
    state->candidate = state->covered;                   // Removes a pending request for the opposite level.
    state->candidateSinceMs = nowMs;                     // Future requests must begin a new stable interval.
    return state->covered;                               // The accepted level does not change.
  }

  if (false) {  // TODO C9a: compare coveredStateRequestedByScore with state->candidate.
    // TODO C9b: record coveredStateRequestedByScore and when its stable interval began.
  }

  if (false) {  // TODO C9c: compare candidate elapsed time with stableMs.
    // TODO C9d: accept coveredStateRequestedByScore and reset the candidate timer.
  }

  return state->covered;  // Returns the accepted level, not an unqualified candidate.
}

/*
 * classifyCompletedCover()
 *
 * Classifies the duration of one completed cover.
 *
 * Parameters:
 *   durationMs: Milliseconds from accepted cover start to accepted release.
 *   config: Tap, commit, and cancel duration boundaries.
 *
 * Returns:
 *   TAP for [tapMinimumMs, tapMaximumMs), COMMIT for
 *   [commitMinimumMs, cancelMinimumMs), and NONE for every other completed
 *   duration. CANCEL is emitted while held by updateCoverTracker().
 */
CoverEvent classifyCompletedCover(uint32_t durationMs,
                                  const GestureConfig &config) {
  if (false) {               // TODO C10a: test durationMs against both tap boundaries in config.
    return COVER_EVENT_TAP;  // Reports one completed brief cover.
  }

  if (false) {                  // TODO C10b: test durationMs against commit and cancel boundaries.
    return COVER_EVENT_COMMIT;  // Reports one completed sustained cover.
  }

  return COVER_EVENT_NONE;  // Durations in a dead band do not become events.
}

/*
 * resetCoverTracker()
 *
 * Initializes cover-edge and held-gesture history without emitting an event.
 *
 * Parameters:
 *   state: Cover-tracker state to initialize. A null pointer is ignored.
 *   initiallyCovered: Accepted cover level at initialization.
 *   nowMs: Current time in milliseconds; becomes the initial cover timestamp.
 */
void resetCoverTracker(CoverTracker *state,
                       bool initiallyCovered,
                       uint32_t nowMs) {
  if (state == nullptr) return;  // Cannot initialize missing tracker state.

  state->wasCovered = initiallyCovered;  // Sets the previous accepted level.
  state->coverStartedMs = nowMs;         // Gives a current cover a known start time.
  state->cancelEmitted = false;          // No cancel has fired for this initial cover.
}

/*
 * updateCoverTracker()
 *
 * Converts accepted cover levels into tap, commit, and fire-once cancel events.
 *
 * Parameters:
 *   state: Persistent edge and gesture history from the previous update.
 *   covered: Current accepted output of updateCoveredDetector().
 *   nowMs: Current time in milliseconds.
 *   config: Duration boundaries used to classify or cancel the gesture.
 *
 * Returns:
 *   At most one CoverEvent for this update. A cancel fires once as soon as the
 *   held duration reaches cancelMinimumMs. Releasing after a cancel emits no
 *   second event. A null state returns COVER_EVENT_NONE.
 */
CoverEvent updateCoverTracker(CoverTracker *state,
                              bool covered,
                              uint32_t nowMs,
                              const GestureConfig &config) {
  if (state == nullptr) return COVER_EVENT_NONE;  // Cannot update missing tracker state.

  if (covered && !state->wasCovered) {  // Detects the accepted uncovered-to-covered edge.
    state->wasCovered = true;           // Records the accepted uncovered-to-covered edge.
    state->coverStartedMs = nowMs;      // Starts measuring this cover's duration.
    state->cancelEmitted = false;       // Allows this new hold to emit one future cancel.
    return COVER_EVENT_NONE;            // A cover start alone is not a completed gesture.
  }

  if (covered && state->wasCovered) {                                   // Handles a cover that remains held across updates.
    uint32_t coverHeldForMs = elapsedMs(nowMs, state->coverStartedMs);  // Measures the current hold duration.

    if (false) {                    // TODO C11: test cancelEmitted and coverHeldForMs against the threshold.
      state->cancelEmitted = true;  // Prevents the same hold from emitting cancel again.
      return COVER_EVENT_CANCEL;    // Reports cancel before the sensor is released.
    }
    return COVER_EVENT_NONE;  // The ongoing hold has not produced a new event.
  }

  if (!covered && state->wasCovered) {                                            // Detects the accepted covered-to-uncovered edge.
    uint32_t completedCoverDurationMs = elapsedMs(nowMs, state->coverStartedMs);  // Measures the completed gesture.
    state->wasCovered = false;                                                    // Records the accepted covered-to-uncovered edge.

    if (state->cancelEmitted) {      // Suppresses a release event after this hold already emitted cancel.
      state->cancelEmitted = false;  // Prepares the tracker for the next cover.
      return COVER_EVENT_NONE;       // Release after cancel must not emit a second event.
    }

    return classifyCompletedCover(completedCoverDurationMs, config);  // Maps a normal release duration into one event.
  }

  return COVER_EVENT_NONE;  // Remaining uncovered samples do not create events.
}

/*
 * resetTimer()
 *
 * Restores all application fields to the complete STANDBY invariant.
 *
 * Parameters:
 *   state: Timer state to initialize. A null pointer is ignored.
 *   nowMs: Current time in milliseconds; initializes all timer timestamps.
 */
void resetTimer(TimerState *state, uint32_t nowMs) {
  if (state == nullptr) return;        // Cannot initialize missing timer state.
  clearTimerForStandby(state, nowMs);  // Applies the complete STANDBY invariant.
}

/*
 * updateTimer()
 *
 * Applies one gesture event and one elapsed-time update to the application FSM.
 *
 * Parameters:
 *   state: Persistent timer state from the previous update.
 *   event: Newly extracted cover event, or COVER_EVENT_NONE.
 *   nowMs: Current time in milliseconds.
 *   config: Entry-window, time-unit, DONE-duration, and required-tap settings.
 *
 * Effects:
 *   Updates the state fields required by R1-R6. Relative-time behavior must
 *   remain correct across uint32_t millis() rollover. An invalid mode recovers
 *   to the complete STANDBY invariant. A null state pointer is ignored.
 */
void updateTimer(TimerState *state,
                 CoverEvent event,
                 uint32_t nowMs,
                 const TimerConfig &config) {
  if (state == nullptr) return;  // Cannot update missing timer state.

  // Each branch contains only the events and elapsed-time behavior relevant to that mode.
  switch (state->mode) {                                           // Runs only the events and timing behavior owned by the active mode.
    case TIMER_STANDBY: {                                          // Watches for the required quick-tap entry sequence.
      bool entryTapWindowHasExpired = false;                       // TODO F1a: compare the tap gap with entryTapWindowMs.
      if (state->entryTapCount > 0 && entryTapWindowHasExpired) {  // Rejects a partial sequence after a slow gap.
        state->entryTapCount = 0;                                  // Discards an entry sequence whose tap spacing was too slow.
      }

      if (event == COVER_EVENT_TAP) {   // Counts only accepted tap events toward entry.
        state->entryTapCount++;         // Adds this accepted tap to the entry sequence.
        state->lastEntryTapMs = nowMs;  // Starts the gap measurement for the next entry tap.

        if (false) {  // TODO F1b: compare entryTapCount with config.entryTapsRequired.
          // TODO F1c: enter ADDING, clear entry history, and seed one time unit without exceeding MAX_COUNTDOWN_SECONDS.
        }
      }
      break;  // Finishes the STANDBY update for this call.
    }

    case TIMER_ADDING:                    // Accepts time-entry taps, commit, or immediate cancel.
      if (event == COVER_EVENT_CANCEL) {  // Gives cancel priority while entering time.
        // TODO F2a: return to the complete STANDBY invariant.
      } else if (event == COVER_EVENT_TAP) {  // Adds one configured time unit for each accepted tap.
        uint64_t newTotalSeconds = 0;         // TODO F2b: replace 0 with the enlarged sum.
        // TODO F2c: store newTotalSeconds without exceeding MAX_COUNTDOWN_SECONDS.
      } else if (event == COVER_EVENT_COMMIT && state->remainingSeconds > 0) {  // Commits only a nonzero timer.
        uint64_t newCountdownDurationMs = 0;                                    // TODO F2d: convert remainingSeconds to milliseconds.
        // TODO F2e: keep remainingSeconds representable in milliseconds, store the duration, record the start time, and enter COUNTDOWN.
      }
      break;  // Finishes the ADDING update for this call.

    case TIMER_COUNTDOWN:                 // Derives remaining time from the committed start and duration.
      if (event == COVER_EVENT_CANCEL) {  // Allows an active countdown to return immediately to STANDBY.
        // TODO F3a: return to the complete STANDBY invariant.
      } else {                                                                    // Updates elapsed countdown time when no cancel event occurred.
        uint32_t countdownElapsedMs = elapsedMs(nowMs, state->countdownStartMs);  // Measures progress from commit.

        if (false) {  // TODO F3b: compare countdownElapsedMs with countdownDurationMs.
          // TODO F3c: set the remaining time to zero, enter DONE, and record its start time.
        } else {                                   // Keeps the FSM in COUNTDOWN while committed time remains.
          uint32_t countdownMillisecondsLeft = 0;  // TODO F3d: calculate the remaining countdown duration.
          // TODO F3e: convert countdownMillisecondsLeft to whole seconds, rounding up.
        }
      }
      break;  // Finishes the COUNTDOWN update for this call.

    case TIMER_DONE:  // Holds the completion alert for its configured duration.
      if (false) {    // TODO F4a: compare DONE elapsed time with config.doneAlertMs.
        // TODO F4b: return to the complete STANDBY invariant.
      }
      break;  // Finishes the DONE update for this call.

    default:                               // Handles corrupted or out-of-range timer modes.
      clearTimerForStandby(state, nowMs);  // Recovers invalid mode data to a known invariant.
      break;                               // Finishes the recovery update.
  }
}

}  // namespace a1
