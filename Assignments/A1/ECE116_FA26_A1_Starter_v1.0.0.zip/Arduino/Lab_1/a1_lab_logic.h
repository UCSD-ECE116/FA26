#ifndef A1_LAB_LOGIC_H
#define A1_LAB_LOGIC_H

#include <stdint.h>

namespace a1 {

enum ButtonEvent {
  BUTTON_EVENT_NONE = 0,  // No newly accepted press occurred on this update.
  BUTTON_EVENT_PRESSED    // The stable level just changed from released to pressed.
};

enum LightMode {
  LIGHT_MODE_OFF = 0,  // Both Lab LEDs are off.
  LIGHT_MODE_AUTO,     // The GPIO3 LED follows the light-to-PWM mapping.
  LIGHT_MODE_ON        // The GPIO2 LED is steadily on.
};

struct LabConfig {
  int brightReference;  // Raw ADC reading measured with the LDR uncovered.
  int darkReference;    // Raw ADC reading measured with the LDR covered.
};

struct ButtonDebouncer {
  bool lastRawPressed;   // Most recently sampled electrical button level.
  bool stablePressed;    // Button level accepted after temporal qualification.
  uint32_t rawChangedMs; // millis() timestamp when lastRawPressed last changed.
};

/*
 * makeLabConfig()
 *
 * Returns the bright and dark ADC references measured on your own LDR circuit.
 * brightReference must be greater than darkReference for the supplied divider.
 */
LabConfig makeLabConfig();

/*
 * periodicDue()
 *
 * Determines whether one periodic service is ready to run.
 *
 * Parameters:
 *   nowMs: Current time in milliseconds, normally the latest millis() value.
 *   intervalMs: Minimum milliseconds required between accepted service runs.
 *   lastRunMs: Mutable timestamp of the most recently accepted run. A null
 *     pointer is invalid and returns false.
 *
 * Returns:
 *   true when at least intervalMs has elapsed. A true result also updates
 *   *lastRunMs to nowMs. Otherwise returns false without changing *lastRunMs.
 *   Elapsed-time arithmetic must remain correct across uint32_t rollover.
 */
bool periodicDue(uint32_t nowMs, uint32_t intervalMs, uint32_t *lastRunMs);

/*
 * mapLightToDuty()
 *
 * Converts one raw light reading into an inverse PWM duty value.
 *
 * Parameters:
 *   reading: Current raw ADC sample from the LDR voltage divider.
 *   brightReference: Raw ADC value that maps to duty 0.
 *   darkReference: Raw ADC value that maps to maxDuty.
 *   maxDuty: Largest PWM duty value allowed by the caller.
 *
 * Returns:
 *   The nearest integer duty after linear mapping and endpoint clamping.
 *   Returns 0 when brightReference <= darkReference.
 */
uint8_t mapLightToDuty(int reading,
                       int brightReference,
                       int darkReference,
                       uint8_t maxDuty);

/*
 * resetButtonDebouncer()
 *
 * Initializes all button-debouncer state without creating a synthetic edge.
 *
 * Parameters:
 *   state: Debouncer state to initialize. A null pointer is ignored.
 *   initialPressed: Raw and accepted button level observed at initialization.
 *   nowMs: Current time in milliseconds; becomes the raw-change timestamp.
 */
void resetButtonDebouncer(ButtonDebouncer *state,
                          bool initialPressed,
                          uint32_t nowMs);

/*
 * updateButtonDebouncer()
 *
 * Converts one raw button sample into at most one accepted press event.
 *
 * Parameters:
 *   state: Persistent debouncer state from the previous update.
 *   rawPressed: Current electrical button level; true means physically pressed.
 *   nowMs: Current time in milliseconds.
 *   stableMs: Minimum number of milliseconds the raw level must remain
 *     unchanged before it becomes the accepted stable level.
 *
 * Returns:
 *   BUTTON_EVENT_PRESSED exactly once when the accepted level changes from
 *   released to pressed. Releases, held levels, unstable samples, and a null
 *   state pointer return BUTTON_EVENT_NONE.
 */
ButtonEvent updateButtonDebouncer(ButtonDebouncer *state,
                                  bool rawPressed,
                                  uint32_t nowMs,
                                  uint32_t stableMs);

/*
 * nextLightMode()
 *
 * Advances one accepted button press through the Lab mode cycle.
 *
 * Parameters:
 *   current: Currently accepted LightMode value.
 *
 * Returns:
 *   OFF -> AUTO, AUTO -> ON, and ON -> OFF. An invalid enum value recovers to
 *   LIGHT_MODE_OFF.
 */
LightMode nextLightMode(LightMode current);

}  // namespace a1

#endif
