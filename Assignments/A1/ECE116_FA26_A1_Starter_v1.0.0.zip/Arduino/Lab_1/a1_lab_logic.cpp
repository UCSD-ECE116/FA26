#include "a1_lab_logic.h"

namespace a1 {

/*
 * makeLabConfig()
 *
 * Returns the bright and dark ADC references measured on your own LDR circuit.
 * brightReference must be greater than darkReference for the supplied divider.
 */
LabConfig makeLabConfig() {
  LabConfig config{};  // Creates the configuration returned to Lab_1.ino.

  config.brightReference = 0;  // TODO L2a: replace 0 with your measured bright reading.
  config.darkReference = 0;    // TODO L2b: replace 0 with your measured covered reading.

  return config;  // Gives the measured references to the supplied integration sketch.
}

/*
 * periodicDue()
 *
 * Determines whether one periodic service is ready to run.
 *
 * Parameters:
 *   nowMs: Current time in milliseconds, normally the latest millis() value.
 *   intervalMs: Minimum milliseconds required between accepted service runs.
 *   lastRunMs: Mutable timestamp of the most recently accepted run. A null
 *     pointer is invalid and returns false.
 *
 * Returns:
 *   true when at least intervalMs has elapsed. A true result also updates
 *   *lastRunMs to nowMs. Otherwise returns false without changing *lastRunMs.
 *   Elapsed-time arithmetic must remain correct across uint32_t rollover.
 */
bool periodicDue(uint32_t nowMs, uint32_t intervalMs, uint32_t *lastRunMs) {
  if (lastRunMs == nullptr) return false;  // Rejects an invalid timestamp pointer.

  uint32_t millisecondsSinceLastRun = 0;  // TODO L1a: replace 0 with elapsed time from nowMs and *lastRunMs.
  // NOTE: Unsigned subtraction remains valid when millis() wraps around.
  if (0) return false;  // TODO L1b: compare millisecondsSinceLastRun with intervalMs.
  // TODO L1c: update *lastRunMs to the current time.

  return true;  // Tells the caller to run this periodic service now.
}

/*
 * mapLightToDuty()
 *
 * Converts one raw light reading into an inverse PWM duty value.
 *
 * Parameters:
 *   reading: Current raw ADC sample from the LDR voltage divider.
 *   brightReference: Raw ADC value that maps to duty 0.
 *   darkReference: Raw ADC value that maps to maxDuty.
 *   maxDuty: Largest PWM duty value allowed by the caller.
 *
 * Returns:
 *   The nearest integer duty after linear mapping and endpoint clamping.
 *   Returns 0 when brightReference <= darkReference.
 */
uint8_t mapLightToDuty(int reading,
                       int brightReference,
                       int darkReference,
                       uint8_t maxDuty) {
  if (brightReference <= darkReference) return 0;  // Rejects unusable calibration references.
  if (reading >= brightReference) return 0;        // Clamps bright readings to LED off.
  if (reading <= darkReference) return maxDuty;    // Clamps dark readings to maximum brightness.

  int64_t brightToDarkAdcSpan = (int64_t)brightReference - darkReference;           // Measures the calibrated ADC range.
  int64_t readingDistanceFromBrightReference = (int64_t)brightReference - reading;  // Measures progress toward dark.
  int64_t pwmDutyNumerator = 0;                                                     // TODO L3a: scale readingDistanceFromBrightReference by maxDuty.
  int64_t roundedPwmDuty = 0;                                                       // TODO L3b: divide by brightToDarkAdcSpan and round to the nearest integer.

  return (uint8_t)roundedPwmDuty;  // Returns the mapped value in the PWM duty type.
}

/*
 * resetButtonDebouncer()
 *
 * Initializes all button-debouncer state without creating a synthetic edge.
 *
 * Parameters:
 *   state: Debouncer state to initialize. A null pointer is ignored.
 *   initialPressed: Raw and accepted button level observed at initialization.
 *   nowMs: Current time in milliseconds; becomes the raw-change timestamp.
 */
void resetButtonDebouncer(ButtonDebouncer *state,
                          bool initialPressed,
                          uint32_t nowMs) {
  if (state == nullptr) return;  // Ignores an invalid state pointer.

  state->lastRawPressed = initialPressed;  // Records the electrical level observed at reset.
  state->stablePressed = false;            // TODO L5a: replace false with the accepted initial level.
  state->rawChangedMs = nowMs;             // Starts raw-level timing at the reset time.
}

/*
 * updateButtonDebouncer()
 *
 * Converts one raw button sample into at most one accepted press event.
 *
 * Parameters:
 *   state: Persistent debouncer state from the previous update.
 *   rawPressed: Current electrical button level; true means physically pressed.
 *   nowMs: Current time in milliseconds.
 *   stableMs: Minimum number of milliseconds the raw level must remain
 *     unchanged before it becomes the accepted stable level.
 *
 * Returns:
 *   BUTTON_EVENT_PRESSED exactly once when the accepted level changes from
 *   released to pressed. Releases, held levels, unstable samples, and a null
 *   state pointer return BUTTON_EVENT_NONE.
 */
ButtonEvent updateButtonDebouncer(ButtonDebouncer *state,
                                  bool rawPressed,
                                  uint32_t nowMs,
                                  uint32_t stableMs) {
  if (state == nullptr) return BUTTON_EVENT_NONE;  // Cannot update missing state.

  if (rawPressed != state->lastRawPressed) {  // Checks for a change in the electrical reading.
    state->lastRawPressed = 0;                // TODO L5b: replace 0 with the new raw button reading.
    state->rawChangedMs = 0;                  // TODO L5c: replace 0 with the time of this raw change.
  }

  uint32_t rawPressedStableForMs = 0;               // TODO L5d: calculate how long rawPressed has been stable.
  bool rawPressedHasBeenStableLongEnough = false;   // TODO L5e: compare that duration with stableMs.
  bool rawPressedDiffersFromStablePressed = false;  // TODO L5f: compare raw and accepted levels.

  if (rawPressedDiffersFromStablePressed && rawPressedHasBeenStableLongEnough) {  // Accepts only a new, qualified level.
    state->stablePressed = rawPressed;                                            // Promotes the qualified raw level to the accepted stable level.
    return rawPressed ? BUTTON_EVENT_PRESSED : BUTTON_EVENT_NONE;                 // Emits only the accepted press edge.
  }

  return BUTTON_EVENT_NONE;  // No new stable press was accepted on this update.
}

/*
 * nextLightMode()
 *
 * Advances one accepted button press through the Lab mode cycle.
 *
 * Parameters:
 *   current: Currently accepted LightMode value.
 *
 * Returns:
 *   OFF -> AUTO, AUTO -> ON, and ON -> OFF. An invalid enum value recovers to
 *   LIGHT_MODE_OFF.
 */
LightMode nextLightMode(LightMode current) {
  switch (current) {           // Selects the transition associated with the current FSM mode.
    case LIGHT_MODE_OFF:       // Defines the transition that follows OFF.
      return LIGHT_MODE_OFF;   // TODO L4a: replace with the mode after OFF.
    case LIGHT_MODE_AUTO:      // Defines the transition that follows AUTO.
      return LIGHT_MODE_AUTO;  // TODO L4b: replace with the mode after AUTO.
    case LIGHT_MODE_ON:        // Defines the transition that follows ON.
      return LIGHT_MODE_ON;    // TODO L4c: replace with the mode after ON.
    default:                   // Handles corrupted or out-of-range mode values.
      return LIGHT_MODE_OFF;   // Recovers from an invalid enum value.
  }
}

}  // namespace a1
