// Lab_1.ino
// v10 - 2026-09-06
//
// A1 STRUCTURED LAB -- Responsive night-light controller.
//
// This supplied integration sketch must remain unchanged. Complete the guided
// logic in a1_lab_logic.cpp, then use this sketch to test it on the board.

#include "a1_lab_logic.h"

#define LDR_PIN          A0
#define ON_LED_PIN       2
#define AUTO_LED_PIN     3
#define BUTTON_PIN       5

#define PWM_MAX          255
#define SAMPLE_MS        50UL
#define REPORT_MS        250UL
#define DEBOUNCE_MS      25UL
#define SERIAL_BAUD      115200

const char *MODE_NAMES[] = {"OFF", "AUTO", "ON"};

a1::LightMode currentLightMode = a1::LIGHT_MODE_OFF;
a1::ButtonDebouncer buttonDebouncerState;
a1::LabConfig labConfiguration;

int currentLightReading = 0;
bool onModeLedIsActive = false;
uint8_t automaticModeLedDuty = 0;

uint32_t lastSensorAndOutputMs = 0;
uint32_t lastReportMs = 0;
bool serialOutputWasAvailable = false;

bool serialOutputIsAvailable();
void serviceSerialOutput();

/*
 * setup()
 *
 * Initializes the pins and gives every software state a known starting value.
 */
void setup() {
  Serial.begin(SERIAL_BAUD);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial.setTxTimeoutMs(0);
#endif
  analogReadResolution(12);

  pinMode(LDR_PIN, INPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(ON_LED_PIN, OUTPUT);
  pinMode(AUTO_LED_PIN, OUTPUT);
  analogWriteResolution(AUTO_LED_PIN, 8);

  labConfiguration = a1::makeLabConfig();

  uint32_t setupTimeMs = millis();
  bool buttonIsPressedAtSetup = digitalRead(BUTTON_PIN) == LOW;
  a1::resetButtonDebouncer(&buttonDebouncerState,buttonIsPressedAtSetup,setupTimeMs);

  lastSensorAndOutputMs = setupTimeMs;
  lastReportMs = setupTimeMs;
  serviceSerialOutput();
}

/*
 * loop()
 *
 * Converts raw input to an event and state, then services sensor/output and
 * reporting on two independent nonblocking schedules.
 */
void loop() {
  uint32_t nowMs = millis();
  serviceSerialOutput();

  bool rawButtonIsPressed = digitalRead(BUTTON_PIN) == LOW;
  a1::ButtonEvent buttonEvent = a1::updateButtonDebouncer(&buttonDebouncerState,rawButtonIsPressed,nowMs,DEBOUNCE_MS);

  if (buttonEvent == a1::BUTTON_EVENT_PRESSED) {
    currentLightMode = a1::nextLightMode(currentLightMode);
  }

  if (a1::periodicDue(nowMs, SAMPLE_MS, &lastSensorAndOutputMs)) {
    currentLightReading = analogRead(LDR_PIN);
    uint8_t mappedAutomaticDuty = a1::mapLightToDuty(currentLightReading,labConfiguration.brightReference,labConfiguration.darkReference,PWM_MAX);

    onModeLedIsActive = currentLightMode == a1::LIGHT_MODE_ON;
    automaticModeLedDuty = currentLightMode == a1::LIGHT_MODE_AUTO ? mappedAutomaticDuty : 0;

    digitalWrite(ON_LED_PIN, onModeLedIsActive);
    analogWrite(AUTO_LED_PIN, automaticModeLedDuty);
  }

  if (a1::periodicDue(nowMs, REPORT_MS, &lastReportMs)
      && serialOutputIsAvailable()) {
    Serial.print("mode=");
    Serial.print(MODE_NAMES[currentLightMode]);
    Serial.print(" light=");
    Serial.print(currentLightReading);
    Serial.print(" on_led=");
    Serial.print(onModeLedIsActive ? 1 : 0);
    Serial.print(" auto_duty=");
    Serial.println(automaticModeLedDuty);
  }
}

/*
 * serialOutputIsAvailable()
 *
 * Reports whether the current Serial transport can accept diagnostic output.
 */
bool serialOutputIsAvailable() {
  return (bool)Serial;
}

/*
 * serviceSerialOutput()
 *
 * Prints the Lab banner once whenever a Serial monitor connects.
 */
void serviceSerialOutput() {
  bool serialOutputIsAvailableNow = serialOutputIsAvailable();
  if (!serialOutputIsAvailableNow) {
    serialOutputWasAvailable = false;
    return;
  }

  if (serialOutputWasAvailable) return;
  serialOutputWasAvailable = true;
  Serial.println("A1 Lab: responsive night-light controller");
}
