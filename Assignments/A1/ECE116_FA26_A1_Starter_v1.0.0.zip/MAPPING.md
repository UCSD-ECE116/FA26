# A1 Starter Projects and Logic Contract

v15 · 2026-09-06

`Arduino/Lab_1/` and `Arduino/Challenge_1/` are the complete starter projects. Each folder contains
the matching `.ino`, its course-owned headers, and the `.cpp` file students implement. Keep each
project together so Arduino can compile it. Do not rename functions, change parameters, edit the
`.ino`, or move logic into a different file to avoid the interface.

The two logic headers are the authoritative interface reference. Their comments define every
function parameter, return value, persistent state field, unit, threshold direction, and interval
boundary used by the starters and behavioral checks.
The handout is the authoritative work sequence. Follow its named Lab and Challenge problems rather
than scanning the source for TODOs or assuming functions should be completed from top to bottom.
Each handout problem maps its TODO labels to an observable checkpoint.

## Structured lab

Implement `Arduino/Lab_1/a1_lab_logic.cpp`:

| Function | Concept exercised |
|---|---|
| `makeLabConfig()` | measured bright and dark references selected from the student's trace |
| `periodicDue()` | nonblocking elapsed-time scheduling and `millis()` rollover |
| `mapLightToDuty()` | inverse linear map, endpoint clamp, and integer rounding |
| `resetButtonDebouncer()` | explicit level and timing initialization |
| `updateButtonDebouncer()` | stable-time debounce and one press event per accepted edge |
| `nextLightMode()` | finite-state transition among the three required Lab modes |

The supplied Lab sketch maps the states to two separate outputs: GPIO2 is the steady ON LED, and
GPIO3 is the PWM-controlled AUTO LED.

## Challenge

Implement `Arduino/Challenge_1/a1_timer_logic.cpp`:

| Function family | Concept exercised |
|---|---|
| `makeCalibrationConfig()` and the other configuration functions | student-selected calibration, decision, gesture, and timer parameters; supplied 1200 ms error display |
| calibration reference and score functions | validity, normalized representation, diagnostic boundaries |
| `beginCalibration()` / `updateCalibration()` | student-owned capture and validity transitions; supplied timed error recovery represented in the student's calibration FSM |
| covered-detector reset/update | hysteresis and stable-time temporal qualification |
| completed-cover classifier | nonoverlapping tap, dead-band, and commit durations |
| cover-tracker reset/update | level-to-event conversion and fire-once cancel while held |
| timer reset/update | student-authored transitions among the required observable timer modes |

The compile-safe starter provides function documentation, defensive checks, common bookkeeping,
and control-flow frames. Most TODOs identify the exact expression or statement to replace. Larger
FSM TODOs identify a specific state and event branch while leaving the transition actions to you.
Comments beside supplied comparisons and state updates explain their role, and local variable names
state the full relationship they represent. These comments locate implementation work; the handout
defines the problem, constraints, hints, and test sequence. The README questions cover the
conceptually important behavior that the starter provides. The completed instructor implementation
and its FSM diagram are not included. Students reconstruct both calibration and timer FSM regions
from the requirements and the mixed supplied/TODO implementation. Staff run 50 behavioral grading tests after Canvas submission to exercise the contracts with different times,
references, thresholds, and rollover boundaries; hardcoding one test trace is not a valid
implementation.
