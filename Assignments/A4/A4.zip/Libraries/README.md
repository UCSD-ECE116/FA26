# Pinned TensorFlow Lite Micro dependency

Install `Chirale_TensorFlowLite-2.0.0.zip` in Arduino IDE with **Sketch > Include Library > Add
.ZIP Library**. Do not replace it with another TensorFlow Lite Micro package or version for A4.

- Upstream project: [Chirale TensorFlowLite repository](https://github.com/spaziochirale/Chirale_TensorFlowLite)
- Version: `2.0.0`
- License: Apache License 2.0, included inside the ZIP
- SHA-256: `d720d744c7f05f775c164d2b73cff1ec953b819d3d0304c082e9ad4b884a0ef8`

The course has tested this exact archive with Espressif core `3.3.10` and
`esp32:esp32:XIAO_ESP32S3:PSRAM=opi`.
