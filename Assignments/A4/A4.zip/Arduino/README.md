# A4 Arduino integration

`A4_Vision/` is the supplied direct TensorFlow Lite Micro runtime. The runtime supports any two
label names generated through the A4 exporter. Students replace only the generated model,
metadata, and golden header files.

Compile with Espressif core `3.3.10` and
`esp32:esp32:XIAO_ESP32S3:PSRAM=opi`. Install
`Libraries/Chirale_TensorFlowLite-2.0.0.zip` and preserve the complete compiler output.

The serial protocol runs at `921600` baud with newline termination:

- `INFO` reports artifact, arena, camera, and runtime identity;
- `GOLDEN` runs every embedded host-parity row;
- `TIMING 20` discards the supplied warm-ups and prints 20 inference measurements; and
- `CAMERA <trial> <truth> <condition>` captures one frame and prints both scores and timing.
- `CAPTURE_JPEG <id>` returns one length- and CRC-framed 240 by 240 camera JPEG; and
- `REPLAY_JPEG <trial> <truth> <split> <bytes> <crc32>` accepts the exact saved JPEG and runs
  device decode, resize, quantization, and TFLM inference. This protocol command supports the
  recorded-image hardware-in-the-loop test; it does not capture a new camera frame.

Use `Python/capture_dataset.py` for data collection, `Python/replay_dataset.py` for per-candidate
on-device validation and held-out evaluation with recorded images, and
`Python/run_device_protocol.py` for final parity and live timing. Each tool stops when model
identity or golden parity fails.
