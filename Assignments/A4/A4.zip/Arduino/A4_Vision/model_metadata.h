#pragma once

#include <stddef.h>

constexpr const char *kA4ModelId = "ece116-a4-lab-fruit-binary-v3";
constexpr const char *kA4ModelSha256 = "769e28ef23442b8a39415961d1ed85e08ef3937789bade732b60670d816b0347";
constexpr size_t kA4LabelCount = 2;
static const char *const kA4Labels[kA4LabelCount] = {
    "apple",
    "banana",
};
