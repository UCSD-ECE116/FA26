#include <Arduino.h>
#include <Chirale_TensorFlowLite.h>
#include <esp_camera.h>
#include <esp_heap_caps.h>
#include <img_converters.h>

#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include "camera_pins.h"
#include "golden_inputs.h"
#include "model_data.h"
#include "model_metadata.h"

namespace {

constexpr uint32_t kBaud = 921600;
constexpr int kSourceWidth = 240;
constexpr int kSourceHeight = 240;
constexpr int kTargetWidth = 96;
constexpr int kTargetHeight = 96;
constexpr size_t kTargetBytes = kTargetWidth * kTargetHeight * 3;
constexpr size_t kTensorArenaBytes = 512 * 1024;
constexpr size_t kWarmupCount = 3;
constexpr float kGoldenScoreTolerance = 0.06f;
constexpr size_t kMaximumReplayJpegBytes = 200 * 1024;

const tflite::Model *model = nullptr;
tflite::MicroInterpreter *interpreter = nullptr;
TfLiteTensor *inputTensor = nullptr;
TfLiteTensor *outputTensor = nullptr;
uint8_t *tensorArena = nullptr;
uint8_t *rgb240 = nullptr;
uint8_t *rgb96 = nullptr;
const uint8_t *activeRgb = nullptr;
bool activeRgbIsProgmem = false;
bool runtimeReady = false;
bool cameraReady = false;
uint32_t sensorPid = 0;

uint8_t readActiveByte(size_t index) {
  return activeRgbIsProgmem ? pgm_read_byte(activeRgb + index) : activeRgb[index];
}

bool labelsMatchGoldenContract() {
  if (kA4LabelCount != kA4GoldenLabelCount) return false;
  for (size_t index = 0; index < kA4LabelCount; ++index) {
    if (strcmp(kA4Labels[index], kA4GoldenLabels[index]) != 0) return false;
  }
  return true;
}

bool beginCamera() {
  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.frame_size = FRAMESIZE_240X240;
  config.pixel_format = PIXFORMAT_JPEG;
  config.grab_mode = CAMERA_GRAB_LATEST;
  config.fb_location = CAMERA_FB_IN_PSRAM;
  config.jpeg_quality = 10;
  config.fb_count = 2;
  if (esp_camera_init(&config) != ESP_OK) return false;
  sensor_t *sensor = esp_camera_sensor_get();
  if (!sensor) return false;
  sensorPid = sensor->id.PID;
  if (sensorPid == OV3660_PID) {
    sensor->set_vflip(sensor, 1);
    sensor->set_brightness(sensor, 1);
    sensor->set_saturation(sensor, -2);
  }
  sensor->set_framesize(sensor, FRAMESIZE_240X240);
  return true;
}

void bilinearResizeRgb888(const uint8_t *source, uint8_t *target) {
  const float xScale = static_cast<float>(kSourceWidth) / kTargetWidth;
  const float yScale = static_cast<float>(kSourceHeight) / kTargetHeight;
  for (int y = 0; y < kTargetHeight; ++y) {
    const float sourceY = (y + 0.5f) * yScale - 0.5f;
    const int y0 = max(0, min(kSourceHeight - 1, static_cast<int>(floorf(sourceY))));
    const int y1 = min(kSourceHeight - 1, y0 + 1);
    const float yWeight = sourceY - floorf(sourceY);
    for (int x = 0; x < kTargetWidth; ++x) {
      const float sourceX = (x + 0.5f) * xScale - 0.5f;
      const int x0 = max(0, min(kSourceWidth - 1, static_cast<int>(floorf(sourceX))));
      const int x1 = min(kSourceWidth - 1, x0 + 1);
      const float xWeight = sourceX - floorf(sourceX);
      for (int channel = 0; channel < 3; ++channel) {
        const float top = source[(y0 * kSourceWidth + x0) * 3 + channel] *
                              (1.0f - xWeight) +
                          source[(y0 * kSourceWidth + x1) * 3 + channel] * xWeight;
        const float bottom = source[(y1 * kSourceWidth + x0) * 3 + channel] *
                                 (1.0f - xWeight) +
                             source[(y1 * kSourceWidth + x1) * 3 + channel] * xWeight;
        target[(y * kTargetWidth + x) * 3 + channel] =
            static_cast<uint8_t>(roundf(top * (1.0f - yWeight) + bottom * yWeight));
      }
    }
  }
}

uint32_t crc32Bytes(const uint8_t *data, size_t length) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t index = 0; index < length; ++index) {
    crc ^= data[index];
    for (uint8_t bit = 0; bit < 8; ++bit) {
      crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
  }
  return ~crc;
}

bool preprocessJpeg(const uint8_t *jpeg, size_t jpegBytes, uint32_t *decodeUs,
                    uint32_t *resizeUs) {
  const uint32_t decodeStart = micros();
  const bool decoded = fmt2rgb888(jpeg, jpegBytes, PIXFORMAT_JPEG, rgb240);
  *decodeUs = micros() - decodeStart;
  if (!decoded) return false;
  const uint32_t resizeStart = micros();
  bilinearResizeRgb888(rgb240, rgb96);
  *resizeUs = micros() - resizeStart;
  return true;
}

bool captureCameraTensor(uint32_t *captureUs, uint32_t *preprocessUs) {
  if (!cameraReady) return false;
  const uint32_t captureStart = micros();
  camera_fb_t *frame = esp_camera_fb_get();
  *captureUs = micros() - captureStart;
  if (!frame) return false;
  uint32_t decodeUs = 0;
  uint32_t resizeUs = 0;
  const bool decoded = preprocessJpeg(frame->buf, frame->len, &decodeUs, &resizeUs);
  esp_camera_fb_return(frame);
  if (!decoded) return false;
  *preprocessUs = decodeUs + resizeUs;
  return true;
}

bool runActiveImage(float *scores, uint32_t *wallUs) {
  if (!runtimeReady || !activeRgb) return false;
  for (size_t index = 0; index < kTargetBytes; ++index) {
    const float pixel = static_cast<float>(readActiveByte(index));
    const int32_t quantized =
        static_cast<int32_t>(roundf(pixel / inputTensor->params.scale)) +
        inputTensor->params.zero_point;
    inputTensor->data.uint8[index] = static_cast<uint8_t>(constrain(quantized, 0, 255));
  }
  const uint32_t start = micros();
  if (interpreter->Invoke() != kTfLiteOk) {
    Serial.println("INFERENCE_ERROR invoke");
    return false;
  }
  *wallUs = micros() - start;
  for (size_t index = 0; index < kA4LabelCount; ++index) {
    scores[index] =
        (static_cast<int32_t>(outputTensor->data.uint8[index]) -
         outputTensor->params.zero_point) *
        outputTensor->params.scale;
  }
  return true;
}

size_t winningClass(const float *scores) {
  size_t winner = 0;
  for (size_t index = 1; index < kA4LabelCount; ++index) {
    if (scores[index] > scores[winner]) winner = index;
  }
  return winner;
}

void printScores(const float *scores) {
  for (size_t index = 0; index < kA4LabelCount; ++index) {
    if (index) Serial.print(',');
    Serial.printf("%s:%.6f", kA4Labels[index], scores[index]);
  }
}

void runGolden() {
  bool allPassed = true;
  for (size_t goldenIndex = 0; goldenIndex < kA4GoldenCount; ++goldenIndex) {
    activeRgb = kA4GoldenInputs[goldenIndex];
    activeRgbIsProgmem = true;
    float scores[kA4LabelCount] = {};
    uint32_t wallUs = 0;
    if (!runActiveImage(scores, &wallUs)) {
      allPassed = false;
      continue;
    }
    float largestDifference = 0.0f;
    for (size_t classIndex = 0; classIndex < kA4LabelCount; ++classIndex) {
      largestDifference = max(
          largestDifference,
          fabsf(scores[classIndex] - kA4GoldenExpected[goldenIndex][classIndex]));
    }
    const size_t actualClass = winningClass(scores);
    const bool argmaxMatch = actualClass == kA4GoldenExpectedClass[goldenIndex];
    const bool passed = argmaxMatch && largestDifference <= kGoldenScoreTolerance;
    allPassed = allPassed && passed;
    Serial.printf(
        "GOLDEN index=%u input_sha256=%s expected=%s actual=%s argmax_match=%u "
        "max_abs=%.6f tolerance=%.6f wall_us=%lu scores=",
        static_cast<unsigned>(goldenIndex), kA4GoldenSha256[goldenIndex],
        kA4GoldenLabels[kA4GoldenExpectedClass[goldenIndex]], kA4Labels[actualClass],
        argmaxMatch ? 1U : 0U, largestDifference, kGoldenScoreTolerance, wallUs);
    printScores(scores);
    Serial.printf(" pass=%u\n", passed ? 1U : 0U);
  }
  Serial.printf("GOLDEN_SUMMARY model=%s rows=%u pass=%u\n", kA4ModelId,
                static_cast<unsigned>(kA4GoldenCount), allPassed ? 1U : 0U);
}

void runTiming(size_t trials) {
  activeRgb = kA4GoldenInputs[0];
  activeRgbIsProgmem = true;
  for (size_t warmup = 0; warmup < kWarmupCount; ++warmup) {
    float scores[kA4LabelCount] = {};
    uint32_t wallUs = 0;
    if (!runActiveImage(scores, &wallUs)) return;
  }
  for (size_t trial = 0; trial < trials; ++trial) {
    float scores[kA4LabelCount] = {};
    uint32_t wallUs = 0;
    if (!runActiveImage(scores, &wallUs)) return;
    Serial.printf("TIMING trial=%u model=%s warmup=%u inference_us=%lu\n",
                  static_cast<unsigned>(trial + 1), kA4ModelId,
                  static_cast<unsigned>(kWarmupCount), wallUs);
  }
}

void runCamera(const String &trialId, const String &trueLabel,
               const String &condition) {
  uint32_t captureUs = 0;
  uint32_t preprocessUs = 0;
  const uint32_t frameStart = micros();
  if (!captureCameraTensor(&captureUs, &preprocessUs)) {
    Serial.printf("CAMERA_ERROR trial=%s reason=capture_or_preprocess\n", trialId.c_str());
    return;
  }
  activeRgb = rgb96;
  activeRgbIsProgmem = false;
  float scores[kA4LabelCount] = {};
  uint32_t inferenceUs = 0;
  if (!runActiveImage(scores, &inferenceUs)) return;
  const uint32_t frameToResultUs = micros() - frameStart;
  const size_t winner = winningClass(scores);
  Serial.printf(
      "CAMERA trial=%s truth=%s condition=%s model=%s prediction=%s capture_us=%lu "
      "preprocess_us=%lu inference_us=%lu frame_to_result_us=%lu scores=",
      trialId.c_str(), trueLabel.c_str(), condition.c_str(), kA4ModelId,
      kA4Labels[winner], captureUs, preprocessUs, inferenceUs, frameToResultUs);
  printScores(scores);
  Serial.println();
}

void sendCameraJpeg(const String &captureId) {
  if (!cameraReady) {
    Serial.printf("CAPTURE_ERROR id=%s reason=camera_not_ready\n", captureId.c_str());
    return;
  }
  camera_fb_t *frame = esp_camera_fb_get();
  if (!frame) {
    Serial.printf("CAPTURE_ERROR id=%s reason=capture_failed\n", captureId.c_str());
    return;
  }
  const uint32_t checksum = crc32Bytes(frame->buf, frame->len);
  Serial.printf("JPEG_BEGIN id=%s bytes=%u crc32=%08lx width=%u height=%u\n",
                captureId.c_str(), static_cast<unsigned>(frame->len),
                static_cast<unsigned long>(checksum),
                static_cast<unsigned>(frame->width),
                static_cast<unsigned>(frame->height));
  Serial.write(frame->buf, frame->len);
  Serial.printf("\nJPEG_END id=%s\n", captureId.c_str());
  Serial.flush();
  esp_camera_fb_return(frame);
}

void runReplayJpeg(const String &trialId, const String &trueLabel,
                   const String &split, size_t jpegBytes,
                   uint32_t expectedCrc32) {
  if (!runtimeReady || !rgb240 || !rgb96) {
    Serial.printf("REPLAY_ERROR trial=%s reason=runtime_not_ready\n", trialId.c_str());
    return;
  }
  if (jpegBytes == 0 || jpegBytes > kMaximumReplayJpegBytes) {
    Serial.printf("REPLAY_ERROR trial=%s reason=invalid_length bytes=%u\n",
                  trialId.c_str(), static_cast<unsigned>(jpegBytes));
    return;
  }
  uint8_t *jpeg = static_cast<uint8_t *>(
      heap_caps_malloc(jpegBytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!jpeg) {
    Serial.printf("REPLAY_ERROR trial=%s reason=jpeg_alloc\n", trialId.c_str());
    return;
  }
  Serial.printf("REPLAY_READY trial=%s bytes=%u\n", trialId.c_str(),
                static_cast<unsigned>(jpegBytes));
  Serial.flush();
  const uint32_t transferStart = micros();
  const size_t received = Serial.readBytes(reinterpret_cast<char *>(jpeg), jpegBytes);
  const uint32_t transferUs = micros() - transferStart;
  if (received != jpegBytes) {
    Serial.printf("REPLAY_ERROR trial=%s reason=short_read received=%u expected=%u\n",
                  trialId.c_str(), static_cast<unsigned>(received),
                  static_cast<unsigned>(jpegBytes));
    heap_caps_free(jpeg);
    return;
  }
  const uint32_t actualCrc32 = crc32Bytes(jpeg, jpegBytes);
  if (actualCrc32 != expectedCrc32) {
    Serial.printf(
        "REPLAY_ERROR trial=%s reason=crc32 expected=%08lx actual=%08lx\n",
        trialId.c_str(), static_cast<unsigned long>(expectedCrc32),
        static_cast<unsigned long>(actualCrc32));
    heap_caps_free(jpeg);
    return;
  }
  const uint32_t processStart = micros();
  uint32_t decodeUs = 0;
  uint32_t resizeUs = 0;
  const bool preprocessed = preprocessJpeg(jpeg, jpegBytes, &decodeUs, &resizeUs);
  heap_caps_free(jpeg);
  if (!preprocessed) {
    Serial.printf("REPLAY_ERROR trial=%s reason=jpeg_decode\n", trialId.c_str());
    return;
  }
  activeRgb = rgb96;
  activeRgbIsProgmem = false;
  float resultScores[kA4LabelCount] = {};
  uint32_t inferenceUs = 0;
  if (!runActiveImage(resultScores, &inferenceUs)) return;
  const uint32_t replayToResultUs = micros() - processStart;
  const size_t winner = winningClass(resultScores);
  Serial.printf(
      "REPLAY trial=%s truth=%s split=%s model=%s prediction=%s bytes=%u "
      "crc32=%08lx transfer_us=%lu decode_us=%lu resize_us=%lu preprocess_us=%lu "
      "inference_us=%lu replay_to_result_us=%lu scores=",
      trialId.c_str(), trueLabel.c_str(), split.c_str(), kA4ModelId,
      kA4Labels[winner], static_cast<unsigned>(jpegBytes),
      static_cast<unsigned long>(actualCrc32), transferUs, decodeUs, resizeUs,
      decodeUs + resizeUs, inferenceUs, replayToResultUs);
  printScores(resultScores);
  Serial.println();
}

void handleCommand(String command) {
  command.trim();
  if (command == "PING") {
    Serial.println("PONG");
  } else if (command == "INFO") {
    Serial.printf(
        "A4_INFO model=%s model_sha256=%s model_bytes=%u labels=%u input=%ux%ux3 "
        "arena=%u arena_used=%u psram_free=%u heap_free=%u camera=%u sensor_pid=%lu\n",
        kA4ModelId, kA4ModelSha256, static_cast<unsigned>(g_model_data_len),
        static_cast<unsigned>(kA4LabelCount), kTargetWidth, kTargetHeight,
        static_cast<unsigned>(kTensorArenaBytes),
        static_cast<unsigned>(interpreter->arena_used_bytes()), ESP.getFreePsram(),
        ESP.getFreeHeap(), cameraReady ? 1U : 0U, sensorPid);
  } else if (command == "GOLDEN") {
    runGolden();
  } else if (command.startsWith("TIMING ")) {
    const long requestedTrials = command.substring(7).toInt();
    runTiming(requestedTrials > 0 ? static_cast<size_t>(requestedTrials) : 1);
  } else if (command.startsWith("CAMERA ")) {
    const int firstSpace = command.indexOf(' ', 7);
    const int secondSpace = command.indexOf(' ', firstSpace + 1);
    if (firstSpace < 0 || secondSpace < 0) {
      Serial.println("COMMAND_ERROR usage=CAMERA_trial_truth_condition");
      return;
    }
    runCamera(command.substring(7, firstSpace),
              command.substring(firstSpace + 1, secondSpace),
              command.substring(secondSpace + 1));
  } else if (command.startsWith("CAPTURE_JPEG ")) {
    sendCameraJpeg(command.substring(13));
  } else if (command.startsWith("REPLAY_JPEG ")) {
    char trialId[40] = {};
    char trueLabel[24] = {};
    char split[24] = {};
    unsigned jpegBytes = 0;
    unsigned long checksum = 0;
    const int parsed = sscanf(command.c_str(), "REPLAY_JPEG %39s %23s %23s %u %lx",
                              trialId, trueLabel, split, &jpegBytes, &checksum);
    if (parsed != 5) {
      Serial.println(
          "COMMAND_ERROR usage=REPLAY_JPEG_trial_truth_split_bytes_crc32");
      return;
    }
    runReplayJpeg(String(trialId), String(trueLabel), String(split), jpegBytes,
                  static_cast<uint32_t>(checksum));
  } else {
    Serial.printf("COMMAND_ERROR value=%s\n", command.c_str());
  }
}

}  // namespace

void setup() {
  Serial.begin(kBaud);
  Serial.setTimeout(10000);
  delay(1200);
  if (!labelsMatchGoldenContract()) {
    Serial.println("A4_SETUP_ERROR reason=label_contract");
    return;
  }
  model = tflite::GetModel(g_model_data);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    Serial.println("A4_SETUP_ERROR reason=schema");
    return;
  }
  tensorArena = static_cast<uint8_t *>(
      heap_caps_malloc(kTensorArenaBytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!tensorArena) {
    Serial.println("A4_SETUP_ERROR reason=arena_alloc");
    return;
  }
  static tflite::AllOpsResolver resolver;
  static tflite::MicroInterpreter staticInterpreter(model, resolver, tensorArena,
                                                     kTensorArenaBytes);
  interpreter = &staticInterpreter;
  if (interpreter->AllocateTensors() != kTfLiteOk) {
    Serial.println("A4_SETUP_ERROR reason=allocate_tensors");
    return;
  }
  inputTensor = interpreter->input(0);
  outputTensor = interpreter->output(0);
  if (inputTensor->type != kTfLiteUInt8 || inputTensor->bytes != kTargetBytes ||
      outputTensor->type != kTfLiteUInt8 || outputTensor->bytes != kA4LabelCount) {
    Serial.println("A4_SETUP_ERROR reason=tensor_contract");
    return;
  }
  runtimeReady = true;
  if (psramFound()) {
    rgb240 = static_cast<uint8_t *>(ps_malloc(kSourceWidth * kSourceHeight * 3));
    rgb96 = static_cast<uint8_t *>(ps_malloc(kTargetBytes));
    if (rgb240 && rgb96) cameraReady = beginCamera();
  }
  Serial.printf("A4_READY model=%s baud=%lu runtime=tflm camera=%u\n", kA4ModelId,
                kBaud, cameraReady ? 1U : 0U);
  Serial.println(
      "A4_COMMANDS PING INFO GOLDEN TIMING_<n> CAMERA_<trial>_<truth>_<condition> "
      "CAPTURE_JPEG_<id> REPLAY_JPEG_<trial>_<truth>_<split>_<bytes>_<crc32>");
}

void loop() {
  if (!Serial.available()) {
    delay(2);
    return;
  }
  handleCommand(Serial.readStringUntil('\n'));
}
