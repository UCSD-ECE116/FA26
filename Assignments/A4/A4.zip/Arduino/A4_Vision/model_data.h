#pragma once

extern const unsigned char g_model_data[];
extern const unsigned int g_model_data_len;
