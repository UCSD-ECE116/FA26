# A4 engineering report

Replace every prompt. Keep the report concise and cite the submitted file or notebook cell that
supports each quantitative claim.

## 1. Visual task and requirement

State the intended use, labels, positive class, more costly error, selected task metric, and
predeclared validation minimum. Explain how the two classes can be distinguished with the XIAO
camera.

## 2. Sensor-native dataset

Report counts and capture-session IDs for each class and split. Explain the physical variation
within each class and the differences between train, validation, and held-out sessions. Record the
prepared dataset SHA-256 and duplicate/session checks. If you added sourced training images,
report their counts and origin separately from the required XIAO captures.

## 3. Model and device iterations

| ID | Question | Resolution | Alpha | Host int8 balanced accuracy | Device validation balanced accuracy | Device task metric | Int8 bytes | Flash | Arena used | Median inference | Result |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| TODO | TODO | TODO | TODO | TODO | TODO | TODO | TODO | TODO | TODO | TODO | TODO |

Identify one controlled comparison. Explain separately what the host results and the recorded-image
on-device results support. Name every failed requirement for each rejected candidate.

## 4. Selection and held-out device result

State which candidates passed every requirement and which passing candidate you selected before
held-out evaluation. Explain the tradeoff. Report the selected model's device-held-out confusion matrix,
balanced accuracy, and per-class recall without using them to revise selection.

## 5. Deployment integrity and resources

| Claim | Result | Evidence location |
|---|---:|---|
| Selected, embedded, and flashed model identity | TODO | TODO |
| Label and tensor contract | TODO | TODO |
| Program flash | TODO | TODO |
| Static RAM | TODO | TODO |
| Tensor arena allocated and used | TODO | TODO |
| Golden argmax agreement | TODO | TODO |
| Largest golden score difference | TODO | TODO |
| Median recorded-image preprocessing on the XIAO | TODO | TODO |
| Median recorded-image inference on the XIAO | TODO | TODO |
| Median live camera-to-result latency | TODO | TODO |

## 6. Live demonstration

Describe the final live demonstration of both classes. Compare it with recorded device-held-out
behavior. The captioned GIF is a functional demonstration, not a replacement accuracy dataset.

## 7. Decision and limitation

State whether the selected system satisfies every published requirement. Name the most important
unsupported claim or limitation and one next test that would reduce that uncertainty.

## 8. Rubric evidence index

| Rubric area | Primary submitted evidence |
|---|---|
| Guided Lab | TODO |
| Task and dataset | TODO |
| Iterations and comparison | TODO |
| Quantitative requirements | TODO |
| Deployment and parity | TODO |
| Held-out on-device evaluation and live demonstration | TODO |
