# Assignment 4: Design and deploy a tiny visual capability

**Due:** Friday, November 20, 2026, at 5:00 p.m. Pacific Time

**Automatic grace period:** through Friday, November 20, at 11:59 p.m. Pacific Time

**Weekend late window:** Saturday, November 21, through Sunday, November 22, at 11:59 p.m.
Pacific Time; one deduction of 25% of the earned score

**Hard close:** Monday, November 23, at 12:00 a.m. Pacific Time

## What you will build

You will create a binary visual wake word for the XIAO ESP32-S3 Sense. You will define two
visually distinguishable classes, collect images, adapt a pretrained MobileNetV2 model, optimize it for
the microcontroller, convert it to full-int8 TensorFlow Lite, and measure the deployed system.

The guided Lab teaches the complete workflow with an apple-versus-banana example. The Challenge
applies the Lab workflow to a task and dataset that you design.

Complete the tutorial during the **Thursday, November 12 structured Lab**. Use the **Thursday,
November 19 open-work session** for supported Challenge integration and testing.

| Phase | Your work | Evidence you retain |
|---|---|---|
| Guided Lab | Follow the complete fine-tune, optimize, convert, and deploy tutorial. | Executed Lab notebook, Lab embed record, physical checkoff. |
| Task and data | Define two classes and collect separate train, validation, and test sessions. | Prepared dataset ZIP and task contract. |
| Model experiments | Run the baseline and at least two deliberate alternatives. | Executed Challenge notebook and experiment table. |
| Selection | Choose with validation evidence, then evaluate the test split once. | Selected int8 model and selection record. |
| Deployment | Establish identity and parity before timing or live trials. | Embed, compile, golden, timing, and camera records. |
| Decision | Explain what the system can and cannot support. | One completed A4 report. |

## Supported environment

- Google Colab `2026.04`, Python 3.12, TensorFlow `2.19.0`, and Keras `3.13.2`;
- Espressif Arduino core `3.3.10`;
- board target `esp32:esp32:XIAO_ESP32S3:PSRAM=opi`;
- XIAO ESP32-S3 Sense with its camera expansion board; and
- `Libraries/Chirale_TensorFlowLite-2.0.0.zip`.

Do not replace the supplied TensorFlow Lite Micro runtime, camera path, tensor arena, or serial
protocol.

## Open either notebook in Colab

1. Upload the notebook from the starter ZIP's `Python/` folder with **File > Upload notebook**.
2. Select **Runtime > Change runtime type**, choose runtime version **2026.04**, and select a T4
   GPU.
3. Run the notebook's environment cell and upload the complete A4 starter ZIP when prompted.
4. Confirm `companion files: PASS`, TensorFlow `2.19.0`, and Keras `3.13.2`.
5. Download the executed notebook when finished and replace the unfinished copy in your local
   package.

Do not run `pip install` in Colab. The selected past runtime already provides the supported
versions.

# Guided Lab

Complete `Python/A4_Lab.ipynb` during the November 12 structured Lab. The notebook provides all
training and conversion code.

The Lab contains four prediction checkpoints. Complete and run each single-column Colab form
before its experiment; the experiment stops if a choice or reasoning field is missing. Predictions
are not graded for being correct. After each experiment, the notebook displays the committed
prediction, the measured or reference result, and `MATCH` or `REVISE` feedback.

## Lab workflow

1. Predict the roles of the train, validation, and test splits, then inspect the supplied
   apple-versus-banana dataset.
2. Predict what fine-tuning, width, and internal resolution will change.
3. Fine-tune the prescribed `R96-A050`, `R96-A035`, and `R64-A035` models and review the feedback.
4. Compare `R96-A050` with `R96-A035` to isolate width. Compare `R96-A035` with `R64-A035` to
   isolate internal resolution.
5. Predict the effect and evidence boundary of full-int8 quantization, then compare validation
   behavior and artifact bytes.
6. Match compiler, serial, and live-camera evidence to the claims they support.
7. Use the supplied accepted Lab artifact for the physical deployment tutorial.

Fine-tuning adapts pretrained features to the fruit task. Fine-tuning does not make the model
smaller.
Width and internal resolution scale different model costs. Quantization changes the numerical
representation used for inference.

Use the Lab results to answer three separate questions. The notebook's validation metrics show
whether a configuration recognizes both classes after conversion. Artifact bytes and the compiler
summary show storage and program-memory cost. `INFO`, `GOLDEN`, and `TIMING 20` show the deployed
model's memory allocation, agreement with the host reference, and repeated inference time on the
XIAO. A host accuracy or file-size result does not establish device behavior.

## Lab device checkoff

From the package root, embed the accepted Lab artifact:

```bash
python3 Python/export_tflite_model.py \
  --model "Lab Fixture/lab_fruit_full_int8.tflite" \
  --labels "Lab Fixture/labels.txt" \
  --model-id ece116-a4-lab-fruit-binary-v3 \
  --output Arduino/A4_Vision \
  --record evidence/lab_embed_record.json
```

Install the supplied TFLM ZIP, compile, and flash `Arduino/A4_Vision`. Open the Serial Monitor at
`921600` baud with newline termination. Send:

```text
INFO
GOLDEN
TIMING 20
```

Stop if either golden row changes its host/device winning class. For checkoff, show the
executed Lab notebook, embed record, compiler summary, `INFO` output, passing golden summary,
and `TIMING 20` output. Record the compiler's flash and static-RAM figures, the allocated and used
tensor-arena bytes from `INFO`, and the median of the 20 printed `inference_us` values. Be prepared
to explain why compilation alone does not establish correct inference.

# Challenge

Design a binary visual task for the XIAO camera. Capture separate training, validation, and
held-out sessions through the supplied XIAO capture rig. Fine-tune and quantize the supplied
baseline plus at least two deliberate alternatives. Flash every candidate and evaluate the same
recorded validation JPEGs through the actual XIAO preprocessing and TFLM runtime. Continue until a
candidate satisfies every requirement. Select one passing model, evaluate the held-out folder once,
and demonstrate the selected system with the live camera.

The Challenge is intentionally stated as a design brief. The sections below define its boundaries
and evidence; they are not a sequence of hidden syntax exercises.

In this assignment, **on-device evaluation using recorded images** means sending a previously
captured XIAO JPEG from the computer back to the XIAO over serial. This is a
hardware-in-the-loop test: the physical XIAO decodes the JPEG, resizes and quantizes the image,
and runs the flashed TensorFlow Lite Micro model. No new camera frame is captured during this
evaluation. The supplied `replay_dataset.py` tool performs this procedure so that every candidate
can be tested with identical images. The final live demonstration separately checks the complete
camera-to-result path.

## Define the two classes

Choose any two visually distinguishable classes that you can capture and demonstrate with the
XIAO camera. Examples include object present versus absent, drawer open versus closed, package
orientation A versus B, or one gesture versus background.

Before training, record in `evidence/task_contract.json`:

- the task and intended use;
- the two labels and positive class;
- which error is more costly;
- whether positive-class recall or negative-class recall is your task metric; and
- the minimum value that metric must reach on validation data.

## Capture the dataset with the XIAO

Keep the Lab firmware on the board, close Serial Monitor, and start the local capture interface:

```bash
python3 Python/capture_dataset.py \
  --port <serial-port> \
  --root Data/custom_source \
  --labels <label-a> <label-b>
```

The browser interface previews the exact 240 by 240 JPEG returned by the XIAO and saves labeled
captures on the computer. The capture interface also records the split, label, session, image
SHA-256, byte count, camera dimensions, and capture time in `capture_manifest.csv`.

For each class, capture at least 60 training, 20 validation, and 20 held-out test images with the
XIAO. Use lowercase label names containing only letters, digits, and underscores. Use distinct
session IDs for train, validation, and test. Vary position, distance, orientation, and lighting
within each class. Do not distribute adjacent captures from one setup across splits.

Optional: Add sourced images to the training folders. Sourced images do not count toward the 60
required XIAO captures per class. Do not place sourced images in the validation or held-out test
folders. In your report, identify whether you used sourced training images and where they came
from.

Prepare the compact submission archive:

```bash
python3 Python/prepare_custom_dataset.py \
  --source path/to/custom_source \
  --task-name "your task name" \
  --output Data/custom_dataset.zip
```

The script verifies the required XIAO capture counts, removes metadata, standardizes each JPEG at
240 by 240, preserves capture-session provenance, marks supplemental training images as sourced,
writes a manifest, rejects duplicate images, rejects sourced validation or held-out images, and
rejects sessions shared across splits. Review the counts and archive digest before training.

## Conduct the model experiments

Begin with the supplied `R96-A050` baseline. Run at least two additional configurations chosen
from this supported design space:

| Internal resolution | Width multiplier (`alpha`) |
|---:|---:|
| 64 | 0.35, 0.50 |
| 80 | 0.35, 0.50 |
| 96 | 0.35, 0.50 |

Before each additional run, state what changed and what you expect to learn. Include at least one
controlled comparison: two runs in which only resolution or only alpha changes. Keep the supplied
data pipeline, augmentation, optimizer, learning rates, and epoch budget fixed.

Every candidate is fine-tuned, converted to full-int8 TensorFlow Lite, and retained in the
notebook's `A4_candidates.zip` download. Extract that ZIP into the local A4 package. The extracted
ZIP adds the `candidates/` directory and places the prepared dataset and host records in their
required `Data/` and `evidence/` locations.

## Test each candidate on the XIAO

Colab produced at least three candidate models. You will test the same validation images with each
model on the XIAO. Complete this loop for one candidate before moving to the next:

1. place the candidate in the supplied Arduino sketch;
2. compile and flash the sketch;
3. evaluate the complete recorded validation split on the XIAO; and
4. save the candidate's device results.

Do not use the held-out test split during this loop.

### Confirm the candidate files

After extracting `A4_candidates.zip` into the package, confirm that `candidates/` contains one
folder for every configuration you trained. A typical result begins with these folders:

```text
candidates/
  R96-A050/
  R96-A035/
  R80-A035/
```

The folder names are the candidate IDs. The commands that follow use `R96-A050`, the required
baseline, as a complete example.

### Prepare candidate R96-A050

Run these commands from the A4 package root. The first command places the exact `R96-A050` model
in the Arduino sketch. The second command places the two saved host examples and their expected
scores in the same sketch. The generated Arduino files are overwritten when you prepare the next
candidate.

```bash
python3 Python/export_tflite_model.py \
  --model candidates/R96-A050/model_full_int8.tflite \
  --labels candidates/R96-A050/labels.txt \
  --model-id R96-A050 \
  --output Arduino/A4_Vision \
  --record evidence/embed/R96-A050.json

python3 Python/export_golden_header.py \
  --inputs candidates/R96-A050/golden_inputs.npy \
  --scores candidates/R96-A050/golden_scores_full_int8.npy \
  --truth candidates/R96-A050/golden_labels.npy \
  --labels candidates/R96-A050/labels.txt \
  --output Arduino/A4_Vision/golden_inputs.h
```

Check `evidence/embed/R96-A050.json`. Its `model_id` must be `R96-A050`, and its labels must match
your task contract.

### Compile and flash candidate R96-A050

1. Open `Arduino/A4_Vision/A4_Vision.ino` in Arduino IDE.
2. Select ESP32 core `3.3.10` and board target
   `esp32:esp32:XIAO_ESP32S3:PSRAM=opi`.
3. Compile the sketch.
4. Save the FQBN, core version, flash summary, RAM summary, and compiler output in
   `evidence/compile/R96-A050.txt`.
5. Upload the sketch to the XIAO.

Compilation only proves that the firmware was built. The recorded-image validation run checks the
model that is actually running on the board.

### Evaluate the recorded validation images with candidate R96-A050

Close Arduino Serial Monitor before running `replay_dataset.py`. Replace `<serial-port>` with the
port used by your XIAO; for example, `/dev/cu.usbmodem1101` on one macOS system. The script name
uses *replay* as shorthand for the on-device evaluation using recorded images defined earlier.

```bash
python3 Python/replay_dataset.py \
  --port <serial-port> \
  --dataset Data/custom_dataset.zip \
  --split validation \
  --candidate R96-A050 \
  --compile-report evidence/compile/R96-A050.txt \
  --output evidence/device_validation/R96-A050.csv
```

The command stops if the flashed model is not `R96-A050` or golden parity fails. A successful run
creates both of these files:

```text
evidence/device_validation/R96-A050.csv
evidence/device_validation/R96-A050.summary.json
```

Open the summary and confirm that `candidate_id` is `R96-A050`, `split` is `validation`,
`golden_passed` is `true`, and the row count matches your validation set.

### Repeat for the remaining candidate IDs

Return to **Prepare candidate R96-A050** and repeat the preparation, compile, flash, and
recorded-image evaluation steps for every other folder in `candidates/`. Replace every occurrence
of `R96-A050` with the next candidate ID. For example, when testing `R96-A035`, the embed record,
compiler record, device-validation CSV, and summary must all contain `R96-A035` in their filenames.

The generated files in `Arduino/A4_Vision/` are expected to change between candidates. The files
under `evidence/` use different candidate IDs, so the previous measurements are retained.

### Compare the completed device results

After every candidate has a validation CSV and summary, run:

```bash
python3 Python/evaluate_device_candidates.py \
  --candidates candidates \
  --device-results evidence/device_validation \
  --task-contract evidence/task_contract.json \
  --output evidence/device_experiment_results.csv
```

The output table has one row per candidate. `passes_device_gate` is `True` only when that candidate
satisfies every published requirement. `failed_requirements` names the measurements that did not
pass.

The evidence sources in this table are different: host metrics come from Colab, artifact identity
comes from the embed record, flash and static RAM come from compilation, and validation quality,
arena use, and latency come from recorded-image evaluation on the XIAO. Candidate selection uses
the XIAO validation results; host results remain diagnostic.

Each requirement is graded independently, but successful completion requires one model that
satisfies all of them:

| Device requirement | Threshold |
|---|---:|
| Recorded-image device-validation balanced accuracy | at least `0.70` |
| Predeclared recorded-image device metric | at least your recorded minimum |
| Full-int8 artifact size | at most `700000` bytes |
| Float-to-int8 host balanced-accuracy decrease | at most `0.10` |
| Program flash `[COMPILE]` | at most `1500000` bytes |
| Static RAM `[COMPILE]` | at most `64000` bytes |
| Tensor arena `[DEVICE]` | at most `524288` bytes in PSRAM |
| Median repeated inference `[DEVICE]` | at most `850000 us` |
| Median recorded-image processing time (`replay_to_result_us`) `[DEVICE]` | at most `1000000 us` |
| Golden score difference `[DEVICE]` | at most `0.06` per row |
| Golden argmax agreement `[DEVICE]` | every row |

If none of the first three candidates passes, diagnose the failed measurements, add another
supported experiment in Colab, and repeat. Do not evaluate the held-out test split while choosing.

## Select, then evaluate the held-out set once

Choose one row whose `passes_device_gate` value is `True`, and record that candidate ID before
opening the test split. The commands below show what to run if the selected ID is `R80-A035`.
`R80-A035` is only an example; use the passing candidate you selected from your own results.

Keep the selected candidate flashed and run one recorded-image evaluation of the held-out split:

```bash
python3 Python/replay_dataset.py \
  --port <serial-port> \
  --dataset Data/custom_dataset.zip \
  --split test \
  --candidate R80-A035 \
  --compile-report evidence/compile/R80-A035.txt \
  --output evidence/device_test/R80-A035.csv
```

Freeze the selection and submission artifacts:

```bash
python3 Python/finalize_selection.py \
  --candidates candidates \
  --device-experiments evidence/device_experiment_results.csv \
  --selected-id R80-A035 \
  --validation-summary evidence/device_validation/R80-A035.summary.json \
  --test-summary evidence/device_test/R80-A035.summary.json \
  --dataset Data/custom_dataset.zip \
  --task-contract evidence/task_contract.json
```

## Demonstrate the selected model live

Run the final evidence collector without a labeled camera protocol. Continue using the same
selected candidate ID; this example therefore uses `R80-A035`:

```bash
python3 Python/run_device_protocol.py \
  --port <serial-port> \
  --selected-dir selected \
  --candidate R80-A035 \
  --camera-timing 20 \
  --output evidence/final_device
```

Record a captioned GIF, at most 15 seconds long, showing both classes through the live camera with
the serial scores visible. The recorded-image held-out result is the quantitative accuracy
evaluation. The GIF establishes that the complete camera path performs the intended task. Physical
power and energy measurement are not part of A4.

## Complete the report

Fill in `Documentation/A4_REPORT.md`. The report asks for:

- the task, intended use, labels, and error consequences;
- dataset collection and split decisions;
- all model experiments and the question each answered;
- the passing set and selected model;
- validation, held-out, and live-camera results as separate evidence;
- flash, memory, parity, and latency measurements;
- the accepted tradeoff; and
- the most important limitation and next test.

## Submission checklist

Submit one ZIP containing:

1. executed `Python/A4_Lab.ipynb` and `Python/A4_Challenge.ipynb`;
2. `Data/custom_dataset.zip`;
3. `candidates/` with each full-int8 candidate, host result, labels, and golden vectors;
4. `evidence/task_contract.json`, `experiment_results.csv`, and
   `device_experiment_results.csv`;
5. each candidate's embed record, compiler output, device-validation CSV, and summary JSON;
6. `evidence/selected_model_record.json`, `selected_model_full_int8.tflite`, and the selected
   device-held-out CSV and summary;
7. `evidence/final_device/` with golden, inference timing, live camera timing, and raw serial
   records;
8. completed `Documentation/A4_REPORT.md`;
9. `Arduino/A4_Vision/` with the selected embedded model; and
10. one captioned GIF, at most 15 seconds, showing both classes and visible serial scores.

Submit every candidate int8 artifact so staff can reproduce the comparisons. Do not include the
larger Keras models, SavedModels, or float32 TensorFlow Lite intermediates.

Run the visible checker from the package root:

```bash
python3 Python/a4_submission_check.py . --json evidence/submission_check.json
```

The checker validates structure, identities, measurements, and row counts. It cannot decide whether
the recorded dataset represents the intended use, whether the experiment supports the stated
comparison, or whether the engineering argument is persuasive.

## Individual work and assistance

This is an individual assignment. You may discuss concepts and debugging approaches. Your task,
dataset, models, measurements, and explanations must be your own. Disclose substantive use of
generative AI or external code in the package README. Never fabricate training, hardware, or
camera evidence.
