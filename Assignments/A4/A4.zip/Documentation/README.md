# A4 documentation

- `A4_Handout.md` is the complete student workflow and submission contract.
- `MODEL_INTERFACE.md` fixes the model and firmware boundary.
- `A4_REPORT.md` is the report template completed for submission.

The guided Lab notebook contains the tutorial. The Challenge is intentionally presented as one
design brief with explicit constraints and evidence, not as a second sequence of tutorial steps.
