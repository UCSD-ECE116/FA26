# A4 model and deployment interface

| Boundary | Required value |
|---|---|
| Task | Binary classification with two student-defined labels |
| Source frame | XIAO Sense camera in upright orientation |
| Geometry | Centered square crop, then bilinear resize |
| External model input | Float32 RGB `(1, 96, 96, 3)`, values 0 through 255 |
| Internal resolution | `64`, `80`, or `96` |
| MobileNetV2 alpha | `0.35` or `0.50` |
| Normalization | Inside the model: `x * (1/127.5) - 1` |
| Model output | Two scores in `selected/labels.txt` order |
| Deployment artifact | Full-int8 TensorFlow Lite with uint8 input and output |

The prepared dataset, notebook, selected-model record, exporter, firmware metadata, golden header,
and serial records must use the same label order. Do not add another normalization step in
firmware.

`Python/export_tflite_model.py` embeds the exact `.tflite` bytes and records their SHA-256 digest.
The sketch supplies the interpreter, all-ops resolver, `524288`-byte PSRAM tensor arena, camera
decoder, resize path, and serial protocol. Students do not replace those components.

Validation proceeds in this order: XIAO JPEG capture and dataset audit; training and int8
conversion; candidate embedding and compilation; physical golden parity; on-device evaluation of
identical recorded validation images for every candidate; selection; one on-device evaluation of
the selected model with held-out images; and a live-camera demonstration. Host inference is
diagnostic; the recorded-image hardware-in-the-loop results are the selection authority.
