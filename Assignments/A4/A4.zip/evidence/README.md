# A4 evidence workspace

The notebooks and supplied tools create the final evidence structure:

```text
evidence/
  task_contract.json
  experiment_results.csv
  device_experiment_results.csv
  embed/<candidate-id>.json
  compile/<candidate-id>.txt
  device_validation/<candidate-id>.csv
  device_validation/<candidate-id>.summary.json
  device_test/<selected-id>.csv
  device_test/<selected-id>.summary.json
  selected_model_full_int8.tflite
  selected_model_record.json
  final_device/golden_device.json
  final_device/timing.csv
  final_device/camera_timing.csv
  final_device/serial_capture.txt
```

Do not replace raw rows with screenshots or prose summaries.
