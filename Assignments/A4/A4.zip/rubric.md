# A4 grading rubric

Every requirement is expected and scored directly. Performance on one row does not erase credit
for a different learning outcome. Raw accuracy is not ranked across student-defined tasks.

## 1. Guided Lab: 10 points

| Evidence | Points |
|---|---:|
| Complete four Lab checkpoints and the executed fine-tuning, scaling, quantization, and deployment workflow | 4 |
| Correct distinction among fine-tuning, width, resolution, and quantization | 3 |
| Correct explanation of host, embedded, compiler, device, and camera boundaries | 3 |

## 2. Task and sensor-native dataset: 15 points

| Evidence | Points |
|---|---:|
| Two clearly defined classes that can be captured and demonstrated with the XIAO | 3 |
| Costly error and predeclared metric are aligned | 3 |
| Required XIAO-captured counts and class balance | 3 |
| Separate capture sessions for train, validation, and held-out data | 3 |
| Complete manifest, hashes, duplicate checks, sourced-data disclosure, and dataset limitations | 3 |

Creativity and task difficulty are not directly graded.

## 3. Deliberate iterations and comparison: 15 points

| Evidence | Points |
|---|---:|
| Baseline plus at least two additional valid candidates | 5 |
| A useful question is recorded before every additional run | 4 |
| One valid comparison changes only width or only internal resolution | 3 |
| Compare/contrast explanation identifies failed requirements without unsupported causal claims | 3 |

The iteration and comparison points are independent of whether a candidate reaches the
performance thresholds.

## 4. Quantitative model and device requirements: 25 points

| Independent requirement | Points |
|---|---:|
| Device-validation balanced accuracy at least `0.70` | 4 |
| Predeclared device-validation task metric is met | 4 |
| Full-int8 artifact at most `700000` bytes | 3 |
| Float-to-int8 host balanced-accuracy decrease at most `0.10` | 3 |
| Program flash at most `1500000` bytes | 2 |
| Static RAM at most `64000` bytes | 2 |
| Tensor arena at most `524288` bytes in PSRAM | 2 |
| Median device inference at most `850000 us` | 2 |
| Median recorded-image processing time (`replay_to_result_us`) at most `1000000 us` | 2 |
| Complete, reproducible quantitative table | 1 |

Each threshold is scored independently. Successful completion still requires one candidate that
satisfies all published requirements; students continue iterating until one does.

## 5. Deployment identity and parity: 15 points

| Evidence | Points |
|---|---:|
| Candidate, embedded, flashed, and submitted artifact hashes agree | 5 |
| Labels, tensor shapes, dtypes, scales, and zero points agree | 3 |
| Pinned runtime, core, FQBN, and complete compiler evidence | 2 |
| Golden rows preserve host argmax | 3 |
| Every golden score difference is at most `0.06` | 2 |

## 6. Selection and held-out on-device evaluation: 10 points

| Evidence | Points |
|---|---:|
| Selection is recorded from device validation before held-out evaluation | 3 |
| Selected candidate passes every published requirement | 3 |
| Held-out folder is evaluated once with the selected model on the XIAO | 2 |
| Held-out result is interpreted without reselection | 2 |

## 7. Live demonstration and engineering report: 10 points

| Evidence | Points |
|---|---:|
| Twenty complete live camera-to-result timing rows | 2 |
| Captioned GIF demonstrates both classes with visible scores | 2 |
| Report separates host, recorded validation, held-out, and live claims | 2 |
| Selected tradeoff is supported by the submitted evidence | 2 |
| Consequential limitation, next test, and assistance disclosure | 2 |

## Quantitative and qualitative grading

Quantitative evidence includes counts, metrics, hashes, resource values, timing, and row
completeness. Staff recompute the quantitative values when possible. Qualitative evidence includes
task suitability, experiment questions, comparison reasoning, tradeoffs, and limitations. Staff
judge the qualitative areas against the published descriptions in this rubric.

Honest unsuccessful work earns the points directly supported by its evidence. Evidence for
incomplete work does not substitute for requirements that were not completed. Fabricated evidence
receives no credit and is handled under the course integrity policy.
