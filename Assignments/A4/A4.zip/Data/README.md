# A4 data

`a4_lab_fruit_binary_dataset.zip` is the course-supplied dataset used only by the guided Lab.

For the Challenge, run `Python/capture_dataset.py`. The capture script saves exact 240 by 240 XIAO
JPEGs and a capture manifest in this structure:

```text
custom_source/
  train/<label_a>/
  train/<label_b>/
  validation/<label_a>/
  validation/<label_b>/
  test/<label_a>/
  test/<label_b>/
```

Use a separate capture-session ID for each split. The required minimum images in every split must
be XIAO captures. Optional sourced images may be added to the training folders, but they do not
count toward the required XIAO training minimum and may not appear in validation or test folders.
Then run `Python/prepare_custom_dataset.py` to create `Data/custom_dataset.zip`. The prepared
archive and its JPEGs are part of the final submission.
