"""Shared serial transport for camera capture and recorded-image evaluation on the XIAO."""

from __future__ import annotations

import re
import time
import zlib

import serial


def fields(line: str) -> dict[str, str]:
    return dict(re.findall(r"([A-Za-z0-9_]+)=([^ ]+)", line))


def score_values(value: str, labels: tuple[str, str]) -> list[float]:
    parsed = {}
    for item in value.split(","):
        label, number = item.split(":", 1)
        parsed[label] = float(number)
    if set(parsed) != set(labels):
        raise ValueError(f"device score labels {sorted(parsed)} do not match {labels}")
    return [parsed[label] for label in labels]


class A4Serial:
    def __init__(self, port: str, baud: int = 921600):
        self.serial = serial.Serial(port, baudrate=baud, timeout=0.25, write_timeout=10)
        time.sleep(1.2)
        self.serial.reset_input_buffer()

    def close(self) -> None:
        self.serial.close()

    def write_command(self, command: str) -> None:
        self.serial.write((command + "\n").encode())
        self.serial.flush()

    def read_line(self, timeout: float = 30.0) -> str:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            line = self.serial.readline().decode("utf-8", errors="replace").strip()
            if line:
                return line
        raise TimeoutError("timed out waiting for a device line")

    def read_until(self, prefixes: tuple[str, ...], timeout: float = 30.0) -> str:
        deadline = time.monotonic() + timeout
        seen = []
        while time.monotonic() < deadline:
            line = self.read_line(max(0.1, deadline - time.monotonic()))
            seen.append(line)
            if line.startswith(prefixes):
                return line
        raise TimeoutError(f"timed out waiting for {prefixes}; received {seen[-5:]}")

    def info(self) -> dict[str, str]:
        self.write_command("INFO")
        line = self.read_until(("A4_INFO ", "A4_SETUP_ERROR", "COMMAND_ERROR"))
        if not line.startswith("A4_INFO "):
            raise RuntimeError(line)
        return fields(line)

    def capture_jpeg(self, capture_id: str) -> tuple[bytes, dict[str, str]]:
        self.write_command(f"CAPTURE_JPEG {capture_id}")
        header = self.read_until(("JPEG_BEGIN ", "CAPTURE_ERROR", "COMMAND_ERROR"), 30.0)
        if not header.startswith("JPEG_BEGIN "):
            raise RuntimeError(header)
        metadata = fields(header)
        expected = int(metadata["bytes"])
        payload = bytearray()
        deadline = time.monotonic() + 30.0
        while len(payload) < expected and time.monotonic() < deadline:
            chunk = self.serial.read(expected - len(payload))
            if chunk:
                payload.extend(chunk)
        if len(payload) != expected:
            raise TimeoutError(f"received {len(payload)} of {expected} JPEG bytes")
        ending = self.read_until(("JPEG_END ", "CAPTURE_ERROR"), 5.0)
        if not ending.startswith("JPEG_END "):
            raise RuntimeError(ending)
        actual_crc = zlib.crc32(payload) & 0xFFFFFFFF
        expected_crc = int(metadata["crc32"], 16)
        if actual_crc != expected_crc:
            raise ValueError(
                f"capture CRC mismatch: device={expected_crc:08x} host={actual_crc:08x}"
            )
        return bytes(payload), metadata

    def replay_jpeg(
        self,
        trial_id: str,
        true_label: str,
        split: str,
        payload: bytes,
    ) -> dict[str, str]:
        checksum = zlib.crc32(payload) & 0xFFFFFFFF
        self.write_command(
            f"REPLAY_JPEG {trial_id} {true_label} {split} {len(payload)} {checksum:08x}"
        )
        ready = self.read_until(("REPLAY_READY ", "REPLAY_ERROR", "COMMAND_ERROR"), 10.0)
        if not ready.startswith("REPLAY_READY "):
            raise RuntimeError(ready)
        for start in range(0, len(payload), 256):
            chunk = payload[start : start + 256]
            written = self.serial.write(chunk)
            if written != len(chunk):
                raise IOError(f"serial write accepted {written} of {len(chunk)} bytes")
            self.serial.flush()
            time.sleep(0.002)
        result = self.read_until(("REPLAY ", "REPLAY_ERROR", "INFERENCE_ERROR"), 60.0)
        if not result.startswith("REPLAY "):
            raise RuntimeError(result)
        value = fields(result)
        if int(value["crc32"], 16) != checksum:
            raise ValueError("XIAO result CRC does not match the transmitted JPEG")
        return value
