#!/usr/bin/env python3
"""Export one golden input per class as a flash-resident Arduino header."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import numpy as np


def format_values(values: np.ndarray, width: int = 24) -> list[str]:
    flat = values.reshape(-1)
    return [", ".join(str(int(value)) for value in flat[start : start + width]) for start in range(0, len(flat), width)]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--truth", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    inputs = np.asarray(np.load(args.inputs), dtype=np.uint8)
    scores = np.asarray(np.load(args.scores), dtype=np.float32)
    truth = np.asarray(np.load(args.truth), dtype=np.int32)
    labels = args.labels.read_text(encoding="utf-8").splitlines()
    if inputs.ndim != 4 or inputs.shape[1:] != (96, 96, 3):
        raise ValueError(f"unexpected golden input shape: {inputs.shape}")
    if scores.shape != (len(inputs), len(labels)) or truth.shape != (len(inputs),):
        raise ValueError("golden inputs, scores, truth, and labels do not agree")

    selected = []
    for class_index in range(len(labels)):
        matches = np.flatnonzero(truth == class_index)
        if not len(matches):
            raise ValueError(f"no golden input for class {labels[class_index]}")
        selected.append(int(matches[0]))

    chosen_inputs = inputs[selected]
    chosen_scores = scores[selected]
    lines = [
        "#pragma once",
        "",
        "#include <Arduino.h>",
        "",
        f"constexpr size_t kA4GoldenCount = {len(selected)};",
        "constexpr size_t kA4GoldenWidth = 96;",
        "constexpr size_t kA4GoldenHeight = 96;",
        "constexpr size_t kA4GoldenChannels = 3;",
        "constexpr size_t kA4GoldenBytes = kA4GoldenWidth * kA4GoldenHeight * kA4GoldenChannels;",
        f"constexpr size_t kA4GoldenLabelCount = {len(labels)};",
        "",
        "static const char *const kA4GoldenLabels[kA4GoldenLabelCount] = {",
        *[f'    "{label}",' for label in labels],
        "};",
        "",
        "static const uint8_t kA4GoldenInputs[kA4GoldenCount][kA4GoldenBytes] PROGMEM = {",
    ]
    for input_value in chosen_inputs:
        lines.append("    {")
        lines.extend(f"        {row}," for row in format_values(input_value))
        lines.append("    },")
    lines.extend(
        [
            "};",
            "",
            "static const float kA4GoldenExpected[kA4GoldenCount][kA4GoldenLabelCount] = {",
        ]
    )
    for row in chosen_scores:
        values = ", ".join(f"{float(value):.9f}f" for value in row)
        lines.append(f"    {{{values}}},")
    lines.extend(
        [
            "};",
            "",
            "static const uint8_t kA4GoldenExpectedClass[kA4GoldenCount] = {",
            "    " + ", ".join(str(int(np.argmax(row))) for row in chosen_scores),
            "};",
            "",
            "static const char *const kA4GoldenSha256[kA4GoldenCount] = {",
        ]
    )
    for input_value in chosen_inputs:
        digest = hashlib.sha256(input_value.tobytes()).hexdigest()
        lines.append(f'    "{digest}",')
    lines.extend(["};", ""])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {len(selected)} golden inputs to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
