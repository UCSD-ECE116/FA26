#!/usr/bin/env python3
"""Visible structural and evidence checks for the redesigned A4 submission."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import statistics
import sys
import zipfile
from collections import Counter
from pathlib import Path


HOST = {
    "minimum_balanced_accuracy": 0.70,
    "maximum_int8_bytes": 700_000,
    "maximum_quantization_drop": 0.10,
}
DEVICE = {
    "maximum_flash_bytes": 1_500_000,
    "maximum_static_ram_bytes": 64_000,
    "maximum_arena_bytes": 524_288,
    "maximum_median_inference_us": 850_000,
    "maximum_median_replay_to_result_us": 1_000_000,
    "maximum_median_camera_to_result_us": 1_000_000,
    "maximum_golden_score_difference": 0.06,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def add(checks: list[dict[str, object]], name: str, passed: bool, detail: object) -> None:
    checks.append({"name": name, "status": "pass" if passed else "fail", "detail": detail})


def read_csv(path: Path) -> tuple[list[dict[str, str]], set[str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return list(reader), set(reader.fieldnames or [])


def finite(value: object) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def check_notebook(path: Path, checks: list[dict[str, object]]) -> None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        cells = [cell for cell in value["cells"] if cell.get("cell_type") == "code"]
        executed = bool(cells) and all(cell.get("execution_count") is not None for cell in cells)
        errors = [
            output
            for cell in cells
            for output in cell.get("outputs", [])
            if output.get("output_type") == "error"
        ]
        add(checks, f"executed notebook: {path.name}", executed and not errors, {
            "code_cells": len(cells), "all_executed": executed, "saved_errors": len(errors)
        })
    except Exception as exc:
        add(checks, f"executed notebook: {path.name}", False, repr(exc))


def check_task_and_dataset(
    root: Path, checks: list[dict[str, object]]
) -> tuple[tuple[str, str], dict[str, object]]:
    try:
        contract = json.loads((root / "evidence/task_contract.json").read_text(encoding="utf-8"))
        labels = tuple(contract["labels"])
        contract_ok = (
            len(labels) == 2
            and len(set(labels)) == 2
            and all(re.fullmatch(r"[a-z][a-z0-9_]{0,20}", label) for label in labels)
            and contract["positive_label"] in labels
            and contract["quality_metric"] in {"positive_recall", "negative_recall"}
            and finite(contract["minimum_quality"])
            and 0 <= float(contract["minimum_quality"]) <= 1
            and all(str(contract[field]).strip() for field in ("task_name", "intended_use", "costly_error"))
        )
        archive_path = root / "Data/custom_dataset.zip"
        with zipfile.ZipFile(archive_path) as archive:
            names = set(archive.namelist())
            archive_labels = tuple(
                line.strip() for line in archive.read("labels.txt").decode().splitlines()
            )
            rows = list(csv.DictReader(archive.read("manifest.csv").decode().splitlines()))
            unsafe = [
                name for name in names if name.startswith("/") or ".." in Path(name).parts
            ]
        counts = Counter((row["split"], row["label"]) for row in rows)
        xiao_counts = Counter(
            (row["split"], row["label"])
            for row in rows
            if row.get("provenance") == "xiao"
        )
        sourced_rows = [row for row in rows if row.get("provenance") == "sourced"]
        sessions = {
            split: {
                row["session_id"]
                for row in rows
                if row["split"] == split and row.get("provenance") == "xiao"
            }
            for split in ("train", "validation", "test")
        }
        minimums = {"train": 60, "validation": 20, "test": 20}
        dataset_ok = (
            not unsafe
            and archive_labels == labels
            and len(rows) >= 200
            and len({row["sha256"] for row in rows}) == len(rows)
            and all(row.get("provenance") in {"xiao", "sourced"} for row in rows)
            and all(
                row.get("capture_id") and row.get("session_id")
                for row in rows
                if row.get("provenance") == "xiao"
            )
            and all(row["split"] == "train" for row in sourced_rows)
            and not (sessions["train"] & sessions["validation"])
            and not (sessions["train"] & sessions["test"])
            and not (sessions["validation"] & sessions["test"])
            and all(
                xiao_counts[(split, label)] >= minimums[split]
                for split in minimums
                for label in labels
            )
            and all(row["relative_path"] in names for row in rows)
        )
        add(checks, "binary task contract", contract_ok, contract)
        add(checks, "prepared custom dataset", dataset_ok, {
            "archive_sha256": sha256(archive_path),
            "rows": len(rows),
            "counts": {f"{split}/{label}": count for (split, label), count in sorted(counts.items())},
            "xiao_capture_counts": {
                f"{split}/{label}": count
                for (split, label), count in sorted(xiao_counts.items())
            },
            "sourced_training_rows": len(sourced_rows),
            "sessions": {split: sorted(value) for split, value in sessions.items()},
            "unsafe_members": unsafe,
        })
        return labels, contract  # type: ignore[return-value]
    except Exception as exc:
        add(checks, "task contract and custom dataset", False, repr(exc))
        return ("label_a", "label_b"), {"minimum_quality": 1.0}


def check_experiments(
    root: Path,
    labels: tuple[str, str],
    contract: dict[str, object],
    checks: list[dict[str, object]],
) -> str:
    try:
        host_rows, host_columns = read_csv(root / "evidence/experiment_results.csv")
        host_required = {
            "id", "resolution", "alpha", "float_balanced_accuracy",
            "int8_balanced_accuracy", "int8_bytes", "quantization_drop",
            "host_positive_recall",
        }
        pairs = []
        artifact_checks = []
        for row in host_rows:
            resolution = int(row["resolution"])
            alpha = float(row["alpha"])
            pairs.append((resolution, alpha))
            artifact = root / "candidates" / row["id"] / "model_full_int8.tflite"
            artifact_checks.append(
                artifact.is_file()
                and artifact.read_bytes()[4:8] == b"TFL3"
                and artifact.stat().st_size == int(row["int8_bytes"])
            )
        controlled = any(
            (left[0] == right[0]) ^ (left[1] == right[1])
            for index, left in enumerate(pairs)
            for right in pairs[index + 1 :]
        )
        host_passed = (
            host_required <= host_columns
            and len(host_rows) >= 3
            and pairs[0] == (96, 0.50)
            and len(set(pairs)) == len(pairs)
            and controlled
            and all(artifact_checks)
        )
        add(checks, "deliberate host model experiments", host_passed, {
            "rows": len(host_rows), "pairs": pairs, "controlled_comparison": controlled,
            "candidate_artifacts_match": artifact_checks,
        })

        device_rows, device_columns = read_csv(root / "evidence/device_experiment_results.csv")
        device_required = {
            "id", "device_validation_balanced_accuracy", "device_task_metric",
            "int8_bytes", "quantization_drop", "arena_used_bytes", "flash_bytes",
            "static_ram_bytes", "median_preprocess_us", "median_inference_us",
            "median_replay_to_result_us", "golden_max_absolute_score_difference",
            "failed_requirements", "passes_device_gate",
        }
        recomputed = []
        positive = contract["positive_label"]
        for row in device_rows:
            summary = json.loads(
                (root / "evidence/device_validation" / f"{row['id']}.summary.json").read_text(
                    encoding="utf-8"
                )
            )
            host = next(value for value in host_rows if value["id"] == row["id"])
            passed = (
                float(row["device_validation_balanced_accuracy"]) >= HOST["minimum_balanced_accuracy"]
                and float(row["device_task_metric"]) >= float(contract["minimum_quality"])
                and int(row["int8_bytes"]) <= HOST["maximum_int8_bytes"]
                and float(row["quantization_drop"]) <= HOST["maximum_quantization_drop"]
                and int(row["flash_bytes"]) <= DEVICE["maximum_flash_bytes"]
                and int(row["static_ram_bytes"]) <= DEVICE["maximum_static_ram_bytes"]
                and int(summary["arena_bytes"]) <= DEVICE["maximum_arena_bytes"]
                and float(row["median_inference_us"]) <= DEVICE["maximum_median_inference_us"]
                and float(row["median_replay_to_result_us"])
                <= DEVICE["maximum_median_replay_to_result_us"]
                and bool(summary["golden_passed"])
                and bool(summary["golden_argmax_agreement"])
                and float(summary["golden_max_absolute_score_difference"])
                <= DEVICE["maximum_golden_score_difference"]
            )
            recomputed.append((row["id"], passed, row["passes_device_gate"].lower() == "true"))
        device_passed = (
            device_required <= device_columns
            and {row["id"] for row in device_rows} == {row["id"] for row in host_rows}
            and all(expected == stated for _, expected, stated in recomputed)
            and any(expected for _, expected, _ in recomputed)
        )
        add(checks, "recorded-image candidate evaluation on the XIAO", device_passed, {
            "rows": len(device_rows), "gate_recomputation": recomputed,
        })
        return next((identifier for identifier, passed, _ in recomputed if passed), "")
    except Exception as exc:
        add(checks, "host and device candidate experiments", False, repr(exc))
        return ""


def check_selection(root: Path, labels: tuple[str, str], checks: list[dict[str, object]]) -> str:
    try:
        record = json.loads((root / "evidence/selected_model_record.json").read_text(encoding="utf-8"))
        artifact = root / "evidence/selected_model_full_int8.tflite"
        validation = record["device_validation"]
        held_out = record["device_held_out_test"]
        device_rows, _ = read_csv(root / "evidence/device_experiment_results.csv")
        selected_rows = [row for row in device_rows if row["id"] == record["selected_id"]]
        passed = (
            record["schema"] == "ece116.a4.selected-model.v3"
            and tuple(record["labels"]) == labels
            and record["artifact_sha256"] == sha256(artifact)
            and record["dataset_sha256"] == sha256(root / "Data/custom_dataset.zip")
            and len(selected_rows) == 1
            and selected_rows[0]["passes_device_gate"].lower() == "true"
            and validation["candidate_id"] == record["selected_id"]
            and validation["split"] == "validation"
            and held_out["candidate_id"] == record["selected_id"]
            and held_out["split"] == "test"
            and int(held_out["rows"]) >= 40
            and 0 <= float(held_out["balanced_accuracy"]) <= 1
            and artifact.read_bytes()[4:8] == b"TFL3"
        )
        add(checks, "device-validated selection and held-out on-device evaluation", passed, {
            "selected_id": record.get("selected_id"),
            "artifact_sha256": sha256(artifact),
            "device_validation": validation,
            "device_held_out_test": held_out,
        })
        return str(record["selected_id"])
    except Exception as exc:
        add(checks, "selected artifact and held-out record", False, repr(exc))
        return ""


def check_deployment(root: Path, labels: tuple[str, str], selected_id: str, checks: list[dict[str, object]]) -> None:
    try:
        artifact = root / "evidence/selected_model_full_int8.tflite"
        embed = json.loads(
            (root / "evidence/embed" / f"{selected_id}.json").read_text(encoding="utf-8")
        )
        metadata = (root / "Arduino/A4_Vision/model_metadata.h").read_text(encoding="utf-8")
        array = (root / "Arduino/A4_Vision/model_data.cpp").read_text(encoding="utf-8")
        embedded = bytes(int(value, 16) for value in re.findall(r"0x([0-9a-fA-F]{2})", array))
        digest = sha256(artifact)
        identity_ok = (
            embed["model_id"] == selected_id
            and tuple(embed["labels"]) == labels
            and embed["model_sha256"] == digest
            and digest in metadata
            and hashlib.sha256(embedded).hexdigest() == digest
        )
        add(checks, "selected and embedded artifact identity", identity_ok, {
            "selected_id": selected_id, "sha256": digest, "labels": labels
        })

        compile_text = (
            root / "evidence/compile" / f"{selected_id}.txt"
        ).read_text(encoding="utf-8")
        flash = re.search(r"Sketch uses (\d+) bytes", compile_text)
        static = re.search(r"Global variables use (\d+) bytes", compile_text)
        compile_ok = (
            bool(flash and static)
            and int(flash.group(1)) <= DEVICE["maximum_flash_bytes"]
            and int(static.group(1)) <= DEVICE["maximum_static_ram_bytes"]
            and "esp32:esp32:XIAO_ESP32S3:PSRAM=opi" in compile_text
            and "3.3.10" in compile_text
        )
        add(checks, "pinned compile and resource limits", compile_ok, {
            "flash_bytes": int(flash.group(1)) if flash else None,
            "static_ram_bytes": int(static.group(1)) if static else None,
        })

        golden = json.loads(
            (root / "evidence/final_device/golden_device.json").read_text(encoding="utf-8")
        )
        golden_ok = (
            golden["candidate_id"] == selected_id
            and tuple(golden["labels"]) == labels
            and golden["model_sha256"] == digest
            and int(golden["arena_bytes"]) <= DEVICE["maximum_arena_bytes"]
            and golden["arena_location"] == "PSRAM"
            and len(golden["rows"]) == 2
            and all(row["argmax_agreement"] and row["passed"] for row in golden["rows"])
            and all(
                float(row["max_absolute_score_difference"])
                <= DEVICE["maximum_golden_score_difference"]
                for row in golden["rows"]
            )
        )
        add(checks, "physical golden parity", golden_ok, {
            "rows": len(golden.get("rows", [])), "passed": golden.get("passed")
        })
    except Exception as exc:
        add(checks, "deployment identity, compile, and golden evidence", False, repr(exc))


def check_measurements(root: Path, labels: tuple[str, str], selected_id: str, checks: list[dict[str, object]]) -> None:
    try:
        timing, _ = read_csv(root / "evidence/final_device/timing.csv")
        inference = [int(row["inference_us"]) for row in timing]
        timing_ok = (
            len(timing) >= 20
            and {row["candidate_id"] for row in timing} == {selected_id}
            and all(int(row["warmup_discarded"]) >= 3 for row in timing)
            and statistics.median(inference) <= DEVICE["maximum_median_inference_us"]
        )
        add(checks, "repeated physical inference timing", timing_ok, {
            "rows": len(timing), "median_inference_us": statistics.median(inference)
        })

        camera_rows, _ = read_csv(root / "evidence/final_device/camera_timing.csv")
        camera_values = [int(row["camera_to_result_us"]) for row in camera_rows]
        camera_ok = (
            len(camera_rows) >= 20
            and {row["candidate_id"] for row in camera_rows} == {selected_id}
            and statistics.median(camera_values)
            <= DEVICE["maximum_median_camera_to_result_us"]
        )
        add(checks, "selected-model live camera timing", camera_ok, {
            "rows": len(camera_rows),
            "median_camera_to_result_us": statistics.median(camera_values),
        })
    except Exception as exc:
        add(checks, "selected-model inference and live timing", False, repr(exc))


def check_report(root: Path, checks: list[dict[str, object]]) -> None:
    try:
        text = (root / "Documentation/A4_REPORT.md").read_text(encoding="utf-8")
        placeholders = len(re.findall(r"\bTODO\b|FILL_IN", text))
        required = (
            "## 1. Visual task and requirement", "## 2. Sensor-native dataset",
            "## 3. Model and device iterations", "## 4. Selection and held-out device result",
            "## 5. Deployment integrity and resources", "## 6. Live demonstration",
            "## 7. Decision and limitation", "## 8. Rubric evidence index",
        )
        add(checks, "completed engineering report", placeholders == 0 and all(value in text for value in required), {
            "remaining_placeholders": placeholders
        })
    except Exception as exc:
        add(checks, "completed engineering report", False, repr(exc))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", type=Path, default=Path("."))
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    checks: list[dict[str, object]] = []
    check_notebook(root / "Python/A4_Lab.ipynb", checks)
    check_notebook(root / "Python/A4_Challenge.ipynb", checks)
    labels, contract = check_task_and_dataset(root, checks)
    check_experiments(root, labels, contract, checks)
    selected_id = check_selection(root, labels, checks)
    check_deployment(root, labels, selected_id, checks)
    check_measurements(root, labels, selected_id, checks)
    check_report(root, checks)
    result = {
        "status": "pass" if all(item["status"] == "pass" for item in checks) else "fail",
        "summary": Counter(item["status"] for item in checks),
        "checks": checks,
    }
    rendered = json.dumps(result, indent=2) + "\n"
    print(rendered, end="")
    if args.json:
        args.json.write_text(rendered, encoding="utf-8")
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
