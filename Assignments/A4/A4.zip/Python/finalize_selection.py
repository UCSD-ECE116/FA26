#!/usr/bin/env python3
"""Freeze one passing device-validated candidate before final submission."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--device-experiments", type=Path, required=True)
    parser.add_argument("--selected-id", required=True)
    parser.add_argument("--validation-summary", type=Path, required=True)
    parser.add_argument("--test-summary", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--task-contract", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, default=Path("evidence"))
    parser.add_argument("--selected-output", type=Path, default=Path("selected"))
    args = parser.parse_args()

    with args.device_experiments.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    selected_rows = [row for row in rows if row["id"] == args.selected_id]
    if len(selected_rows) != 1:
        raise ValueError("selected ID must occur exactly once in device_experiment_results.csv")
    if selected_rows[0]["passes_device_gate"].lower() != "true":
        raise ValueError("only a candidate that passes every published requirement may be selected")

    candidate = args.candidates / args.selected_id
    validation = json.loads(args.validation_summary.read_text(encoding="utf-8"))
    test = json.loads(args.test_summary.read_text(encoding="utf-8"))
    contract = json.loads(args.task_contract.read_text(encoding="utf-8"))
    if validation["candidate_id"] != args.selected_id or validation["split"] != "validation":
        raise ValueError("validation summary does not match the selected candidate")
    if test["candidate_id"] != args.selected_id or test["split"] != "test":
        raise ValueError("test summary does not match the selected candidate")

    args.evidence.mkdir(parents=True, exist_ok=True)
    args.selected_output.mkdir(parents=True, exist_ok=True)
    artifact = candidate / "model_full_int8.tflite"
    selected_artifact = args.evidence / "selected_model_full_int8.tflite"
    shutil.copy2(artifact, selected_artifact)
    for name in (
        "labels.txt", "golden_inputs.npy", "golden_labels.npy",
        "golden_scores_full_int8.npy", "host_result.json",
    ):
        shutil.copy2(candidate / name, args.selected_output / name)
    record = {
        "schema": "ece116.a4.selected-model.v3",
        "selected_id": args.selected_id,
        "artifact_sha256": sha256(selected_artifact),
        "dataset_sha256": sha256(args.dataset),
        "task_contract": contract,
        "device_validation": validation,
        "device_held_out_test": test,
        "labels": contract["labels"],
    }
    (args.evidence / "selected_model_record.json").write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(record, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
