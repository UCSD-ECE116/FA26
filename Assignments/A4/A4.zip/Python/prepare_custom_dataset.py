#!/usr/bin/env python3
"""Validate and package XIAO-captured two-class JPEGs for A4."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

from PIL import Image, ImageOps


SPLITS = ("train", "validation", "test")
MINIMUM_COUNTS = {"train": 60, "validation": 20, "test": 20}
IMAGE_SUFFIXES = {".jpg", ".jpeg"}
OUTPUT_SIZE = 240


def normalized_jpeg(path: Path) -> tuple[bytes, str]:
    with Image.open(path) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
        side = min(image.size)
        left = (image.width - side) // 2
        top = (image.height - side) // 2
        image = image.crop((left, top, left + side, top + side))
        image = image.resize((OUTPUT_SIZE, OUTPUT_SIZE), Image.Resampling.BILINEAR)
        pixel_sha256 = hashlib.sha256(image.tobytes()).hexdigest()
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=90, optimize=True, progressive=False)
        return buffer.getvalue(), pixel_sha256


def labels_from_source(source: Path) -> tuple[str, str]:
    train_root = source / "train"
    if not train_root.is_dir():
        raise FileNotFoundError(f"missing dataset directory: {train_root}")
    labels = sorted(path.name for path in train_root.iterdir() if path.is_dir())
    if len(labels) != 2:
        raise ValueError("train/ must contain exactly two class directories")
    for label in labels:
        if not re.fullmatch(r"[a-z][a-z0-9_]{0,20}", label):
            raise ValueError(
                f"unsupported label {label!r}; use lowercase letters, digits, and underscores"
            )
    expected = set(labels)
    for split in SPLITS:
        split_root = source / split
        if not split_root.is_dir():
            raise FileNotFoundError(f"missing dataset directory: {split_root}")
        found = {path.name for path in split_root.iterdir() if path.is_dir()}
        if found != expected:
            raise ValueError(f"{split}/ class directories must be {labels}")
    return labels[0], labels[1]


def write_zip(output: Path, files: dict[str, bytes]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, files[name])


def build(source: Path, output: Path, task_name: str) -> dict[str, object]:
    labels = labels_from_source(source)
    capture_manifest_path = source / "capture_manifest.csv"
    if not capture_manifest_path.is_file():
        raise FileNotFoundError(
            "capture_manifest.csv is required; collect the dataset with capture_dataset.py"
        )
    with capture_manifest_path.open(newline="", encoding="utf-8") as handle:
        capture_rows = list(csv.DictReader(handle))
    capture_by_path = {row["relative_path"]: row for row in capture_rows}
    if len(capture_by_path) != len(capture_rows):
        raise ValueError("capture_manifest.csv contains a duplicate relative_path")
    files: dict[str, bytes] = {}
    rows: list[dict[str, object]] = []
    seen_pixels: dict[str, str] = {}
    counts: Counter[tuple[str, str]] = Counter()
    xiao_counts: Counter[tuple[str, str]] = Counter()
    sourced_training_counts: Counter[str] = Counter()
    split_sessions: dict[str, set[str]] = {split: set() for split in SPLITS}
    for split in SPLITS:
        for label in labels:
            inputs = sorted(
                path
                for path in (source / split / label).rglob("*")
                if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
            )
            for index, path in enumerate(inputs, start=1):
                source_relative = path.relative_to(source).as_posix()
                source_sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
                capture = capture_by_path.get(source_relative)
                if capture is None:
                    if split != "train":
                        raise ValueError(
                            "validation and test images must be XIAO captures: "
                            f"{source_relative} is missing from capture_manifest.csv"
                        )
                    provenance = "sourced"
                    sourced_training_counts[label] += 1
                else:
                    if capture["split"] != split or capture["label"] != label:
                        raise ValueError(
                            f"capture manifest disagrees with folder path: {source_relative}"
                        )
                    if capture["jpeg_sha256"] != source_sha256:
                        raise ValueError(
                            f"captured JPEG hash does not match the manifest: {source_relative}"
                        )
                    provenance = "xiao"
                    xiao_counts[(split, label)] += 1
                    split_sessions[split].add(capture["session_id"])
                jpeg, pixel_sha256 = normalized_jpeg(path)
                if pixel_sha256 in seen_pixels:
                    raise ValueError(
                        f"duplicate normalized image across dataset: {path} and "
                        f"{seen_pixels[pixel_sha256]}"
                    )
                seen_pixels[pixel_sha256] = str(path)
                relative = f"{split}/{label}/{index:04d}_{pixel_sha256[:12]}.jpg"
                file_sha256 = hashlib.sha256(jpeg).hexdigest()
                files[relative] = jpeg
                rows.append(
                    {
                        "relative_path": relative,
                        "split": split,
                        "label": label,
                        "provenance": provenance,
                        "source_id": pixel_sha256,
                        "sha256": file_sha256,
                        "capture_id": capture["capture_id"] if capture else "",
                        "session_id": capture["session_id"] if capture else "",
                        "captured_at": capture["captured_at"] if capture else "",
                        "source_jpeg_sha256": source_sha256,
                    }
                )
                counts[(split, label)] += 1
    manifest_buffer = io.StringIO()
    writer = csv.DictWriter(
        manifest_buffer,
        fieldnames=(
            "relative_path", "split", "label", "provenance", "source_id", "sha256",
            "capture_id", "session_id", "captured_at", "source_jpeg_sha256",
        ),
        lineterminator="\n",
    )
    writer.writeheader()
    writer.writerows(rows)
    summary = {
        "schema": "ece116.a4.binary-dataset.v1",
        "task_name": task_name,
        "labels": list(labels),
        "image_shape": [OUTPUT_SIZE, OUTPUT_SIZE, 3],
        "normalization": "XIAO JPEG; EXIF removed; centered square crop; 240 by 240 pixels",
        "counts": {
            f"{split}/{label}": counts[(split, label)]
            for split in SPLITS
            for label in labels
        },
        "xiao_capture_counts": {
            f"{split}/{label}": xiao_counts[(split, label)]
            for split in SPLITS
            for label in labels
        },
        "sourced_training_counts": {
            label: sourced_training_counts[label] for label in labels
        },
        "rows": len(rows),
        "sessions": {split: sorted(split_sessions[split]) for split in SPLITS},
    }
    for left_index, left in enumerate(SPLITS):
        for right in SPLITS[left_index + 1 :]:
            overlap = split_sessions[left] & split_sessions[right]
            if overlap:
                raise ValueError(
                    f"capture sessions cannot cross splits: {left}/{right} share {sorted(overlap)}"
                )
    for split in SPLITS:
        for label in labels:
            required = MINIMUM_COUNTS[split]
            observed = xiao_counts[(split, label)]
            if observed < required:
                raise ValueError(
                    f"{split}/{label} has {observed} XIAO captures; at least {required} are required"
                )
    files["labels.txt"] = ("\n".join(labels) + "\n").encode()
    files["manifest.csv"] = manifest_buffer.getvalue().encode()
    files["dataset_record.json"] = (json.dumps(summary, indent=2) + "\n").encode()
    write_zip(output, files)
    summary["archive_sha256"] = hashlib.sha256(output.read_bytes()).hexdigest()
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("Data/custom_dataset.zip"))
    parser.add_argument("--task-name", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.output, args.task_name), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
