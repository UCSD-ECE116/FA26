#!/usr/bin/env python3
"""Run the supplied A4 serial protocol and write normalized evidence files."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import time
from pathlib import Path

import numpy as np
import serial


def sha256_bytes(value: np.ndarray) -> str:
    return hashlib.sha256(np.asarray(value, dtype=np.uint8).tobytes()).hexdigest()


def fields(line: str) -> dict[str, str]:
    return dict(re.findall(r"([A-Za-z0-9_]+)=([^ ]+)", line))


def scores(value: str, labels: tuple[str, str]) -> list[float]:
    parsed = {}
    for item in value.split(","):
        label, number = item.split(":", 1)
        parsed[label] = float(number)
    if set(parsed) != set(labels):
        raise ValueError(f"serial score labels {sorted(parsed)} do not match {labels}")
    return [parsed[label] for label in labels]


class Device:
    def __init__(self, port: str, baud: int, log: list[str]):
        self.serial = serial.Serial(port, baudrate=baud, timeout=0.25)
        self.log = log
        time.sleep(1.2)
        self.serial.reset_input_buffer()

    def close(self) -> None:
        self.serial.close()

    def command(self, value: str, stop, timeout: float = 30.0) -> list[str]:
        self.serial.write((value + "\n").encode())
        self.serial.flush()
        rows = []
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            line = self.serial.readline().decode("utf-8", errors="replace").strip()
            if not line:
                continue
            print(line)
            self.log.append(line)
            rows.append(line)
            if stop(line, rows):
                return rows
        raise TimeoutError(f"timed out waiting for response to {value!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True)
    parser.add_argument("--selected-dir", type=Path, required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--output", type=Path, default=Path("evidence"))
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--camera-timing", type=int, default=20)
    parser.add_argument("--baud", type=int, default=921600)
    args = parser.parse_args()

    labels = tuple(
        line.strip()
        for line in (args.selected_dir / "labels.txt").read_text(encoding="utf-8").splitlines()
    )
    if len(labels) != 2:
        raise ValueError("selected labels must contain exactly two rows")
    host_scores = np.load(args.selected_dir / "golden_scores_full_int8.npy")
    expected = np.load(args.selected_dir / "golden_labels.npy")
    golden_inputs = np.load(args.selected_dir / "golden_inputs.npy")
    if host_scores.ndim != 2 or host_scores.shape[1] != 2:
        raise ValueError("selected golden scores must have two columns")
    if expected.shape != (len(host_scores),) or golden_inputs.shape[0] != len(host_scores):
        raise ValueError("selected golden arrays do not agree")
    selected_indices = []
    for class_index in range(2):
        matches = np.flatnonzero(expected == class_index)
        if not len(matches):
            raise ValueError(f"no selected golden row for {labels[class_index]}")
        selected_indices.append(int(matches[0]))
    host_scores = host_scores[selected_indices]
    expected = expected[selected_indices]
    golden_inputs = golden_inputs[selected_indices]

    args.output.mkdir(parents=True, exist_ok=True)
    log: list[str] = []
    device = Device(args.port, args.baud, log)
    try:
        info_lines = device.command("INFO", lambda line, _: line.startswith("A4_INFO "))
        info = fields(info_lines[-1])
        if info.get("model") != args.candidate:
            raise ValueError(f"device model {info.get('model')} != {args.candidate}")

        golden_lines = device.command(
            "GOLDEN", lambda line, _: line.startswith("GOLDEN_SUMMARY "), timeout=60.0
        )
        observed = [line for line in golden_lines if line.startswith("GOLDEN index=")]
        if len(observed) != 2:
            raise ValueError(f"expected two GOLDEN rows, received {len(observed)}")
        golden_rows = []
        for index, line in enumerate(observed):
            value = fields(line)
            device_scores = scores(value["scores"], labels)
            host = [float(item) for item in host_scores[index]]
            difference = max(abs(left - right) for left, right in zip(host, device_scores))
            golden_rows.append(
                {
                    "input_sha256": value["input_sha256"],
                    "host_input_sha256": sha256_bytes(golden_inputs[index]),
                    "expected_label": labels[int(expected[index])],
                    "host_scores": host,
                    "device_scores": device_scores,
                    "max_absolute_score_difference": difference,
                    "argmax_agreement": int(np.argmax(host)) == int(np.argmax(device_scores)),
                    "passed": value.get("pass") == "1",
                }
            )
        golden_record = {
            "candidate_id": args.candidate,
            "model_sha256": info["model_sha256"],
            "labels": list(labels),
            "score_tolerance": float(fields(observed[0])["tolerance"]),
            "arena_bytes": int(info["arena"]),
            "arena_used_bytes": int(info["arena_used"]),
            "arena_location": "PSRAM",
            "rows": golden_rows,
            "passed": all(row["passed"] for row in golden_rows),
        }
        (args.output / "golden_device.json").write_text(
            json.dumps(golden_record, indent=2) + "\n", encoding="utf-8"
        )
        if not golden_record["passed"]:
            raise RuntimeError("golden parity failed; timing and camera collection stopped")

        timing_lines = device.command(
            "TIMING 20",
            lambda line, rows: len([item for item in rows if item.startswith("TIMING ")]) == 20,
            timeout=120.0,
        )
        timing_rows = []
        for line in timing_lines:
            if not line.startswith("TIMING "):
                continue
            value = fields(line)
            timing_rows.append(
                {
                    "trial_id": value["trial"],
                    "candidate_id": value["model"],
                    "measurement": "inference",
                    "inference_us": value["inference_us"],
                    "frame_to_result_us": "",
                    "warmup_discarded": value["warmup"],
                    "board_core": "3.3.10",
                    "fqbn": "esp32:esp32:XIAO_ESP32S3:PSRAM=opi",
                    "notes": "runtime=tflm",
                }
            )
        with (args.output / "timing.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=timing_rows[0].keys())
            writer.writeheader()
            writer.writerows(timing_rows)

        camera_timing_rows = []
        for index in range(args.camera_timing):
            command = f"CAMERA timing_{index + 1:02d} unlabeled timing"
            lines = device.command(command, lambda line, _: line.startswith("CAMERA trial="))
            value = fields(lines[-1])
            camera_timing_rows.append(
                {
                    "trial_id": value["trial"],
                    "candidate_id": value["model"],
                    "capture_us": value["capture_us"],
                    "preprocess_us": value["preprocess_us"],
                    "inference_us": value["inference_us"],
                    "camera_to_result_us": value["frame_to_result_us"],
                }
            )
        if camera_timing_rows:
            with (args.output / "camera_timing.csv").open(
                "w", newline="", encoding="utf-8"
            ) as handle:
                writer = csv.DictWriter(handle, fieldnames=camera_timing_rows[0].keys())
                writer.writeheader()
                writer.writerows(camera_timing_rows)

        if args.protocol:
            with args.protocol.open(newline="", encoding="utf-8") as handle:
                protocol = list(csv.DictReader(handle))
            completed = []
            for row in protocol:
                input(
                    f"Prepare {row['true_label']} in {row['condition']} for "
                    f"{row['trial_id']}, then press Enter. "
                )
                command = f"CAMERA {row['trial_id']} {row['true_label']} {row['condition']}"
                lines = device.command(command, lambda line, _: line.startswith("CAMERA trial="))
                value = fields(lines[-1])
                device_scores = scores(value["scores"], labels)
                completed.append(
                    {
                        **row,
                        "predicted_label": value["prediction"],
                        f"score_{labels[0]}": f"{device_scores[0]:.6f}",
                        f"score_{labels[1]}": f"{device_scores[1]:.6f}",
                        "inference_us": value["inference_us"],
                        "frame_to_result_us": value["frame_to_result_us"],
                        "notes": (
                            f"capture_us={value['capture_us']};"
                            f"preprocess_us={value['preprocess_us']}"
                        ),
                    }
                )
            with (args.output / "device_trials.csv").open(
                "w", newline="", encoding="utf-8"
            ) as handle:
                writer = csv.DictWriter(handle, fieldnames=completed[0].keys())
                writer.writeheader()
                writer.writerows(completed)
    finally:
        device.close()
        (args.output / "serial_capture.txt").write_text(
            "\n".join(log) + "\n", encoding="utf-8"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
