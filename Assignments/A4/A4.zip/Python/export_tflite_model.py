#!/usr/bin/env python3
"""Embed one full-int8 TFLite artifact in the supplied Arduino sketch."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


RUNTIME_NAME = "Chirale_TensorFlowLite"
RUNTIME_VERSION = "2.0.0"
RUNTIME_ZIP_SHA256 = "d720d744c7f05f775c164d2b73cff1ec953b819d3d0304c082e9ad4b884a0ef8"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def render_bytes(data: bytes, width: int = 16) -> list[str]:
    return [
        "  " + ", ".join(f"0x{value:02x}" for value in data[start : start + width]) + ","
        for start in range(0, len(data), width)
    ]


def write_model_files(
    *, model_path: Path, labels_path: Path, model_id: str, output: Path, record: Path
) -> dict[str, object]:
    model_bytes = model_path.read_bytes()
    if len(model_bytes) < 8 or model_bytes[4:8] != b"TFL3":
        raise ValueError(f"not a TensorFlow Lite FlatBuffer: {model_path}")
    labels = [line.strip() for line in labels_path.read_text(encoding="utf-8").splitlines()]
    labels = [label for label in labels if label]
    if not labels:
        raise ValueError("labels file is empty")

    output.mkdir(parents=True, exist_ok=True)
    model_sha256 = sha256_bytes(model_bytes)
    model_data_h = output / "model_data.h"
    model_data_cpp = output / "model_data.cpp"
    metadata_h = output / "model_metadata.h"

    model_data_h.write_text(
        "#pragma once\n\n"
        "extern const unsigned char g_model_data[];\n"
        "extern const unsigned int g_model_data_len;\n",
        encoding="utf-8",
    )
    model_data_cpp.write_text(
        "#include \"model_data.h\"\n\n"
        "alignas(16) extern const unsigned char g_model_data[] = {\n"
        + "\n".join(render_bytes(model_bytes))
        + "\n};\n"
        + f"extern const unsigned int g_model_data_len = {len(model_bytes)};\n",
        encoding="utf-8",
    )
    label_lines = "\n".join(f'    "{label}",' for label in labels)
    metadata_h.write_text(
        "#pragma once\n\n"
        "#include <stddef.h>\n\n"
        f'constexpr const char *kA4ModelId = "{model_id}";\n'
        f'constexpr const char *kA4ModelSha256 = "{model_sha256}";\n'
        f"constexpr size_t kA4LabelCount = {len(labels)};\n"
        "static const char *const kA4Labels[kA4LabelCount] = {\n"
        f"{label_lines}\n"
        "};\n",
        encoding="utf-8",
    )

    result = {
        "schema": "ece116.a4.model-embed.v1",
        "model_id": model_id,
        "model_filename": model_path.name,
        "model_sha256": model_sha256,
        "model_bytes": len(model_bytes),
        "labels": labels,
        "runtime": {
            "name": RUNTIME_NAME,
            "version": RUNTIME_VERSION,
            "zip_sha256": RUNTIME_ZIP_SHA256,
        },
        "generated_files": {
            path.name: sha256_file(path)
            for path in (model_data_h, model_data_cpp, metadata_h)
        },
    }
    record.parent.mkdir(parents=True, exist_ok=True)
    record.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--record", type=Path, required=True)
    args = parser.parse_args()
    result = write_model_files(
        model_path=args.model,
        labels_path=args.labels,
        model_id=args.model_id,
        output=args.output,
        record=args.record,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
