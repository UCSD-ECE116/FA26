#!/usr/bin/env python3
"""Apply A4 requirements to recorded-image validation results from the physical XIAO."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--device-results", type=Path, required=True)
    parser.add_argument("--task-contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("evidence/device_experiment_results.csv"))
    args = parser.parse_args()
    contract = json.loads(args.task_contract.read_text(encoding="utf-8"))
    positive = contract["positive_label"]
    labels = contract["labels"]
    negative = next(label for label in labels if label != positive)
    metric_label = positive if contract["quality_metric"] == "positive_recall" else negative
    rows = []
    for summary_path in sorted(args.device_results.glob("*.summary.json")):
        device = json.loads(summary_path.read_text(encoding="utf-8"))
        if device.get("split") != "validation":
            continue
        candidate_id = device["candidate_id"]
        candidate_dir = args.candidates / candidate_id
        host = json.loads((candidate_dir / "host_result.json").read_text(encoding="utf-8"))
        artifact = candidate_dir / "model_full_int8.tflite"
        if not artifact.is_file():
            raise FileNotFoundError(artifact)
        quantization_drop = (
            host["float_validation_balanced_accuracy"]
            - host["int8_validation_balanced_accuracy"]
        )
        task_metric = device["per_class_recall"][metric_label]
        checks = {
            "device_balanced_accuracy": device["balanced_accuracy"] >= 0.70,
            "task_metric": task_metric >= contract["minimum_quality"],
            "artifact_bytes": artifact.stat().st_size <= 700_000,
            "quantization_drop": quantization_drop <= 0.10,
            "median_inference_us": device["median_inference_us"] <= 850_000,
            "median_replay_to_result_us": device["median_replay_to_result_us"] <= 1_000_000,
            "arena_bytes": device["arena_bytes"] <= 524_288,
            "flash_bytes": device["flash_bytes"] <= 1_500_000,
            "static_ram_bytes": device["static_ram_bytes"] <= 64_000,
            "golden_argmax_agreement": bool(device["golden_argmax_agreement"]),
            "golden_score_difference": (
                device["golden_max_absolute_score_difference"] <= 0.06
            ),
        }
        rows.append(
            {
                "id": candidate_id,
                "resolution": host["internal_resolution"],
                "alpha": host["alpha"],
                "device_validation_balanced_accuracy": device["balanced_accuracy"],
                "device_task_metric": task_metric,
                "task_metric_label": metric_label,
                "int8_bytes": artifact.stat().st_size,
                "quantization_drop": quantization_drop,
                "arena_used_bytes": device["arena_used_bytes"],
                "flash_bytes": device["flash_bytes"],
                "static_ram_bytes": device["static_ram_bytes"],
                "median_preprocess_us": device["median_preprocess_us"],
                "median_inference_us": device["median_inference_us"],
                "median_replay_to_result_us": device["median_replay_to_result_us"],
                "golden_max_absolute_score_difference": device[
                    "golden_max_absolute_score_difference"
                ],
                "failed_requirements": ";".join(name for name, passed in checks.items() if not passed),
                "passes_device_gate": all(checks.values()),
            }
        )
    if len(rows) < 3:
        raise ValueError("evaluate validation images on the XIAO with at least three candidates")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(row)
    if not any(row["passes_device_gate"] for row in rows):
        print("No candidate passes yet. Diagnose the failures and run another supported experiment.")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
