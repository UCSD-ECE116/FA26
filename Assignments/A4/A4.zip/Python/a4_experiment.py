"""Supplied transfer-learning, optimization, and evaluation mechanics for ECE116 A4."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
import tensorflow as tf


EXTERNAL_IMAGE_SIZE = 96
ALLOWED_RESOLUTIONS = (64, 80, 96)
ALLOWED_ALPHAS = (0.35, 0.50)
BASELINE_CONFIGURATION = {"internal_resolution": 96, "alpha": 0.50}
REQUIRED_SPLITS = ("train", "validation", "test")
SEED = 116


def sha256(path: str | Path) -> str:
    """Return the lowercase SHA-256 digest for one file."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def extract_dataset(archive_path: str | Path, destination: str | Path) -> Path:
    """Extract one dataset after rejecting paths outside the destination."""
    archive_path = Path(archive_path)
    destination = Path(destination)
    if (destination / "manifest.csv").is_file():
        return destination
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if target != root and root not in target.parents:
                raise ValueError(f"unsafe archive member: {member.filename}")
        archive.extractall(destination)
    return destination


def read_labels(path: str | Path) -> tuple[str, str]:
    """Read and validate the two deployment labels in fixed output order."""
    labels = tuple(line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines())
    if len(labels) != 2 or len(set(labels)) != 2:
        raise ValueError("A4 requires exactly two distinct labels")
    for label in labels:
        if not re.fullmatch(r"[a-z][a-z0-9_]{0,20}", label):
            raise ValueError(
                f"unsupported label {label!r}; use lowercase letters, digits, and underscores"
            )
    return labels  # type: ignore[return-value]


def validate_configurations(
    configurations: Iterable[dict[str, object]],
) -> list[dict[str, object]]:
    """Validate a baseline plus at least two deliberate model-scaling experiments."""
    values = [dict(item) for item in configurations]
    if len(values) < 3:
        raise ValueError("run the baseline and at least two additional configurations")
    pairs: list[tuple[int, float]] = []
    identifiers: list[str] = []
    for config in values:
        identifier = str(config["id"])
        resolution = int(config["internal_resolution"])
        alpha = float(config["alpha"])
        if resolution not in ALLOWED_RESOLUTIONS:
            raise ValueError(f"unsupported internal_resolution: {resolution}")
        if alpha not in ALLOWED_ALPHAS:
            raise ValueError(f"unsupported alpha: {alpha}")
        expected = f"R{resolution}-A{int(round(alpha * 100)):03d}"
        if identifier != expected:
            raise ValueError(f"configuration id {identifier} should be {expected}")
        identifiers.append(identifier)
        pairs.append((resolution, alpha))
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("configuration ids must be unique")
    if len(set(pairs)) != len(pairs):
        raise ValueError("configurations must be unique")
    baseline = (
        int(BASELINE_CONFIGURATION["internal_resolution"]),
        float(BASELINE_CONFIGURATION["alpha"]),
    )
    if pairs[0] != baseline:
        raise ValueError("the first run must be the supplied R96-A050 baseline")
    controlled_pairs = [
        (left, right)
        for index, left in enumerate(pairs)
        for right in pairs[index + 1 :]
        if (left[0] == right[0]) ^ (left[1] == right[1])
    ]
    if not controlled_pairs:
        raise ValueError("include at least one pair that changes only resolution or only alpha")
    return values


def _decode_resize(path: tf.Tensor, label: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    image = tf.io.decode_image(tf.io.read_file(path), channels=3, expand_animations=False)
    image.set_shape((None, None, 3))
    image = tf.image.resize(
        image,
        (EXTERNAL_IMAGE_SIZE, EXTERNAL_IMAGE_SIZE),
        method="bilinear",
    )
    return tf.cast(image, tf.float32), tf.cast(label, tf.int32)


def _dataset_from_frame(
    frame: pd.DataFrame,
    dataset_root: Path,
    labels: Sequence[str],
    *,
    training: bool,
    batch_size: int,
) -> tf.data.Dataset:
    label_to_index = {label: index for index, label in enumerate(labels)}
    paths = [str(dataset_root / value) for value in frame["relative_path"]]
    indices = frame["label"].map(label_to_index).to_numpy(dtype=np.int32)
    dataset = tf.data.Dataset.from_tensor_slices((paths, indices))
    dataset = dataset.map(_decode_resize, num_parallel_calls=tf.data.AUTOTUNE)
    if training:
        dataset = dataset.shuffle(len(paths), seed=SEED, reshuffle_each_iteration=True)
    return dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)


def load_dataset(
    dataset_archive: str | Path,
    work_directory: str | Path,
    *,
    batch_size: int = 32,
) -> dict[str, object]:
    """Load a prepared two-class archive with explicit train, validation, and test splits."""
    work_directory = Path(work_directory)
    archive_path = Path(dataset_archive)
    root = extract_dataset(
        archive_path,
        work_directory / f"dataset_{sha256(archive_path)[:12]}",
    )
    labels = read_labels(root / "labels.txt")
    manifest = pd.read_csv(root / "manifest.csv")
    required_columns = {"relative_path", "split", "label", "source_id", "sha256"}
    missing = required_columns - set(manifest.columns)
    if missing:
        raise ValueError(f"dataset manifest is missing columns: {sorted(missing)}")
    if set(manifest["split"]) != set(REQUIRED_SPLITS):
        raise ValueError("dataset must contain train, validation, and test rows")
    if set(manifest["label"]) != set(labels):
        raise ValueError("manifest labels do not match labels.txt")
    if manifest["sha256"].duplicated().any():
        raise ValueError("dataset contains duplicate normalized image bytes")
    missing_files = [
        value for value in manifest["relative_path"] if not (root / value).is_file()
    ]
    if missing_files:
        raise FileNotFoundError(f"dataset archive is missing files: {missing_files[:3]}")
    result: dict[str, object] = {
        "root": root,
        "labels": labels,
        "manifest": manifest,
        "archive_sha256": sha256(archive_path),
    }
    for split in REQUIRED_SPLITS:
        frame = manifest.query("split == @split").reset_index(drop=True)
        result[f"{split}_frame"] = frame
        result[split] = _dataset_from_frame(
            frame,
            root,
            labels,
            training=split == "train",
            batch_size=batch_size,
        )
    return result


def collect_dataset(dataset: tf.data.Dataset) -> tuple[np.ndarray, np.ndarray]:
    """Materialize one finite dataset for conversion or deterministic evaluation."""
    images: list[np.ndarray] = []
    labels: list[np.ndarray] = []
    for batch_images, batch_labels in dataset:
        images.append(np.asarray(batch_images, dtype=np.float32))
        labels.append(np.asarray(batch_labels, dtype=np.int32))
    if not images:
        raise ValueError("dataset is empty")
    return np.concatenate(images), np.concatenate(labels)


def build_model(
    internal_resolution: int,
    alpha: float,
    *,
    class_count: int = 2,
    model_name: str = "ece116_a4_binary",
) -> tf.keras.Model:
    """Build the supplied pretrained MobileNetV2 family with a fixed external interface."""
    if internal_resolution not in ALLOWED_RESOLUTIONS:
        raise ValueError(f"unsupported resolution: {internal_resolution}")
    if alpha not in ALLOWED_ALPHAS:
        raise ValueError(f"unsupported alpha: {alpha}")
    if class_count != 2:
        raise ValueError("A4 supports exactly two output classes")
    inputs = tf.keras.Input(
        (EXTERNAL_IMAGE_SIZE, EXTERNAL_IMAGE_SIZE, 3),
        name="image",
        dtype=tf.float32,
    )
    x = tf.keras.layers.RandomFlip("horizontal", seed=SEED, name="augment_flip")(inputs)
    x = tf.keras.layers.RandomRotation(0.06, seed=SEED + 1, name="augment_rotate")(x)
    x = tf.keras.layers.RandomZoom(0.10, seed=SEED + 2, name="augment_zoom")(x)
    x = tf.keras.layers.RandomContrast(0.10, seed=SEED + 3, name="augment_contrast")(x)
    if internal_resolution != EXTERNAL_IMAGE_SIZE:
        x = tf.keras.layers.Resizing(
            internal_resolution,
            internal_resolution,
            interpolation="bilinear",
            name=f"resize_{internal_resolution}",
        )(x)
    x = tf.keras.layers.Rescaling(1 / 127.5, offset=-1, name="normalize")(x)
    backbone = tf.keras.applications.MobileNetV2(
        input_shape=(internal_resolution, internal_resolution, 3),
        include_top=False,
        weights="imagenet",
        alpha=alpha,
    )
    backbone.trainable = False
    x = backbone(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D(name="pool")(x)
    x = tf.keras.layers.Dropout(0.20, name="dropout")(x)
    outputs = tf.keras.layers.Dense(class_count, activation="softmax", name="scores")(x)
    return tf.keras.Model(inputs, outputs, name=model_name)


def compile_model(model: tf.keras.Model, learning_rate: float) -> None:
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )


def train_model(
    config: dict[str, object],
    train_dataset: tf.data.Dataset,
    validation_dataset: tf.data.Dataset,
    *,
    class_count: int = 2,
    frozen_epochs: int = 4,
    fine_tune_epochs: int = 2,
    verbose: int = 2,
) -> tuple[tf.keras.Model, dict[str, object]]:
    """Fine-tune one configuration under the supplied two-stage protocol."""
    tf.keras.utils.set_random_seed(SEED)
    model = build_model(
        int(config["internal_resolution"]),
        float(config["alpha"]),
        class_count=class_count,
        model_name=f"ece116_{str(config['id']).lower().replace('-', '_')}",
    )
    compile_model(model, 3e-4)
    frozen_history = model.fit(
        train_dataset,
        validation_data=validation_dataset,
        epochs=frozen_epochs,
        verbose=verbose,
    )
    backbone = next(layer for layer in model.layers if "mobilenetv2" in layer.name.lower())
    backbone.trainable = True
    for layer in backbone.layers[:-10]:
        layer.trainable = False
    compile_model(model, 2e-5)
    fine_history = model.fit(
        train_dataset,
        validation_data=validation_dataset,
        epochs=fine_tune_epochs,
        verbose=verbose,
    )
    record = {
        "configuration": {
            "id": str(config["id"]),
            "internal_resolution": int(config["internal_resolution"]),
            "alpha": float(config["alpha"]),
        },
        "parameters": int(model.count_params()),
        "frozen_validation_accuracy": [
            float(value) for value in frozen_history.history["val_accuracy"]
        ],
        "fine_tune_validation_accuracy": [
            float(value) for value in fine_history.history["val_accuracy"]
        ],
    }
    return model, record


def save_fixed_batch_model(model: tf.keras.Model, destination: str | Path) -> Path:
    destination = Path(destination)
    if destination.exists():
        shutil.rmtree(destination)

    @tf.function(
        input_signature=[
            tf.TensorSpec(
                (1, EXTERNAL_IMAGE_SIZE, EXTERNAL_IMAGE_SIZE, 3),
                tf.float32,
                name="image",
            )
        ]
    )
    def serve(image: tf.Tensor) -> dict[str, tf.Tensor]:
        return {"scores": model(image, training=False)}

    archive = tf.keras.export.ExportArchive()
    archive.track(model)
    archive.add_endpoint("serving_default", serve)
    archive.write_out(destination, verbose=False)
    return destination


def convert_tflite(
    model: tf.keras.Model,
    representative_inputs: np.ndarray,
    output_directory: str | Path,
) -> dict[str, Path]:
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    saved_model = save_fixed_batch_model(model, output_directory / "saved_model")
    float_converter = tf.lite.TFLiteConverter.from_saved_model(str(saved_model))
    float_bytes = float_converter.convert()

    def representative_generator():
        for item in np.asarray(representative_inputs, dtype=np.float32):
            yield [item[None]]

    int8_converter = tf.lite.TFLiteConverter.from_saved_model(str(saved_model))
    int8_converter.optimizations = [tf.lite.Optimize.DEFAULT]
    int8_converter.representative_dataset = representative_generator
    int8_converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    int8_converter.inference_input_type = tf.uint8
    int8_converter.inference_output_type = tf.uint8
    int8_bytes = int8_converter.convert()
    float_path = output_directory / "model_float32.tflite"
    int8_path = output_directory / "model_full_int8.tflite"
    float_path.write_bytes(float_bytes)
    int8_path.write_bytes(int8_bytes)
    shutil.rmtree(saved_model)
    return {"float32": float_path, "full_int8": int8_path}


def run_tflite(
    model_path: str | Path,
    inputs: np.ndarray,
) -> tuple[np.ndarray, dict[str, object]]:
    interpreter = tf.lite.Interpreter(model_path=str(model_path))
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    outputs: list[np.ndarray] = []
    for item in np.asarray(inputs, dtype=np.float32):
        value = item[None]
        if np.issubdtype(input_detail["dtype"], np.integer):
            scale, zero_point = input_detail["quantization"]
            value = np.clip(np.rint(value / scale + zero_point), 0, 255)
        interpreter.set_tensor(input_detail["index"], value.astype(input_detail["dtype"]))
        interpreter.invoke()
        output = interpreter.get_tensor(output_detail["index"])[0]
        if np.issubdtype(output_detail["dtype"], np.integer):
            scale, zero_point = output_detail["quantization"]
            output = (output.astype(np.float32) - zero_point) * scale
        outputs.append(output)
    metadata = {
        "input_shape": input_detail["shape"].tolist(),
        "input_dtype": np.dtype(input_detail["dtype"]).name,
        "input_quantization": list(input_detail["quantization"]),
        "output_shape": output_detail["shape"].tolist(),
        "output_dtype": np.dtype(output_detail["dtype"]).name,
        "output_quantization": list(output_detail["quantization"]),
    }
    return np.asarray(outputs), metadata


def classification_metrics(
    scores: np.ndarray,
    truth: np.ndarray,
    labels: Sequence[str],
) -> dict[str, object]:
    """Return complete two-class metrics in the supplied fixed label order."""
    if len(labels) != 2:
        raise ValueError("binary metrics require two labels")
    predictions = np.asarray(scores).argmax(axis=1)
    truth = np.asarray(truth, dtype=np.int32)
    matrix = np.zeros((2, 2), dtype=np.int64)
    for actual, predicted in zip(truth, predictions):
        matrix[int(actual), int(predicted)] += 1
    recalls: dict[str, float] = {}
    precisions: dict[str, float] = {}
    for index, label in enumerate(labels):
        recalls[label] = float(matrix[index, index] / max(matrix[index].sum(), 1))
        precisions[label] = float(matrix[index, index] / max(matrix[:, index].sum(), 1))
    return {
        "n": int(len(truth)),
        "accuracy": float(np.mean(predictions == truth)),
        "balanced_accuracy": float(np.mean(list(recalls.values()))),
        "per_class_precision": precisions,
        "per_class_recall": recalls,
        "confusion_matrix": matrix.tolist(),
    }


def host_requirement(
    result: dict[str, object],
    *,
    minimum_balanced_accuracy: float,
    maximum_int8_bytes: int,
    maximum_quantization_drop: float,
    student_quality_passed: bool,
) -> dict[str, object]:
    """Apply fixed host requirements plus the student's predeclared quality check."""
    float_quality = float(result["float_validation_balanced_accuracy"])
    int8_quality = float(result["int8_validation_balanced_accuracy"])
    int8_bytes = int(result["int8_bytes"])
    checks = {
        "balanced_accuracy": int8_quality >= minimum_balanced_accuracy,
        "int8_bytes": int8_bytes <= maximum_int8_bytes,
        "quantization_drop": float_quality - int8_quality <= maximum_quantization_drop,
        "student_quality_requirement": bool(student_quality_passed),
    }
    return {"passed": all(checks.values()), "checks": checks}


def write_json(path: str | Path, value: object) -> None:
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
