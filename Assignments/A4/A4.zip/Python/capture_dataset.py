#!/usr/bin/env python3
"""Serve a local browser UI that captures labeled JPEGs from the XIAO camera."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import threading
import webbrowser
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from a4_device_io import A4Serial


HTML = r"""<!doctype html>
<meta charset="utf-8">
<title>ECE116 A4 XIAO Capture Rig</title>
<style>
body{font:16px system-ui;margin:2rem;max-width:900px}main{display:grid;grid-template-columns:360px 1fr;gap:2rem}
img{width:320px;height:320px;object-fit:contain;background:#222}label{display:block;margin:.8rem 0}
select,input,button{font:inherit;padding:.45rem}button{margin-right:.5rem}pre{white-space:pre-wrap;background:#f3f3f3;padding:1rem}
</style>
<h1>ECE116 A4 XIAO Capture Rig</h1>
<p>Choose a split, label, and collection session. Preview does not save. Save capture writes the exact XIAO JPEG and manifest row.</p>
<main><section><img id="preview"><p id="message">No frame captured.</p></section><section>
<label>Split <select id="split"><option>train</option><option>validation</option><option>test</option></select></label>
<label>Label <select id="label"></select></label>
<label>Session ID <input id="session" value="session_01" pattern="[a-z0-9_]+"></label>
<button onclick="capture(false)">Preview</button><button onclick="capture(true)">Save capture</button>
<h2>Saved counts</h2><pre id="counts"></pre></section></main>
<script>
const labels=LABELS; const select=document.getElementById('label'); labels.forEach(x=>select.add(new Option(x,x)));
async function state(){const r=await fetch('/api/state');const x=await r.json();document.getElementById('counts').textContent=JSON.stringify(x.counts,null,2)}
async function capture(save){const q=new URLSearchParams({split:split.value,label:select.value,session:session.value,save:save?'1':'0'});message.textContent='Capturing…';const r=await fetch('/api/capture?'+q);const x=await r.json();if(!r.ok){message.textContent=x.error;return}preview.src='/latest.jpg?t='+Date.now();message.textContent=save?'Saved '+x.relative_path:'Preview only';state()}
state();
</script>"""


class CaptureState:
    def __init__(self, device: A4Serial, root: Path, labels: tuple[str, str]):
        self.device = device
        self.root = root
        self.labels = labels
        self.lock = threading.Lock()
        self.latest = b""
        self.counter = 0
        self.manifest = root / "capture_manifest.csv"
        self.fields = (
            "capture_id", "split", "label", "session_id", "relative_path",
            "captured_at", "jpeg_bytes", "jpeg_sha256", "crc32", "width", "height",
        )
        root.mkdir(parents=True, exist_ok=True)
        if not self.manifest.exists():
            with self.manifest.open("w", newline="", encoding="utf-8") as handle:
                csv.DictWriter(handle, fieldnames=self.fields).writeheader()
        self.counter = len(self.rows())

    def rows(self):
        with self.manifest.open(newline="", encoding="utf-8") as handle:
            return list(csv.DictReader(handle))

    def counts(self):
        return dict(Counter(f"{row['split']}/{row['label']}" for row in self.rows()))

    def capture(self, split: str, label: str, session: str, save: bool):
        if split not in {"train", "validation", "test"}:
            raise ValueError("invalid split")
        if label not in self.labels:
            raise ValueError("invalid label")
        if not re.fullmatch(r"[a-z0-9_]{1,32}", session):
            raise ValueError("session must use lowercase letters, digits, and underscores")
        with self.lock:
            self.counter += 1
            capture_id = f"cap_{self.counter:05d}"
            payload, metadata = self.device.capture_jpeg(capture_id)
            if int(metadata.get("width", 0)) != 240 or int(metadata.get("height", 0)) != 240:
                raise ValueError(f"expected a 240 by 240 camera JPEG, received {metadata}")
            self.latest = payload
            if not save:
                return {"capture_id": capture_id, "saved": False}
            folder = self.root / split / label
            folder.mkdir(parents=True, exist_ok=True)
            index = 1 + sum(1 for row in self.rows() if row["split"] == split and row["label"] == label)
            relative = Path(split) / label / f"{session}_{index:04d}.jpg"
            path = self.root / relative
            path.write_bytes(payload)
            row = {
                "capture_id": capture_id,
                "split": split,
                "label": label,
                "session_id": session,
                "relative_path": relative.as_posix(),
                "captured_at": datetime.now(timezone.utc).isoformat(),
                "jpeg_bytes": len(payload),
                "jpeg_sha256": hashlib.sha256(payload).hexdigest(),
                "crc32": metadata["crc32"],
                "width": metadata["width"],
                "height": metadata["height"],
            }
            with self.manifest.open("a", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=self.fields)
                writer.writerow(row)
            return {**row, "saved": True}


def handler_factory(state: CaptureState):
    page = HTML.replace("LABELS", json.dumps(state.labels)).encode()

    class Handler(BaseHTTPRequestHandler):
        def send(self, status: int, body: bytes, content_type: str):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlparse(self.path)
            try:
                if parsed.path == "/":
                    self.send(200, page, "text/html; charset=utf-8")
                elif parsed.path == "/latest.jpg":
                    self.send(200, state.latest, "image/jpeg")
                elif parsed.path == "/api/state":
                    self.send(200, json.dumps({"counts": state.counts()}).encode(), "application/json")
                elif parsed.path == "/api/capture":
                    query = parse_qs(parsed.query)
                    result = state.capture(
                        query.get("split", [""])[0], query.get("label", [""])[0],
                        query.get("session", [""])[0], query.get("save", ["0"])[0] == "1",
                    )
                    self.send(200, json.dumps(result).encode(), "application/json")
                else:
                    self.send(404, b"not found", "text/plain")
            except Exception as exc:
                self.send(400, json.dumps({"error": str(exc)}).encode(), "application/json")

        def log_message(self, format, *args):
            return

    return Handler


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--labels", nargs=2, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--http-port", type=int, default=8116)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    labels = tuple(args.labels)
    if any(not re.fullmatch(r"[a-z][a-z0-9_]{0,20}", label) for label in labels):
        raise ValueError("labels must use lowercase letters, digits, and underscores")
    device = A4Serial(args.port)
    try:
        info = device.info()
        if info.get("camera") != "1":
            raise RuntimeError(f"camera is not ready: {info}")
        state = CaptureState(device, args.root, labels)  # type: ignore[arg-type]
        server = ThreadingHTTPServer((args.host, args.http_port), handler_factory(state))
        url = f"http://{args.host}:{args.http_port}/"
        print(f"Capture rig ready at {url}; press Ctrl+C to stop.")
        if not args.no_browser:
            webbrowser.open(url)
        server.serve_forever()
    except KeyboardInterrupt:
        return 0
    finally:
        device.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
