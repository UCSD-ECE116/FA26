#!/usr/bin/env python3
"""Evaluate one recorded dataset split with the flashed model on the physical XIAO."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import statistics
import zipfile
from collections import Counter
from pathlib import Path

from a4_device_io import A4Serial, fields, score_values


def metrics(rows: list[dict[str, object]], labels: tuple[str, str]) -> dict[str, object]:
    matrix = [[0, 0], [0, 0]]
    index = {label: value for value, label in enumerate(labels)}
    for row in rows:
        matrix[index[str(row["true_label"])]][index[str(row["predicted_label"])]] += 1
    recalls = {
        label: matrix[i][i] / max(sum(matrix[i]), 1) for i, label in enumerate(labels)
    }
    return {
        "rows": len(rows),
        "confusion_matrix": matrix,
        "accuracy": sum(matrix[i][i] for i in range(2)) / max(len(rows), 1),
        "balanced_accuracy": statistics.mean(recalls.values()),
        "per_class_recall": recalls,
        "median_preprocess_us": statistics.median(int(row["preprocess_us"]) for row in rows),
        "median_inference_us": statistics.median(int(row["inference_us"]) for row in rows),
        "median_replay_to_result_us": statistics.median(
            int(row["replay_to_result_us"]) for row in rows
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--split", choices=("validation", "test"), required=True)
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--compile-report", type=Path, required=True)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--warmup", type=int, default=3)
    args = parser.parse_args()

    with zipfile.ZipFile(args.dataset) as archive:
        labels = tuple(archive.read("labels.txt").decode().splitlines())
        manifest = list(csv.DictReader(archive.read("manifest.csv").decode().splitlines()))
        selected = [row for row in manifest if row["split"] == args.split]
        selected.sort(key=lambda row: (row["label"], row["relative_path"]))
        if args.limit:
            by_label = {label: [row for row in selected if row["label"] == label] for label in labels}
            selected = []
            for label in labels:
                selected.extend(by_label[label][: args.limit])
        device = A4Serial(args.port)
        try:
            info = device.info()
            if info.get("model") != args.candidate:
                raise ValueError(f"flashed model {info.get('model')} != {args.candidate}")
            if int(info.get("labels", 0)) != 2:
                raise ValueError(f"flashed model is not binary: {info}")
            if not selected:
                raise ValueError(f"dataset has no {args.split} rows")
            device.write_command("GOLDEN")
            golden_lines = []
            while True:
                line = device.read_line(60.0)
                golden_lines.append(line)
                if line.startswith("GOLDEN_SUMMARY "):
                    if "pass=1" not in line:
                        raise RuntimeError("golden parity failed; on-device evaluation stopped")
                    break
            golden_rows = [fields(line) for line in golden_lines if line.startswith("GOLDEN index=")]
            warmup_payload = archive.read(selected[0]["relative_path"])
            for index in range(args.warmup):
                device.replay_jpeg(f"warmup_{index + 1}", selected[0]["label"], "warmup", warmup_payload)
            results = []
            for number, row in enumerate(selected, start=1):
                payload = archive.read(row["relative_path"])
                value = device.replay_jpeg(
                    f"{args.split}_{number:04d}", row["label"], args.split, payload
                )
                score = score_values(value["scores"], labels)  # type: ignore[arg-type]
                results.append(
                    {
                        "trial_id": value["trial"],
                        "relative_path": row["relative_path"],
                        "image_sha256": hashlib.sha256(payload).hexdigest(),
                        "true_label": row["label"],
                        "candidate_id": value["model"],
                        "model_sha256": info["model_sha256"],
                        "predicted_label": value["prediction"],
                        f"score_{labels[0]}": f"{score[0]:.6f}",
                        f"score_{labels[1]}": f"{score[1]:.6f}",
                        "jpeg_bytes": value["bytes"],
                        "crc32": value["crc32"],
                        "transfer_us": value["transfer_us"],
                        "decode_us": value["decode_us"],
                        "resize_us": value["resize_us"],
                        "preprocess_us": value["preprocess_us"],
                        "inference_us": value["inference_us"],
                        "replay_to_result_us": value["replay_to_result_us"],
                    }
                )
        finally:
            device.close()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    compile_text = args.compile_report.read_text(encoding="utf-8", errors="replace")
    flash_match = re.search(r"Sketch uses (\d+) bytes", compile_text)
    static_match = re.search(r"Global variables use (\d+) bytes", compile_text)
    if not flash_match or not static_match:
        raise ValueError("compile report does not contain flash and static RAM values")
    summary = {
        "schema": "ece116.a4.device-replay.v1",
        "dataset_sha256": hashlib.sha256(args.dataset.read_bytes()).hexdigest(),
        "split": args.split,
        "candidate_id": args.candidate,
        "model_sha256": results[0]["model_sha256"],
        "model_bytes": int(info["model_bytes"]),
        "arena_bytes": int(info["arena"]),
        "arena_used_bytes": int(info["arena_used"]),
        "flash_bytes": int(flash_match.group(1)),
        "static_ram_bytes": int(static_match.group(1)),
        "golden_passed": True,
        "golden_rows": len(golden_rows),
        "golden_argmax_agreement": all(row.get("argmax_match") == "1" for row in golden_rows),
        "golden_max_absolute_score_difference": max(
            float(row["max_abs"]) for row in golden_rows
        ),
        "labels": list(labels),
        "class_counts": dict(Counter(str(row["true_label"]) for row in results)),
        **metrics(results, labels),  # type: ignore[arg-type]
    }
    summary_path = args.output.with_suffix(".summary.json")
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
