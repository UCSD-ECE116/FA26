# A4: Design and deploy a tiny visual capability

**Student release: v1.0.0.**

Start with `Documentation/A4_Handout.md`. The guided Lab teaches the complete fine-tuning,
optimization, quantization, and deployment path with a supplied binary fruit task. The Challenge
asks you to define and deploy a binary visual capability of your own.

## Package map

- `Data/`: guided-Lab data and the location for your prepared custom dataset;
- `Lab Fixture/`: accepted binary fruit artifact and host-parity vectors;
- `Python/`: Lab and Challenge notebooks plus the XIAO browser capture rig, recorded-image
  hardware-in-the-loop evaluation, model, conversion, export, selection, evidence, and checker
  mechanics;
- `Libraries/`: pinned TensorFlow Lite Micro runtime;
- `Arduino/A4_Vision/`: generalized two-label camera and inference firmware;
- `evidence/`: generated and physical records; and
- `Documentation/`: handout, interface contract, and one report template.

Use Colab `2026.04` without changing its packages. Submit every candidate full-int8 artifact so
staff can reproduce the device comparisons, but omit the larger Keras, SavedModel, and float32
intermediates. Physical power and energy measurements are not part of A4.
